# 海康 MVS 工业相机 SDK（Linux / C，V4.9.0）开发笔记

> ## ⚠️ 实测更正（2026-11-10，hik_probe 在真机 MV-CB013-A0UC-S 上实测）
>
> 本笔记写于真机测试之前，部分结论来自虚拟相机的描述文件（[VXML]）。下面几条以真机实测为准，正文未逐处修改：
>
> 1. **`DeviceTimestampIncrement` 在真机上是时钟频率**：值为 100000000（100 MHz），即 1 tick = 10 ns。既不是用户手册说的“最大值”，也不是 [VXML] 说的“每 tick 多少 ns”（U1、U10）。
> 2. **读取 `DeviceTimestamp` 前必须执行 `DeviceTimestampLatch`**：不执行 Latch，或者只调用 `MV_CC_InvalidateNodes`，读到的都是同一个旧值（U2）。
> 3. **取流中可以执行 Latch**：1201 / 1201 次成功；往返时间最小约 0.35 ms，中位约 0.41 ms，p99 约 1.5 ms（U2、U12）。
> 4. **帧时间戳和 Latch 时间戳是同一个时钟**：用 Latch 样本换算后，“接收时刻 − 帧时间”的标准差只有 0.018 ms（U3）。
> 5. **设备时钟从上电开始计时**：停流后读到的时间戳 ≈ `DeviceUptime`（秒）；相机重启后归零（U14）。
> 6. **`nHostTimeStamp` 单位是 ms，使用 CLOCK_REALTIME**（U5），精度不够，不用作 ROS 时间戳。
> 7. **`ResultingFrameRate` 在真机上等于当前设定的帧率**（设 30 读到 30，设 60 读到 60），不是 [VXML] 说的“最大帧率”（U8）。
> 8. **`AcquisitionFrameRate` 写入后立即读回的值可能不是最新值**（写 30 读到 88.5，但实际帧率已经生效），原因未查明。
> 9. **取流中 `Width`、`PixelFormat` 写入返回 0x80000106；`OffsetX`、`ExposureTime` 可以写入**（U10）。
> 10. **两台相机 60 Hz 同时运行 60 s 无丢帧**：每台约 78.6 MB/s，USB 错误帧 0，SDK 缓存积压 0（U15）。时钟模型残差约 7 µs，相机比主机慢约 5 ppm（U13 初步结果）。
> 11. 虚拟相机：时间戳全为 0，默认像素格式是 RGB8（0x02180014），`SetGrabStrategy` 和流异常回调返回 0x80000021。
>
> 项目整体情况、架构和进度见《海康相机项目交接文档.md》。


> 用途：为 ROS2 组件驱动整理 SDK 事实。场景是两台 MV-CB013-A0UC-S（USB3、全局快门、1280×1024、BayerGB8）自由运行，主机通过软件对时，再用 ApproximateTime 配对。
> 调研日期：2026-11-09。SDK 版本 V4.9.0（本机 `MV_CC_GetSDKVersion`✓ 返回 0x04090003）。
> 开发阶段在虚拟相机 MV-CS016-10UC 上测试，之后迁移到真机。

## 对上述方案影响最大的结论

> 文中 [CN]、[H:…]、[S]、[VXML] 等来源简称，以及 ✓/? 和引号的标注约定，见下一节“0. 资料来源与标注约定”。

1. **USB3 相机的设备时间戳节点在指定资料里完全没有定义。** `"DeviceTimestamp"`、`"DeviceTimestampLatch"`、`"DeviceTimestampIncrement"` 在节点表、全部 HTML 页面、头文件和示例中都查不到；节点表只有 GigE 专用的 `"GevTimestamp*"`。目前唯一的定义来自虚拟相机的 [VXML]：
   - `"DeviceTimestamp"`：64 位无符号只读整数，单位 ns；
   - `"DeviceTimestampLatch"`：命令；
   - `"DeviceTimestampIncrement"`：说明写的是 “Timestamp increment in ns/tick”，**不是“时间戳最大值”**；
   - 执行 Latch 会让 `"DeviceTimestamp"` 的缓存失效（pInvalidator），可见设计上的用法是“先 Latch，再读”；
   - 没有任何清零或复位时间戳的节点。
   
   这些都要在真机上导出 XML 复核（U1、U2、U10）。
2. **帧信息里的时间戳没有任何语义说明。** `MV_FRAME_OUT_INFO_EX.nDevTimeStampHigh`✓ / `nDevTimeStampLow`✓ 只写了“时间戳高/低 32 位”，`MV_FRAME_OUT_INFO_EX.nHostTimeStamp`✓ 只写了“主机生成的时间戳”。单位、对应曝光开始、曝光结束还是读出的时刻、主机用哪个时钟，文档都没有写。所以方案里“设备时间换算成主机时间”和曝光时刻补偿都必须先做实验确定（U3、U4、U5）。在这之前，不能直接把 `nHostTimeStamp`✓ 当作 ROS 时间戳。
3. **SDK 不提供设备时间和主机时间的换算，也没有给出建议做法。** 与对时有关的只有 GigE 专用的 Action Command（`MV_GIGE_IssueActionCommand`✓）。偏移和快慢比例的拟合需要自己写。每次对时要做两次 USB 控制传输：一次 `MV_CC_SetCommandValue`✓（Latch），一次 `MV_CC_GetIntValueEx`✓（读值）。读值前后要各记一次主机时间，并只保留往返时间最短的样本（U12、U13）。
4. **两个组件运行在同一个进程里，由此带来两条硬约束。**
   - 每个进程只能调用一次 `MV_CC_Initialize`✓ 和一次 `MV_CC_Finalize`✓，不能写在每个节点的构造和析构函数里。
   - 设备列表的内存由 SDK 内部分配，文档要求避免多线程同时枚举。本机实测发现：第二次枚举会**覆写**第一次返回的 `MV_CC_DEVICE_INFO`✓ 指针所指的内容。
   
   因此需要一个进程级单例：Initialize 只调用一次，用互斥锁串行化枚举，并在锁内**按值拷贝** `MV_CC_DEVICE_INFO`✓，然后再调用 `MV_CC_CreateHandle`✓。
5. **同一个句柄能否被多个线程同时使用，文档和头文件都没有说明。** 官方示例里有“工作线程循环调用接口，主线程调用 `MV_CC_StopGrabbing`✓”的写法，但这只能算旁证。建议：
   - 取图线程只调用 `MV_CC_GetImageBuffer`✓ 和 `MV_CC_FreeImageBuffer`✓；
   - 其他控制类调用（Latch 加读时间戳、设置曝光等）在每台相机内用一把锁串行化，Latch 和读值必须放在同一个临界区；
   - 上线前先做并发压力实验（U6）。
6. **固定帧率自由运行需要的节点不在节点表里。**
   - 节点表没有 `"AcquisitionFrameRate"`。`"AcquisitionFrameRateEnable"` 只在触发示例里出现过一次，是被设成 false 的。
   - [VXML] 里前者是 Float（单位 Fps，可读写，上下限由设备动态给出），后者是 Boolean。
   - `"ResultingFrameRate"` 在节点表里写的是“相机的实际采集帧率”，[VXML] 写的却是“在当前 ROI、曝光和带宽设置下允许的**最大**帧率”，两者矛盾，需要实测（U8）。
   - 帧率和曝光怎样互相制约，文档没有说明（U9）。
   - `"TriggerMode"` 必须设为 Off。
7. **缓存默认只有 1 个，部分参数在取流期间被锁定。**
   - SDK 内部的图像缓存节点默认只有 1 个（依据：头文件注释、[XLSX] 和 [INI]）。录制时必须在 `MV_CC_StartGrabbing`✓ 之前用 `MV_CC_SetImageNodeNum`✓ 调大，并在用完后及时 Free。
   - 取图策略默认是 OneByOne，适合录制；LatestImagesOnly 适合低延迟推理。
   - 在 [VXML] 中，`"Width"`、`"Height"`、`"PixelFormat"` 等节点在取流期间被锁定；`"ExposureTime"`、`"Gain"`、`"AcquisitionFrameRate"`、`"OffsetX"` 不受取流锁定；`"OffsetY"` 是否锁定取决于设备的能力位。这与“开始前下发 ROI”的方案一致。
8. **有些功能在虚拟相机上测不到，结论必须回到真机上再验证。**
   - `MV_CC_RegisterStreamExceptionCallBack`✓ 明确不支持虚拟相机；[XLSX] 里所有 U3V 传输参数都标注了“虚拟相机不支持”。
   - 本机用 `MV_CC_EnumDevices`✓ 枚举 `MV_USB_DEVICE`✓ 时，虚拟相机的 `MV_CC_DEVICE_INFO.nTLayerType`✓ 返回值就是 `MV_USB_DEVICE`✓，单看这个字段无法和真机区分（虚拟相机的序列号以 “Vir” 开头）。
   - 时间戳、断线、带宽、丢帧相关的结论都必须在 MV-CB013 真机上重新验证。

---

## 0. 资料来源与标注约定

| 简称 | 路径 | 说明 |
|---|---|---|
| [CN] | `/opt/MVS/doc/工业相机Linux SDK开发指南V4.9.0（C）/html/` | 中文开发指南（页面文件名见下表） |
| [EN] | `/opt/MVS/doc/Machine Vision Camera SDK Developer Guide Linux (C) V4.9.0/html/` | 英文版，用于对照；与中文版同名页面内容一致，未发现额外信息 |
| [H:文件名] | `/opt/MVS/include/文件名` | 头文件；“:行号”为本机文件的行号 |
| [S] | `/opt/MVS/Samples/64/C++/` | C++ 示例 |
| [XLSX] | `/opt/MVS/doc/工业相机SDK可配置化参数表.xlsx` | 已转为 CSV 阅读（两个工作表） |
| [README] | `/opt/MVS/Samples/README-CH` | 示例说明 |
| **[VXML]（补充）** | `/opt/MVS/bin/VirtualCamera/MV-CS016-10UC/MV-CS016-10UC.xml` | **不在任务指定的资料范围内。** 这是开发用虚拟相机的 GenICam 描述文件，**不代表 MV-CB013-A0UC-S 真机**。之所以引用，是因为指定资料里查不到 USB3 时间戳和帧率节点 |
| [INI]（补充） | `/opt/MVS/lib/64/CommonParameters.ini` | [XLSX] 所说的配置文件 |
| [RN]（补充） | `/opt/MVS/ReleaseNote_CH.txt` | 发版记录 |
| [脚本]（补充） | `/opt/MVS/bin/set_env_path.sh`、`set_usb_priority.sh`、`set_usbfs_memory_size.sh` | 环境配置页提到的脚本 |
| [本机实测] | 2026-11-09 在本机用第 5 节的 CMake 编译小程序运行 | 只做了初始化、枚举和反初始化，**没有打开相机** |

[CN] 中用到的页面（文件名是 Doxygen 转义后的中文）：

| 页面 | 文件名 |
|---|---|
| 环境配置 | `_xE7_x8E_xAF_xE5_xA2_x83_xE9_x85_x8D_xE7_xBD_xAE.html` |
| 配置开发环境 | `_xE9_x85_x8D_xE7_xBD_xAE_xE5_xBC_x80_xE5_x8F_x91_xE7_x8E_xAF_xE5_xA2_x83.html` |
| 开发前必读 | `_xE5_xBC_x80_xE5_x8F_x91_xE5_x89_x8D_xE5_xBF_x85_xE8_xAF_xBB.html`（流程图为 `MVCC_Process.png`） |
| 初始化SDK | `_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_s_d_k.html` |
| 初始化相机 | `_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE7_x9B_xB8_xE6_x9C_xBA.html` |
| 设置参数 | `_xE8_xAE_xBE_xE7_xBD_xAE_xE5_x8F_x82_xE6_x95_xB0.html` |
| 事件及异常 | `_xE4_xBA_x8B_xE4_xBB_xB6_xE5_x8F_x8A_xE5_xBC_x82_xE5_xB8_xB8.html` |
| 配置缓存 | `_xE9_x85_x8D_xE7_xBD_xAE_xE7_xBC_x93_xE5_xAD_x98.html` |
| 采集图像 | `_xE9_x87_x87_xE9_x9B_x86_xE5_x9B_xBE_xE5_x83_x8F.html` |
| 处理图像 | `_xE5_xA4_x84_xE7_x90_x86_xE5_x9B_xBE_xE5_x83_x8F.html` |
| 相机参数节点表 | `_xE7_x9B_xB8_xE6_x9C_xBA_xE5_x8F_x82_xE6_x95_xB0_xE8_x8A_x82_xE7_x82_xB9_xE8_xA1_xA8.html` |
| 常见问题 | `_xE5_xB8_xB8_xE8_xA7_x81_xE9_x97_xAE_xE9_xA2_x98.html` |
| 发版说明 | `_xE5_x8F_x91_xE7_x89_x88_xE8_xAF_xB4_xE6_x98_x8E.html` |
| 已弃用列表 | `deprecated.html` |
| 废弃接口（API 分组） | `group___xE5_xBA_x9F_xE5_xBC_x83_xE6_x8E_xA5_xE5_x8F_xA3.html` |
| 图像采集（API 分组） | `group___xE5_x9B_xBE_xE5_x83_x8F_xE9_x87_x87_xE9_x9B_x86.html` |
| MV_FRAME_OUT_INFO_EX 结构体 | `struct_m_v___f_r_a_m_e___o_u_t___i_n_f_o___e_x.html` |

标注约定：

- 反引号里不带引号的 C 标识符（函数、结构体、字段、宏、枚举值），例如 `MV_CC_GetImageBuffer`✓、`MV_FRAME_OUT_INFO_EX.nFrameNum`✓，后面的 ✓/? 由脚本在 `/opt/MVS/include` 中核对得出（规则见文末“名称核对”）。
- 带双引号的 `"ExposureTime"` 是 GenICam **节点名**（传给 SDK 的字符串），不是头文件里的标识符，不做 ✓/? 标注。
- 标记为 c 语言的代码块中抄写的原型和字段逐行与头文件比对，比对时忽略空白和注释，结果标在行尾。
- “**文档未说明**”的意思是：在 [CN] 和 [EN] 全部页面、`/opt/MVS/include` 和 [S] 中都没有找到相关内容。
- “**建议**”是我的工程判断，不是文档内容。

---

## P0 时间同步

### 1. 设备时间戳相关节点

来源：[CN] 相机参数节点表；在 [CN]、[EN]、`/opt/MVS/include`、`/opt/MVS/Samples` 中全文检索 “DeviceTimestamp” 和 “Timestamp”；[VXML] 第 2412–2466 行。

**指定资料中的结论**

- `"DeviceTimestamp"`、`"DeviceTimestampLatch"`、`"DeviceTimestampIncrement"`：**文档未说明**，三个名字在指定资料中都没有出现。
- 节点表里与时间戳有关的只有 Transport Layer Control 分类下的 GigE 节点：

| 节点 | 类型 | 访问 | 范围 | 描述（节点表原文） |
|---|---|---|---|---|
| `"GevTimestampTickFrequency"` | IInteger | R | ≥0，单位 Hz | 时间戳频率 |
| `"GevTimestampControlLatch"` | ICommand | W | – | 获取时间戳 |
| `"GevTimestampControlReset"` | ICommand | W | – | 复位时间戳 |
| `"GevTimestampControlLatchReset"` | ICommand | W | – | 复位时间戳同时获取时间戳 |
| `"GevTimestampValue"` | IInteger | R | – | 时间戳值 |

  节点表没有说明 USB3 相机是否提供这些节点；[VXML] 里没有任何 `Gev*Timestamp*` 节点。

**补充：[VXML] 中的定义（虚拟相机 MV-CS016-10UC，不等于真机）**

| 节点 | 类型 | 访问 | 单位 | ToolTip 原文 | 底层寄存器 |
|---|---|---|---|---|---|
| `"DeviceTimestamp"` | Integer | RO | ns | Current device time in ns. | 地址 0x01F0，8 字节，无符号，小端；pInvalidator 为 TimestampLatch_Reg 和 UserSetLoad_Reg |
| `"DeviceTimestampLatch"` | Command | （写） | CommandValue=2 | Timestamp Latch. | 地址 0x01F8，4 字节，只写 |
| `"DeviceTimestampIncrement"` | Integer | ImposedAccessMode 为 RW，但寄存器是 RO，实际只读 | ns/tick | Timestamp increment in ns/tick. | 地址 0x01FC，8 字节，无符号 |

三个节点的 pIsImplemented 都指向设备能力位 TimestampSupported_Inq，也就是说设备可能不实现这些节点。

**a. 准确含义**

- `"DeviceTimestamp"`：[VXML] 说明为“当前设备时间（ns）”。
- `"DeviceTimestampLatch"`：[VXML] 中是锁存命令，写入 Latch 寄存器。
- `"DeviceTimestampIncrement"`：[VXML] 说明为“每个 tick 对应多少 ns”。
- **对“DeviceTimestampIncrement 是设备时间戳的最大值”的核实**：用户手册不在指定资料里，无法对照原文。指定资料对这个节点没有任何说明。[VXML] 的 ToolTip 和单位都表明它是 **ns/tick（时钟分辨率）**，和“最大值”的解释不符。以 [VXML] 为准，“最大值”的说法不成立，但仍需用真机 XML 复核（U10）。
- 存疑：`"DeviceTimestamp"` 标注的单位是 ns，同时又存在一个 ns/tick 的 Increment。XML 没有说明 `"DeviceTimestamp"` 读出来的是换算后的 ns，还是原始 tick 计数（两种读法只有在 Increment=1 时才没有区别），见 U1。

**b. 能否设置或清零相机时钟**

- 指定资料：没有适用于 USB3 的节点，只有 GigE 的 `"GevTimestampControlReset"` 和 `"GevTimestampControlLatchReset"`。
- [VXML]：名字里含 “Timestamp” 的节点只有 `"DeviceTimestamp"`、`"DeviceTimestampIncrement"`、`"DeviceTimestampLatch"`、`"Timestamp"`（水印选择器的一个选项）和一组 `"Event*Timestamp"`（事件数据）。**没有** `*TimestampReset` 或 `*TimestampControl*` 节点。
- `"DeviceReset"`（节点表：ICommand、W、重启设备）会不会清零时间戳，**文档未说明**（U14）。
- 对方案的影响：设备时钟只能读、不能设置，拟合模型必须能处理任意的初始偏移。

**c. 表示时间戳频率或单位的节点**

- 指定资料：只有 GigE 的 `"GevTimestampTickFrequency"`（Hz）。USB3 相机**文档未说明**。
- [VXML]：没有频率节点，唯一相关的是 `"DeviceTimestampIncrement"`（ns/tick）。由它推算，频率 = 1e9 / Increment Hz。

**d. 取流中执行 Latch、锁存值从哪里读、位数与回绕**

- 能否在取流过程中执行 Latch：**文档未说明**。在 [VXML] 中，`"DeviceTimestampLatch"` 没有 pIsLocked，不受 TLParamsLocked（取流期间为 1）约束，所以在 XML 层面是允许的。真机行为需要实测（U2）。
- 锁存值从哪个节点读：**文档未说明**。[VXML] 中没有单独的 LatchValue 节点，而 Latch 寄存器是 `"DeviceTimestamp"` 寄存器的 pInvalidator，所以执行 Latch 后用 `MV_CC_GetIntValueEx`✓ 读 `"DeviceTimestamp"`，就会拿到重新读取的值。XML 没有声明 Cachable 或 PollingTime；不执行 Latch 而直接重复读，会不会读到旧的缓存值，文档也没有说明（U2）。SDK 提供了 `MV_CC_InvalidateNodes`✓ 来清除 GenICam 节点缓存（[H:MvCameraControl.h]:1636–1647）。
- 位数：[VXML] 中的寄存器是 8 字节无符号数，即 64 位。SDK 通过 `MVCC_INTVALUE_EX.nCurValue`✓ 返回，类型是有符号的 `int64_t`✓。
- 是否会回绕：**文档未说明**。可以计算：如果是 64 位 ns 计数，2^64 ns ≈ 584 年，实际上不会回绕；如果是 tick 计数，回绕周期是 2^64 × Increment ns，同样极长。帧信息中的设备时间戳被拆成两个 32 位无符号数，拼接时要用 `uint64_t`✓：`((uint64_t)High << 32) | Low`。示例里拼接事件时间戳也用的是这种写法（[S]`General/Events/Events.cpp`:87–88）。

### 2. 帧信息结构体

来源：[H:CameraParams.h]:436–525；[CN] MV_FRAME_OUT_INFO_EX 结构体页（逐字段与头文件一致，没有额外说明）；[S]`General/ChunkData/ChunkData.cpp`:103–112。

```c
typedef struct _MV_FRAME_OUT_INFO_EX_  // ✓
{
    unsigned short nWidth;                 // 图像宽(最大65535，超出请用nExtendWidth) ✓
    unsigned short nHeight;                // 图像高(最大65535，超出请用nExtendHeight) ✓
    enum MvGvspPixelType enPixelType;      // 像素格式 ✓
    unsigned int nFrameNum;                // 帧号 ✓
    unsigned int nDevTimeStampHigh;        // 时间戳高32位 ✓
    unsigned int nDevTimeStampLow;         // 时间戳低32位 ✓
    unsigned int nReserved0;               // 保留，8字节对齐 ✓
    int64_t nHostTimeStamp;                // 主机生成的时间戳 ✓
    unsigned int nFrameLen;                // 帧的长度(4GB以上图像使用nFrameLenEx替代) ✓
    unsigned int nSecondCount;             // 设备水印时标：秒数 ✓
    unsigned int nCycleCount;              // 周期数 ✓
    unsigned int nCycleOffset;             // 周期偏移量 ✓
    float fGain;                           // 增益 ✓
    float fExposureTime;                   // 曝光时间 ✓
    unsigned int nAverageBrightness;       // 平均亮度 ✓
    unsigned int nRed;                     // 白平衡：红色 ✓
    unsigned int nGreen;                   // 绿色 ✓
    unsigned int nBlue;                    // 蓝色 ✓
    unsigned int nFrameCounter;            // 总帧数 ✓
    unsigned int nTriggerIndex;            // 触发计数 ✓
    unsigned int nInput;                   // 输入 ✓
    unsigned int nOutput;                  // 输出 ✓
    unsigned short nOffsetX;               // ROI：水平偏移量 ✓
    unsigned short nOffsetY;               // 垂直偏移量 ✓
    unsigned short nChunkWidth;            // Chunk宽 ✓
    unsigned short nChunkHeight;           // Chunk高 ✓
    unsigned int nLostPacket;              // 本帧丢包数 ✓
    unsigned int nUnparsedChunkNum;        // 未解析的Chunkdata个数 ✓
    union
    {
        MV_CHUNK_DATA_CONTENT* pUnparsedChunkContent;   // 未解析的Chunk ✓
        int64_t nAligning;  // ✓
    }UnparsedChunkList;  // ✓
    unsigned int nExtendWidth;             // 图像宽(扩展变量) ✓
    unsigned int nExtendHeight;            // 图像高(扩展变量) ✓
    uint64_t nFrameLenEx;                  // 帧的长度 ✓
    unsigned int nExtraType;               // 额外信息类型：子图还是多图 ✓
    unsigned int nSubImageNum;             // 子图(多图)个数 ✓
    union
    {
        MV_CC_IMAGE* pstSubImage;  // ✓
        MV_GIGE_MULTI_PART_INFO* pstPartInfo;  // ✓
        int64_t nAligning;  // ✓
    } SubImageList;  // ✓
    union
    {
        void* pUser;                       // 外部注册缓存时对应的用户指针 ✓
        int64_t nAligning;  // ✓
    }UserPtr;  // ✓
    unsigned int nFirstLineEncoderCount;   // 首行编码器计数 ✓
    unsigned int nLastLineEncoderCount;    // 尾行编码器计数 ✓
    unsigned int nLastFrameFlag;           // 电平结束时的最后一帧 ✓
    unsigned int nReserved[23];            // 预留 ✓
}MV_FRAME_OUT_INFO_EX;  // ✓

typedef struct _MV_FRAME_OUT_  // ✓
{
    unsigned char* pBufAddr;               // 图像指针地址 ✓
    MV_FRAME_OUT_INFO_EX stFrameInfo;      // 图像信息 ✓
    unsigned int nRes[16];                 // 预留 ✓
}MV_FRAME_OUT;  // ✓
```

**a. 设备时间戳的单位和对应时刻**

**文档未说明。** 结构体页和头文件只写了“时间戳高32位/低32位”。[VXML] 中 `"FrameSpecInfoSelector"` 有一个 Timestamp 水印选项，但文档没有说明以下几点：

- `nDevTimeStampHigh`✓/`nDevTimeStampLow`✓ 是来自 U3V 流协议头还是来自水印；
- 它和 `"DeviceTimestamp"` 是否是同一个时钟（U3）；
- 它对应曝光开始、曝光结束、读出开始还是其他时刻（U4）。

**b. 主机时间戳**

`MV_FRAME_OUT_INFO_EX.nHostTimeStamp`✓ 的类型是 `int64_t`✓，说明只有“主机生成的时间戳”。在什么时刻打上、使用哪种系统时钟、单位是什么，**文档都未说明**（U5）。[XLSX] 中的 SetTimeFlag（设置系统时钟精度）只支持 Windows，在 Linux 下无效。

**c. 帧号、丢包和其他时间相关字段**

| 字段 | 头文件说明 | 补充 |
|---|---|---|
| `MV_FRAME_OUT_INFO_EX.nFrameNum`✓ | 帧号（32 位） | [CN] 常见问题提到：USB 流链路受 EMC 干扰时会“流链路重置，帧号重置”。所以不能只靠帧号连续来判断丢帧或配对 |
| `MV_FRAME_OUT_INFO_EX.nFrameCounter`✓ | 总帧数 | 位于水印相关字段之间；是否要开启 `"FrameSpecInfo"` 水印才会填充，文档未说明 |
| `MV_FRAME_OUT_INFO_EX.nTriggerIndex`✓ | 触发计数 | 同上。自由运行模式下的取值，文档未说明 |
| `MV_FRAME_OUT_INFO_EX.nLostPacket`✓ | 本帧丢包数 | 常见问题在 HB 解码条目中用它判断丢包 |
| `MV_FRAME_OUT_INFO_EX.nSecondCount`✓ / `nCycleCount`✓ / `nCycleOffset`✓ | 设备水印时标：秒数、周期数、周期偏移量 | 含义和单位文档未说明。ChunkData 示例开启 `"ChunkSelector"`=Timestamp 后会打印这三个字段 |
| `MV_FRAME_OUT_INFO_EX.fExposureTime`✓ / `fGain`✓ / `nAverageBrightness`✓ | 曝光、增益、平均亮度 | 水印信息，是否填充取决于水印设置（文档未说明） |
| `MV_FRAME_OUT_INFO_EX.nLastFrameFlag`✓ | 电平结束时的最后一帧 | 与触发有关 |

除帧号外，其他检测丢帧的手段：

- `MV_CC_GetAllMatchInfo`✓ 配合 `MV_MATCH_TYPE_USB_DETECT`✓，可以得到 `MV_MATCH_INFO_USB_DETECT.nReceivedFrameCount`✓ 和 `MV_MATCH_INFO_USB_DETECT.nErrorFrameCount`✓。这个接口要在打开设备之后调用（[H:MvCameraControl.h]:543–565）。
- 流异常回调中的 `MV_CC_STREAM_EXCEPTION_LIST_OVERFLOW`✓（缓存列表已满）。
- 用 `MV_CC_GetValidImageNum`✓ 查看缓存中积压的帧数。
- [VXML] 中的 `"TransferQueueOverFlowCount"`（相机端传输队列溢出计数，只读）。

### 3. SDK 是否提供设备时间到主机时间的换算

来源：在 [CN]、[EN]、`/opt/MVS/include` 和 [S] 中全文检索 PTP、1588、时钟同步、对时、CLOCK_ 等关键词。

- **文档未说明**：SDK 没有现成的换算接口，也没有给出建议做法。
- 唯一相关的是 GigE 的 `MV_GIGE_IssueActionCommand`✓。它的 `MV_ACTION_CMD_INFO.nActionTime`✓ 字段注释为“和相机主频有关，与相机时间戳处于同一时间域”（[H:CameraParams.h]:1176），对应示例是 Grab_ActionCommand（“通过PTP时钟协议对相机进行采图”）。这些只适用于 GigE，对 USB3 不适用。
- **建议做法**（不是文档内容）：
  1. 主机端用 `CLOCK_MONOTONIC` 记时，以免受 NTP 跳变影响。
  2. 每次对时都在同一个临界区里完成：先记主机时间 t0，执行 `"DeviceTimestampLatch"`，读 `"DeviceTimestamp"` 得到 d，再记主机时间 t1。这样得到一个样本：(d, (t0+t1)/2, rtt=t1−t0)。
  3. 在滑动窗口里只保留 rtt 最小的一批样本，拟合 host = a + b·dev，其中 b 就是两个时钟的快慢比例。
  4. 每帧的主机时间 = a + b·dev_frame，再根据 U4 的结论减去曝光时刻偏移。
  5. 两个节点在同一个进程里，用同一个进程级偏移把 `CLOCK_MONOTONIC` 换算到 ROS 时间，保证 ApproximateTime 两路的时间基一致。

### 4. 固定帧率自由运行

来源：[CN] 相机参数节点表；[S]`AreaScanCamera/Trigger_ImageCallback/Trigger_ImageCallback.cpp`:211、`AreaScanCamera/Trigger_Image/Trigger_Image.cpp`；[S]`General/GrabImage_HighPerformance/GrabImage_HighPerformance.cpp`:210；[CN] 处理图像（录像一节）；[VXML]。

**指定资料中的节点**

| 节点 | 节点表定义 | 用途 |
|---|---|---|
| `"TriggerMode"` | IEnumeration，0:Off / 1:On，R/W | 自由运行时设为 Off。示例：`MV_CC_SetEnumValue`✓(handle, "TriggerMode", 0) |
| `"AcquisitionMode"` | IEnumeration，0:SingleFrame / 1:MultiFrame / 2:Continuous，R/(W) | 设为 Continuous |
| `"ResultingFrameRate"` | IFloat，≥0.0，单位 fps，R，“相机的实际采集帧率” | 录像示例用 `MV_CC_GetFloatValue`✓ 读它作为录像帧率 |
| `"AcquisitionFrameRate"` | **不在节点表中，指定资料里零命中，文档未说明** | |
| `"AcquisitionFrameRateEnable"` | **不在节点表中**，只在两个触发示例里出现：`MV_CC_SetBoolValue`✓(handle, "AcquisitionFrameRateEnable", false)，即进入触发模式前关闭帧率控制 | 由此可知它是 Boolean |

**补充：[VXML] 中的定义**

| 节点 | 类型 | 访问 | 说明 |
|---|---|---|---|
| `"AcquisitionFrameRate"` | Float | RW，无 pIsLocked，取流中也可写 | 单位 Fps；pMin 和 pMax 来自设备寄存器 AcqFrameRateMinInq / AcqFrameRateMaxInq，会随其他设置动态变化；“Controls the acquisition rate at which the frames are captured.” |
| `"AcquisitionFrameRateEnable"` | Boolean | RW | “Enables manual control of the camera frame rate.” |
| `"ResultingFrameRate"` | Float | 只读 | “Indicates the maximum allowed frame acquisition rate (in frames per second) given the current settings for the area of interest, exposure time, and bandwidth” |

- **实际帧率从哪里读**：节点表说是 `"ResultingFrameRate"`，但 [VXML] 把它定义为“当前设置下允许的最大值”，两者矛盾（U8）。建议用连续帧设备时间戳的差值统计实际帧率。
- **帧率和曝光的制约关系**：**文档未说明**。[VXML] 对 `"ResultingFrameRate"` 的说明表明它受 ROI、曝光时间和带宽共同影响，`"AcquisitionFrameRate"` 的上限也由设备动态给出（U9）。带宽限制节点见第 13 项。
- **建议的下发顺序**：
  1. `"TriggerMode"` 设为 Off，`"AcquisitionMode"` 设为 Continuous；
  2. 设置 ROI 和 `"PixelFormat"`；
  3. 设置 `"ExposureTime"`；
  4. `"AcquisitionFrameRateEnable"` 设为 true，`"AcquisitionFrameRate"` 设为 60；
  5. 回读 `"AcquisitionFrameRate"` 的当前值和最大值（`MVCC_FLOATVALUE.fMax`✓），以及 `"ResultingFrameRate"`。如果最大值小于 60，说明受到曝光、ROI 或带宽的限制。
- 已废弃的 `MV_CC_SetFrameRate`✓ / `MV_CC_GetFrameRate`✓（[H:MvObsoleteInterfaces.h]:800–836）的注释没有写明它们操作的是哪个节点。

---

## P1 程序结构

### 5. 开发环境

来源：[CN] 配置开发环境、环境配置、常见问题（编译报错条目）；[README]；[S]`General/GrabImage_HighPerformance/Makefile`；[脚本] `set_env_path.sh`；[本机实测]。

- **头文件**：`/opt/MVS/include`。只需包含 `MvCameraControl.h`，它会自动包含 `MvErrorDefine.h`、`CameraParams.h` 和 `MvObsoleteInterfaces.h`（[H:MvCameraControl.h]:5–7）。
- **库**：x86_64 用 `/opt/MVS/lib/64`，链接 `-lMvCameraControl -lpthread`（见示例 Makefile）。gcc/g++ 要求 4.8.5 及以上（x86_64 平台）。
- **环境变量**：
  - [README] 要求 `$LD_LIBRARY_PATH` 和 `$MVCAM_COMMON_RUNENV` 生效。
  - `set_env_path.sh` 会导出 `$MVCAM_SDK_PATH`、`$MVCAM_COMMON_RUNENV`（值为 …/lib）、`$MVCAM_SOFTWARE_LIBENV`、`$MVCAM_GENICAM_CLPROTOCOL`，并把 …/lib/64 和 …/lib/32 加进 `$LD_LIBRARY_PATH`，同时写入 `~/.bashrc`、`~/.profile` 和 `/etc/profile`。
  - 本机当前值：`$MVCAM_COMMON_RUNENV`=/opt/MVS/lib，`$LD_LIBRARY_PATH`=/opt/MVS/lib/64:/opt/MVS/lib/32:…
- **[本机实测]**：用下面的 CMake 编译出的程序带 RUNPATH=/opt/MVS/lib/64。即使 unset `$LD_LIBRARY_PATH` 和全部 `$MVCAM_*` 变量，程序仍能正常完成初始化、枚举和反初始化。注意：**只测到枚举**，没有测打开相机和取流时动态加载传输层库的情况。
- 示例 Makefile（原文）：

```text
Demo: GrabImage_HighPerformance.cpp
	g++ -g -o GrabImage_HighPerformance GrabImage_HighPerformance.cpp -I../../../../../include -Wl,-rpath=$(MVCAM_COMMON_RUNENV)/64 -L$(MVCAM_COMMON_RUNENV)/64 -lMvCameraControl -lpthread
```

- 等价的 CMake 写法（已在本机用 CMake 3.22.1 编译并运行通过）：

```cmake
cmake_minimum_required(VERSION 3.18)          # find_library(... REQUIRED) 需要 3.18+
project(hik_camera CXX)

# MVS 安装根目录：优先用 set_env_path.sh 导出的 MVCAM_SDK_PATH，否则默认 /opt/MVS
if(DEFINED ENV{MVCAM_SDK_PATH})
  set(MVS_ROOT "$ENV{MVCAM_SDK_PATH}" CACHE PATH "MVS install root")
else()
  set(MVS_ROOT "/opt/MVS" CACHE PATH "MVS install root")
endif()
set(MVS_LIB_DIR "${MVS_ROOT}/lib/64")         # = $(MVCAM_COMMON_RUNENV)/64

find_library(MVCAMERACONTROL_LIB NAMES MvCameraControl
             PATHS "${MVS_LIB_DIR}" NO_DEFAULT_PATH REQUIRED)
add_library(mvs::MvCameraControl SHARED IMPORTED)
set_target_properties(mvs::MvCameraControl PROPERTIES
  IMPORTED_LOCATION "${MVCAMERACONTROL_LIB}"                 # = -L... -lMvCameraControl
  INTERFACE_INCLUDE_DIRECTORIES "${MVS_ROOT}/include")       # = -I.../include

find_package(Threads REQUIRED)                               # = -lpthread

add_executable(grab_demo src/grab_demo.cpp)
target_link_libraries(grab_demo PRIVATE mvs::MvCameraControl Threads::Threads)
set_target_properties(grab_demo PROPERTIES
  BUILD_RPATH   "${MVS_LIB_DIR}"                             # = -Wl,-rpath=...
  INSTALL_RPATH "${MVS_LIB_DIR}")                            # colcon install 后仍能找到库
```

  这里的 `-g` 对应 `-DCMAKE_BUILD_TYPE=Debug`。在 ROS2 的 ament_cmake 包里用法相同，只是要把可执行文件换成组件库，并保留 INSTALL_RPATH。我只在普通 CMake 工程中验证过，**没有在 colcon 下验证**。
- 其他注意事项：
  - `/opt/MVS/lib/64` 自带一份 `libusb-1.0.so.0`。常见问题提到 libusb 版本冲突会导致打不开相机，可以用 `ldd libMvUsb3vTL.so` 检查实际加载的 libusb。
  - `MV_CC_CreateHandle`✓ 默认会生成 SDK 日志文件；不需要时可以把日志配置文件中的日志等级改为 off（[H:MvCameraControl.h]:451–467）。

### 6. “开发前必读”中的规则

来源：[CN] 开发前必读和 `MVCC_Process.png`；[EN] 同名页（内容相同）；其余来源列在下表中。

这一页只有三部分：**相机调用流程**（一张流程图）、**采集卡调用流程**、**错误处理和错误码**。页面上**没有关于多线程的任何规则**。

- **错误处理**：接口返回 int 型状态码，`MV_OK`✓=0x00000000 表示成功，建议用 “0x%x” 格式打印。页面举的例子是：相机已经被第三方软件连接时，`MV_CC_OpenDevice`✓ 返回 0x80000203（`MV_E_ACCESS_DENIED`✓，设备无访问权限）。

**a. 调用顺序的限制**

流程图给出的顺序：

1. `MV_CC_Initialize`✓
2. 初始化相机：`MV_CC_EnumDevices`✓ → `MV_CC_CreateHandle`✓ → `MV_CC_OpenDevice`✓
3. 参数设置（`MV_CC_SetIntValueEx`✓、`MV_CC_SetFloatValue`✓ 等）
4. 采集和处理图像，可选内部缓存或外部缓存，两种取图方式二选一：
   - 回调取图：`MV_CC_RegisterImageCallBackEx2`✓ 或 `MV_CC_RegisterImageCallBackEx`✓ → `MV_CC_StartGrabbing`✓ → 回调中处理
   - 轮询取图：`MV_CC_StartGrabbing`✓ → 创建取流线程 → 循环执行 `MV_CC_GetImageBuffer`✓、处理、`MV_CC_FreeImageBuffer`✓ → **退出线程**
5. 结束：`MV_CC_StopGrabbing`✓ → `MV_CC_CloseDevice`✓ → `MV_CC_DestroyHandle`✓ → `MV_CC_Finalize`✓

注意轮询取图分支中“退出线程”画在“停止取流”之前。

分散在其他页面和头文件中的顺序约束：

| 约束 | 来源 |
|---|---|
| 每个进程只能各执行一次 `MV_CC_Initialize`✓ 和 `MV_CC_Finalize`✓ | [CN] 初始化SDK |
| 避免多线程同时枚举，因为设备列表内存由 SDK 内部分配 | [CN] 初始化相机；[H:MvCameraControl.h]:292 |
| `MV_CC_SetImageNodeNum`✓ 必须在 `MV_CC_StartGrabbing`✓ 之前调用 | [CN] 配置缓存；[H:MvCameraControl.h]:798–818 |
| 外部缓存必须在 `MV_CC_StartGrabbing`✓ 之前注册，否则使用内部缓存；开始取流后也可以继续注册或取消注册 | [CN] 配置缓存 |
| 修改宽、高、像素格式后，需要重新调用 `MV_CC_GetPayloadSize`✓ | [CN] 配置缓存 |
| 图像回调在 `MV_CC_CreateHandle`✓ 之后就可以注册；回调取图和轮询取图不能同时使用 | [CN] 采集图像；[H:MvCameraControl.h]:603–657 |
| `MV_CC_RegisterExceptionCallBack`✓ 要在 `MV_CC_OpenDevice`✓ 之后调用 | [H:MvCameraControl.h]:1803–1825 |
| 需要取流才能产生的事件，必须先订阅并开启，再调用 `MV_CC_StartGrabbing`✓ | [CN] 事件及异常 |
| 流异常回调中不能调用 `MV_CC_StopGrabbing`✓、`MV_CC_CloseDevice`✓ 或 `MV_CC_DestroyHandle`✓ | [H:MvCameraControl.h]:1872–1890 |
| 建议在取流前调用 `MV_CC_GetDeviceInfo`✓（对 GigE 设备有阻塞风险） | [H:MvCameraControl.h]:524–540 |
| USB 设备的 `MV_CC_GetAllMatchInfo`✓ 要在打开设备之后调用 | [H:MvCameraControl.h]:543–565 |
| U3V 设备不能不枚举就直接打开（只有网口设备可以） | [H:MvCameraControl.h]:470–507 |

**b. 同一个相机句柄能否被多个线程同时使用**

**文档未说明。** [CN] 和 [EN] 全部页面以及三个主要头文件中，关于多线程的说明只有“避免多线程枚举”，并没有说明同一个句柄能否被多个线程并发调用。具体到你问的场景——一个线程阻塞在 `MV_CC_GetImageBuffer`✓ 里等图，另一个线程执行 Latch、读时间戳或设置曝光——是否安全，**没有任何文档依据**。

旁证（只能说明官方示例这样写过，不能证明安全）：

- [S]`AreaScanCamera/Trigger_ImageCallback/Trigger_ImageCallback.cpp`：SDK 的回调线程在交付图像，同时工作线程循环调用 `MV_CC_SetCommandValue`✓(…, "TriggerSoftware")，主线程最后再调用 `MV_CC_StopGrabbing`✓。这里同一个句柄同时被至少三个线程使用。
- [S]`General/GrabImage_HighPerformance/GrabImage_HighPerformance.cpp`:85–120、225–262：工作线程用 1000 ms 超时循环调用 `MV_CC_GetImageBuffer`✓；主线程把退出标志置位，`sleep(1)` 之后直接调用 `MV_CC_StopGrabbing`✓，**没有 join 工作线程**。
- [RN] 某个版本记录过“修复多线程枚举、开启相机时概率性崩溃问题”，说明 SDK 内部存在多线程相关的缺陷修复史。

**建议**：

- 每台相机一个取图线程，只调用 `MV_CC_GetImageBuffer`✓ 和 `MV_CC_FreeImageBuffer`✓。
- 其他调用（Latch 加读值、设置曝光和增益、读温度等）都经过同一把每相机互斥锁。
- Latch 和读值必须放在同一个临界区内，否则两个线程交错执行时，读到的值可能对应别人的 Latch。
- 在锁的保护下，控制调用与阻塞中的 `MV_CC_GetImageBuffer`✓ 仍然是并发的。这一点没有文档依据，需要用 U6 的压力实验确认。

### 7. SDK 初始化和反初始化

来源：[CN] 初始化SDK；[H:MvCameraControl.h]:210–261。

```c
int __stdcall MV_CC_Initialize();          // 初始化SDK ✓
int __stdcall MV_CC_Finalize();            // 反初始化SDK，释放资源；main函数退出前调用 ✓
unsigned int __stdcall MV_CC_GetSDKVersion();   // 返回4字节版本号 主.次.修正.测试 ✓
```

- 调用时机：进程启动后、调用任何其他接口之前调用 `MV_CC_Initialize`✓（它会预先申请所需的系统资源）；进程退出前调用 `MV_CC_Finalize`✓。**每个进程只能各执行一次。**
- `MV_CC_GetSDKVersion`✓ 在初始化之前就可以调用（[H:MvCameraControl.h]:245–261）。
- **建议（组件容器场景）**：如果用引用计数“最后一个节点析构时调用 Finalize”，那么之后再加载组件时就会第二次调用 Initialize，违反“只能各一次”的规定。更稳妥的做法是：用 `std::call_once` 懒初始化，在进程退出时（例如静态对象析构或 atexit 中）调用 Finalize。至于在静态析构阶段调用 Finalize 是否安全（SDK 内部线程的退出顺序），**文档未说明**，需要在 U6 中一并测试。

### 8. 枚举和打开相机

来源：[CN] 初始化相机；[H:MvCameraControl.h]:273–600；[H:CameraParams.h]:14–216、315–321；[S]`General/ReconnectDemo/ReconnectDemo.cpp`、`General/ConnectSpecCamera/ConnectSpecCamera.cpp`；[本机实测]。

```c
int __stdcall MV_CC_EnumDevices(IN unsigned int nTLayerType, IN OUT MV_CC_DEVICE_INFO_LIST* pstDevList);  // ✓
int __stdcall MV_CC_EnumDevicesEx(IN unsigned int nTLayerType, IN OUT MV_CC_DEVICE_INFO_LIST* pstDevList, IN const char* strManufacturerName);  // ✓
int __stdcall MV_CC_EnumDevicesEx2(IN unsigned int nTLayerType, IN OUT MV_CC_DEVICE_INFO_LIST* pstDevList, IN const char* strManufacturerName, IN MV_SORT_METHOD enSortMethod);  // ✓
bool __stdcall MV_CC_IsDeviceAccessible(IN MV_CC_DEVICE_INFO* pstDevInfo, IN unsigned int nAccessMode);  // ✓
int __stdcall MV_CC_CreateHandle(IN OUT void ** handle, IN const MV_CC_DEVICE_INFO* pstDevInfo);  // ✓
int __stdcall MV_CC_OpenDevice(IN void* handle, IN unsigned int nAccessMode = MV_ACCESS_Exclusive, IN unsigned short nSwitchoverKey = 0);   // C++ 版本带默认参数 ✓
bool __stdcall MV_CC_IsDeviceConnected(IN void* handle);  // ✓
int __stdcall MV_CC_GetDeviceInfo(IN void * handle, IN OUT MV_CC_DEVICE_INFO* pstDevInfo);  // ✓
int __stdcall MV_CC_CloseDevice(IN void* handle);  // ✓
int __stdcall MV_CC_DestroyHandle(IN void * handle);  // ✓

typedef enum _MV_SORT_METHOD_  // ✓
{
    SortMethod_SerialNumber = 0,           // 按序列号排序 ✓
    SortMethod_UserID = 1,                 // 按用户自定义名字排序 ✓
    SortMethod_CurrentIP_ASC = 2,          // 仅GigE ✓
    SortMethod_CurrentIP_DESC = 3,         // 仅GigE ✓
}MV_SORT_METHOD;  // ✓
```

**a. 设备类型标志，以及如何枚举到虚拟相机**

宏定义见第 14 项。头文件的说法（[H:MvCameraControl.h]:273–395）：

- `MV_CC_EnumDevices`✓ 和 `MV_CC_EnumDevicesEx`✓ 传入 `MV_USB_DEVICE`✓ 时，“传出所有USB3 Vision设备，包含虚拟USB3 Vision设备”。
- `MV_CC_EnumDevicesEx2`✓ 严格按类型枚举，传入 `MV_USB_DEVICE`✓ 时“仅枚举USB口相机”。

[本机实测]：本机已有两台虚拟 MV-CS016-10UC，序列号分别为 Vir21217369 和 Vir21217440，User ID 已设置为 left 和 right。

| 调用 | 结果 | 返回的 `nTLayerType`✓ |
|---|---|---|
| `MV_CC_EnumDevices`✓(`MV_USB_DEVICE`✓) | 2 台 | 0x4（`MV_USB_DEVICE`✓） |
| `MV_CC_EnumDevices`✓(`MV_VIR_USB_DEVICE`✓) | 2 台 | 0x4 |
| `MV_CC_EnumDevicesEx2`✓(`MV_USB_DEVICE`✓) | **0 台** | – |
| `MV_CC_EnumDevicesEx2`✓(`MV_VIR_USB_DEVICE`✓) | 2 台 | 0x20（`MV_VIR_USB_DEVICE`✓） |
| `MV_CC_EnumDevicesEx2`✓(`MV_USB_DEVICE`✓ \| `MV_VIR_USB_DEVICE`✓) | 2 台 | 0x20 |

- 结论：用 `MV_CC_EnumDevices`✓(`MV_USB_DEVICE`✓) 可以同时覆盖真机和虚拟相机，开发阶段和真机阶段可以用同一份代码。不过同一台虚拟相机经过不同接口枚举时，`nTLayerType`✓ 会不同（0x4 或 0x20）。所以读取 `SpecialInfo.stUsb3VInfo`✓ 前，不要只判断 `nTLayerType == MV_USB_DEVICE`，两种值都要接受。本机实测，在 0x20 的情况下 `stUsb3VInfo`✓ 中的序列号和 User ID 也是有效的。
- **[本机实测] 枚举结果会被下一次枚举覆写**：第一次枚举返回的 `MV_CC_DEVICE_INFO_LIST.pDeviceInfo`✓ 指针，在第二次和第三次枚举后仍指向同一个地址，但内容已经变成新一次枚举的结果（`nTLayerType`✓ 从 0x4 变成 0x20，又变回 0x4）。所以必须在枚举后立刻**按值拷贝** `MV_CC_DEVICE_INFO`✓，并在两个组件之间用进程级锁串行化“枚举、拷贝”这个过程。

**b. 序列号和 User ID 所在的字段**

```c
typedef struct _MV_CC_DEVICE_INFO_  // ✓
{
    unsigned short nMajorVer;  // ✓
    unsigned short nMinorVer;  // ✓
    unsigned int nMacAddrHigh;  // ✓
    unsigned int nMacAddrLow;  // ✓
    unsigned int nTLayerType;              // 设备传输层协议类型 ✓
    unsigned int nDevTypeInfo;             // 设备类型信息 ✓
    unsigned int nReserved[3];  // ✓
    union
    {
        MV_GIGE_DEVICE_INFO stGigEInfo;  // ✓
        MV_USB3_DEVICE_INFO stUsb3VInfo;   // USB3 Vision设备信息 ✓
        MV_CamL_DEV_INFO stCamLInfo;  // ✓
        MV_CML_DEVICE_INFO stCMLInfo;  // ✓
        MV_CXP_DEVICE_INFO stCXPInfo;  // ✓
        MV_XOF_DEVICE_INFO stXoFInfo;  // ✓
        MV_XOC_DEVICE_INFO stXoCInfo;  // ✓
        MV_GENTL_VIR_DEVICE_INFO stVirInfo;  // ✓
    }SpecialInfo;  // ✓
}MV_CC_DEVICE_INFO;  // ✓

typedef struct _MV_CC_DEVICE_INFO_LIST_  // ✓
{
    unsigned int nDeviceNum;               // 在线设备数量 ✓
    MV_CC_DEVICE_INFO* pDeviceInfo[MV_MAX_DEVICE_NUM];   // 指针指向SDK内部内存 ✓
}MV_CC_DEVICE_INFO_LIST;  // ✓

#define INFO_MAX_BUFFER_SIZE 64  // ✓
typedef struct _MV_USB3_DEVICE_INFO_  // ✓
{
    unsigned char CrtlInEndPoint;          // 控制输入端点 ✓
    unsigned char CrtlOutEndPoint;         // 控制输出端点 ✓
    unsigned char StreamEndPoint;          // 流端点 ✓
    unsigned char EventEndPoint;           // 事件端点 ✓
    unsigned short idVendor;               // 供应商ID号 ✓
    unsigned short idProduct;              // 产品ID号 ✓
    unsigned int nDeviceNumber;            // 设备索引号 ✓
    unsigned char chDeviceGUID[INFO_MAX_BUFFER_SIZE];  // ✓
    unsigned char chVendorName[INFO_MAX_BUFFER_SIZE];  // ✓
    unsigned char chModelName[INFO_MAX_BUFFER_SIZE];  // ✓
    unsigned char chFamilyName[INFO_MAX_BUFFER_SIZE];  // ✓
    unsigned char chDeviceVersion[INFO_MAX_BUFFER_SIZE];  // ✓
    unsigned char chManufacturerName[INFO_MAX_BUFFER_SIZE];  // ✓
    unsigned char chSerialNumber[INFO_MAX_BUFFER_SIZE];      // 序列号 ✓
    unsigned char chUserDefinedName[INFO_MAX_BUFFER_SIZE];   // 用户自定义名字 ✓
    unsigned int nbcdUSB;                  // 支持的USB协议 ✓
    unsigned int nDeviceAddress;           // 设备地址 ✓
    unsigned int nReserved[2];  // ✓
}MV_USB3_DEVICE_INFO;  // ✓
```

- USB3 相机的序列号和 User ID 分别在 `MV_CC_DEVICE_INFO.SpecialInfo.stUsb3VInfo.chSerialNumber`✓ 和 `MV_CC_DEVICE_INFO.SpecialInfo.stUsb3VInfo.chUserDefinedName`✓，都是 64 字节。GigE 相机对应的是 `MV_GIGE_DEVICE_INFO.chSerialNumber`✓ 和 `MV_GIGE_DEVICE_INFO.chUserDefinedName`✓，只有 16 字节。
- 对应的节点：`"DeviceSerialNumber"`（IString，R）和 `"DeviceUserID"`（IString，R/W），见第 17 项。

**c. 按 User ID 或序列号打开相机**

- SDK **没有**按序列号或 User ID 打开相机的专用接口（头文件中没有这类函数）。而且 U3V 设备必须先枚举才能打开（[H:MvCameraControl.h]:470–507；只有 GigE 可以像 ConnectSpecCamera 示例那样填 IP 直接打开）。
- 做法：枚举后逐个比较字符串，命中后按值拷贝 `MV_CC_DEVICE_INFO`✓，再调用 `MV_CC_CreateHandle`✓ 和 `MV_CC_OpenDevice`✓。ReconnectDemo 示例就是用 strcmp 比较 `stUsb3VInfo.chSerialNumber`✓ 来找回同一台相机的。如果需要固定的枚举顺序，可以用 `MV_CC_EnumDevicesEx2`✓ 配合 `SortMethod_SerialNumber`✓ 或 `SortMethod_UserID`✓。
- 写 User ID：`MV_CC_SetStringValue`✓(handle, "DeviceUserID", "left")（[CN] 设置参数页的字符串示例用的正是这个节点）。断电后是否保留，**文档未说明**（U11）。[VXML] 中它是地址 0x0184、长度 64 字节的 RW StringReg。
- **建议**：用出厂序列号作为配置主键，User ID 只作为便于人识别的标签。

**d. 访问模式**

- 宏 `MV_ACCESS_Exclusive`✓（1）到 `MV_ACCESS_Monitor`✓（7），见第 14 项。
- [CN] 初始化相机页：`MV_CC_OpenDevice`✓ 不传参数时，“默认相机实例独占物理相机的访问权限”；传入访问模式的写法“仅支持打开GigE Vision相机”。
- 头文件（[H:MvCameraControl.h]:470–507）：对 **USB3 Vision 设备和虚拟设备，`nAccessMode`✓ 和 `nSwitchoverKey`✓ 两个参数无效，默认以控制权限打开**。这与上面文档里“默认独占”的说法不一致，见“不一致之处”。
- `MV_CC_IsDeviceAccessible`✓ 对 USB3 相机和虚拟相机同样忽略 `nAccessMode`✓：相机没有被连接时返回 true，被第三方连接时返回 false，可以用来在打开前预检。
- 相机被其他进程占用时，打开会失败，返回 0x80000203（[CN] 开发前必读、常见问题）。同一台 USB 相机能否被两个进程同时打开，文档没有正面说明；但常见问题把“相机被其他进程连接”列为打开失败的原因，按此理解应视为独占。

### 9. 参数读写

来源：[CN] 设置参数；[H:MvCameraControl.h]:1231–1670；[H:CameraParams.h]:1211–1379；[VXML]（锁定条件）。

```c
int __stdcall MV_CC_GetIntValueEx(IN void* handle,IN const char* strKey,IN OUT MVCC_INTVALUE_EX *pstIntValue);  // ✓
int __stdcall MV_CC_SetIntValueEx(IN void* handle,IN const char* strKey,IN int64_t nValue);  // ✓
int __stdcall MV_CC_GetEnumValue(IN void* handle,IN const char* strKey,IN OUT MVCC_ENUMVALUE *pstEnumValue);  // ✓
int __stdcall MV_CC_GetEnumValueEx(IN void* handle, IN const char* strKey, IN OUT MVCC_ENUMVALUE_EX *pstEnumValue);  // ✓
int __stdcall MV_CC_SetEnumValue(IN void* handle,IN const char* strKey,IN unsigned int nValue);  // ✓
int __stdcall MV_CC_GetEnumEntrySymbolic(IN void* handle,IN const char* strKey,IN OUT MVCC_ENUMENTRY* pstEnumEntry);  // ✓
int __stdcall MV_CC_SetEnumValueByString(IN void* handle,IN const char* strKey,IN const char* strValue);  // ✓
int __stdcall MV_CC_GetFloatValue(IN void* handle,IN const char* strKey,IN OUT MVCC_FLOATVALUE *pstFloatValue);  // ✓
int __stdcall MV_CC_SetFloatValue(IN void* handle,IN const char* strKey,IN float fValue);  // ✓
int __stdcall MV_CC_GetBoolValue(IN void* handle,IN const char* strKey,IN OUT bool *pbValue);  // ✓
int __stdcall MV_CC_SetBoolValue(IN void* handle,IN const char* strKey,IN bool bValue);  // ✓
int __stdcall MV_CC_GetStringValue(IN void* handle,IN const char* strKey,IN OUT MVCC_STRINGVALUE *pstStringValue);  // ✓
int __stdcall MV_CC_SetStringValue(IN void* handle,IN const char* strKey,IN const char* strValue);  // ✓
int __stdcall MV_CC_SetCommandValue(IN void* handle,IN const char* strKey);  // ✓
int __stdcall MV_XML_GetNodeAccessMode(IN void* handle, IN const char * strName, IN OUT enum MV_XML_AccessMode *penAccessMode);  // ✓
int __stdcall MV_XML_GetNodeInterfaceType(IN void* handle, IN const char * strName, IN OUT enum MV_XML_InterfaceType *penInterfaceType);  // ✓
int __stdcall MV_XML_GetGenICamXML(IN void* handle, IN OUT unsigned char* pData, IN unsigned int nDataSize, IN OUT unsigned int* pnDataLen);  // ✓
int __stdcall MV_CC_InvalidateNodes(IN void* handle);  // ✓
int __stdcall MV_CC_FeatureLoad(IN void* handle, IN const char* strFileName);  // ✓
int __stdcall MV_CC_FeatureSave(IN void* handle, IN const char* strFileName);  // ✓

typedef struct _MVCC_INTVALUE_EX_T  // ✓
{
    int64_t nCurValue;                     // 当前值 ✓
    int64_t nMax;                          // 最大值 ✓
    int64_t nMin;                          // 最小值 ✓
    int64_t nInc;                          // 步进 ✓
    unsigned int nReserved[16];  // ✓
}MVCC_INTVALUE_EX;  // ✓

typedef struct _MVCC_FLOATVALUE_T  // ✓
{
    float fCurValue;                       // 当前值 ✓
    float fMax;                            // 最大值 ✓
    float fMin;                            // 最小值 ✓
    unsigned int nReserved[4];  // ✓
}MVCC_FLOATVALUE;  // ✓

typedef struct _MVCC_ENUMVALUE_EX_T  // ✓
{
    unsigned int nCurValue;                // 当前值 ✓
    unsigned int nSupportedNum;            // 有效数据个数 ✓
    unsigned int nSupportValue[MV_MAX_ENUM_SYMBOLIC_NUM];   // 支持的枚举值（最多256） ✓
    unsigned int nReserved[4];  // ✓
}MVCC_ENUMVALUE_EX;  // ✓

typedef struct _MVCC_ENUMENTRY_T  // ✓
{
    unsigned int nValue;                   // [IN] 指定值 ✓
    char chSymbolic[MV_MAX_SYMBOLIC_LEN];  // [OUT] 对应的符号 ✓
    unsigned int nReserved[4];  // ✓
}MVCC_ENUMENTRY;  // ✓

typedef struct _MVCC_STRINGVALUE_T  // ✓
{
    char chCurValue[256];                  // 当前值 ✓
    int64_t nMaxLength;                    // 最大长度 ✓
    unsigned int nReserved[2];  // ✓
}MVCC_STRINGVALUE;  // ✓
```

| 类型 | 读 | 写 | 范围信息 |
|---|---|---|---|
| Int | `MV_CC_GetIntValueEx`✓ | `MV_CC_SetIntValueEx`✓ | `MVCC_INTVALUE_EX.nMin`✓ / `nMax`✓ / `nInc`✓ |
| Float | `MV_CC_GetFloatValue`✓ | `MV_CC_SetFloatValue`✓（参数类型是 float） | `MVCC_FLOATVALUE.fMin`✓ / `fMax`✓。**结构体没有步进字段**，文档也没有说明如何获取浮点节点的步进 |
| Enum | `MV_CC_GetEnumValueEx`✓（最多 256 项；`MV_CC_GetEnumValue`✓ 最多 64 项） | `MV_CC_SetEnumValue`✓（按数值）/ `MV_CC_SetEnumValueByString`✓（按符号） | `MVCC_ENUMVALUE_EX.nSupportedNum`✓ 和 `nSupportValue`✓；数值转符号用 `MV_CC_GetEnumEntrySymbolic`✓ |
| Bool | `MV_CC_GetBoolValue`✓ | `MV_CC_SetBoolValue`✓ | – |
| String | `MV_CC_GetStringValue`✓ | `MV_CC_SetStringValue`✓ | `MVCC_STRINGVALUE.nMaxLength`✓ |
| Command | – | `MV_CC_SetCommandValue`✓ | – |
| 任意节点 | 访问模式用 `MV_XML_GetNodeAccessMode`✓（`AM_NI`✓、`AM_NA`✓、`AM_WO`✓、`AM_RO`✓、`AM_RW`✓ 等）；类型用 `MV_XML_GetNodeInterfaceType`✓（`IFT_IInteger`✓、`IFT_IFloat`✓ 等）；整份 XML 用 `MV_XML_GetGenICamXML`✓ 导出 | | |

- 早期按具体参数命名的接口（如 `MV_CC_SetExposureTime`✓、`MV_CC_SetFrameRate`✓）以及 `MV_CC_GetIntValue`✓ / `MV_CC_SetIntValue`✓ 都已废弃，应改用上面的通用接口（见第 16 项）。
- **哪些参数必须在停止取流时才能设置**：文档**没有给出清单**，只说修改宽、高、像素格式后需要重新获取 PayloadSize（[CN] 配置缓存）。以下是根据 [VXML] 中各节点的 pIsLocked 公式（是否依赖 TLParamsLocked，即“正在取流”）整理的结果：

| 取流期间锁定（必须停流再改） | 有条件锁定 | 不受取流锁定 |
|---|---|---|
| `"Width"`、`"Height"`、`"PixelFormat"`、`"BinningHorizontal"`、`"BinningVertical"`、`"DecimationHorizontal"`、`"DecimationVertical"`、`"ExposureMode"`、`"SensorShutterMode"`、`"ADCBitDepth"`、`"SequencerMode"`、`"UserSetLoad"`、`"FrameSpecInfoSelector"`、`"FrameSpecInfo"`、`"TransferQueueMaxBlockCount"`、`"DeviceLinkThroughputLimitMode"`、`"DeviceLinkThroughputLimit"`、`"HighBandwidthMode"`、`"ImageCompressionQuality"`、`"AcquisitionBurstFrameCount"`、`"RegionMode"` | `"OffsetY"`：只有设备能力位 OffsetY_Locked_When_TL_Inq_Bit=1 时才锁定。`"TriggerMode"`、`"TriggerSource"`、`"TriggerActivation"`：只有在 `"ExposureMode"`=TriggerWidth 时才锁定。`"ExposureTime"`：在 `"ExposureAuto"`≠Off 或 `"ExposureMode"`≠Timed 时锁定（与取流无关）。`"Gain"`：在 `"GainAuto"`≠Off 时锁定 | `"OffsetX"`、`"AcquisitionFrameRate"`、`"AcquisitionFrameRateEnable"`、`"DeviceTimestampLatch"` |

  这张表来自虚拟相机，真机需要在 U10 中导出 XML 复核。写入被锁定的节点时会返回哪个错误码（推测可能是 `MV_E_GC_ACCESS`✓），**文档未说明**（U10）。

### 10. 缓存和取图策略

来源：[CN] 配置缓存、采集图像；[H:MvCameraControl.h]:690–959；[H:CameraParams.h]:528–535；[XLSX]；[INI]；[CN] 发版说明（V4.8.0、V4.9.0）。

```c
int __stdcall MV_CC_SetImageNodeNum(IN void* handle, IN unsigned int nNum);  // ✓
int __stdcall MV_CC_SetGrabStrategy(IN void* handle, IN MV_GRAB_STRATEGY enGrabStrategy);  // ✓
int __stdcall MV_CC_SetOutputQueueSize(IN void* handle, IN unsigned int nOutputQueueSize);  // ✓
int __stdcall MV_CC_ClearImageBuffer(IN void* handle);  // ✓
int __stdcall MV_CC_GetValidImageNum(IN void* handle, IN OUT unsigned int *pnValidImageNum);  // ✓
int __stdcall MV_CC_GetPayloadSize(IN void* handle, IN OUT uint64_t* pnPayloadSize, IN OUT unsigned int* pnAlignment);  // ✓
void * __stdcall MV_CC_AllocAlignedBuffer(IN uint64_t nBufSize, IN unsigned int nAlignment);  // ✓
int __stdcall MV_CC_FreeAlignedBuffer(IN void* pBuffer);  // ✓
int __stdcall MV_CC_RegisterBuffer(IN void* handle, IN void *pBuffer, IN uint64_t nBufSize, IN void* pUser);  // ✓
int __stdcall MV_CC_UnRegisterBuffer(IN void* handle, IN void* pBuffer);  // ✓

typedef enum _MV_GRAB_STRATEGY_  // ✓
{
    MV_GrabStrategy_OneByOne = 0,          // 从旧到新一帧一帧的获取图像（打开设备后默认） ✓
    MV_GrabStrategy_LatestImagesOnly = 1,  // 获取列表中最新的一帧图像，同时清空列表 ✓
    MV_GrabStrategy_LatestImages = 2,      // 获取最新的OutputQueueSize帧 ✓
    MV_GrabStrategy_UpcomingImage = 3,     // 忽略列表中已有图像，等待下一帧 ✓
}MV_GRAB_STRATEGY;  // ✓
```

**缓存节点数**

- 用 `MV_CC_SetImageNodeNum`✓ 设置，取值至少为 1，**必须在 `MV_CC_StartGrabbing`✓ 之前调用**。开始取流时 SDK 会检查内存，内存不足会导致 `MV_CC_StartGrabbing`✓ 失败。
- 默认值是 **1**：见 [H:MvCameraControl.h]:716–732（`MV_CC_FreeImageBuffer`✓ 的说明）和 821–845（`MV_CC_SetGrabStrategy`✓ 的说明）；[XLSX] 中 ImageNodeNum 也写“默认为1”。
- [INI] 补充：SDK 实际分配的节点数 = SDK 内部预分配的个数 + ImageNodeNum（例如双 U 口相机会多分配 2 个）；调用了 `MV_CC_SetImageNodeNum`✓ 或 `MV_CC_RegisterBuffer`✓ 后，ini 中的设置失效。
- 关键约束：在不 Free 的情况下，`MV_CC_GetImageBuffer`✓ 最多能同时交出的帧数，等于 `MV_CC_SetImageNodeNum`✓ 设置的节点数（[H:MvCameraControl.h]:716–732）。所以如果想把 SDK 缓存直接挂在 ROS 消息上零拷贝，节点数必须大于同时在途的帧数，否则 SDK 无处接收新帧，就会丢帧。常见问题也把“取图后没有及时 Free”列为丢帧原因。
- 外部缓存（`MV_CC_RegisterBuffer`✓）：使用后 `MV_CC_SetImageNodeNum`✓ 不再生效；双 USB 接口相机至少要注册 3 块。
- 计算：1280×1024 的 BayerGB8 每帧约 1.31 MB。缓存 30 帧约 39 MB，两台相机约 79 MB。

**取图策略**（[H:MvCameraControl.h]:821–863）

| 策略 | 行为 |
|---|---|
| OneByOne | 按从旧到新的顺序逐帧取出，**打开设备后的默认策略** |
| LatestImagesOnly | 只取最新的一帧，并清空输出缓存列表 |
| LatestImages | 取最新的 OutputQueueSize 帧，OutputQueueSize 的范围是 1 到 ImageNodeNum，可在取流过程中用 `MV_CC_SetOutputQueueSize`✓ 动态调整。设为 1 时等同于 LatestImagesOnly，设为 ImageNodeNum 时等同于 OneByOne |
| UpcomingImage | 调用取图接口时忽略列表中已有的图像，等待设备产生的下一帧 |

- **USB 相机支持哪些策略**：头文件中 `MV_CC_SetGrabStrategy`✓ 的说明**没有限制设备类型**。[CN] 发版说明：V4.8.0 新增“支持USB3 Vision相机的UpcomingImage模式”，V4.9.0 新增“`MV_CC_SetGrabStrategy`✓ 支持对GigE Vision设备设置取图策略”。由此推断，V4.9.0 下 USB3 相机支持全部四种策略，但文档没有一张明确的支持表。
- **场景对照**（建议）：
  - 录制不丢帧：用 OneByOne（默认），把 `MV_CC_SetImageNodeNum`✓ 调大（例如 60 Hz × 可容忍的 0.5 s 处理抖动 ≈ 30），取图线程拷贝后立即 Free。用帧号跳变、流异常 `MV_CC_STREAM_EXCEPTION_LIST_OVERFLOW`✓ 和 `MV_CC_GetValidImageNum`✓ 监控积压和丢帧。
  - 推理要求低延迟：用 LatestImagesOnly，或用 LatestImages 并设 OutputQueueSize=1。UpcomingImage 要等下一帧，最多会多出一个帧周期的延迟（这是从定义推断的）。
  - 本方案是一条采集链路同时服务录制和推理，**建议驱动层固定用 OneByOne**，丢帧策略放到下游（推理节点只取最新的消息），以免驱动静默丢帧导致左右配对缺帧。
- `MV_CC_ClearImageBuffer`✓ 可以在不停止取流的情况下清空 SDK 缓存中的图像。

### 11. 采集图像

来源：[CN] 采集图像、开发前必读（流程图）、常见问题；[H:MvCameraControl.h]:603–778；[S]`General/GrabImage_HighPerformance/GrabImage_HighPerformance.cpp`。

```c
typedef void(__stdcall *MvImageCallbackEx)(unsigned char * pData, MV_FRAME_OUT_INFO_EX* pFrameInfo, void* pUser);  // ✓
typedef void(__stdcall *MvImageCallbackEx2)(MV_FRAME_OUT* pstFrame, void *pUser, bool bAutoFree);  // ✓
int __stdcall MV_CC_RegisterImageCallBackEx(IN void* handle, IN MvImageCallbackEx cbOutput, IN void* pUser);  // ✓
int __stdcall MV_CC_RegisterImageCallBackEx2(IN void* handle, IN MvImageCallbackEx2 cbOutput, IN void* pUser, IN bool bAutoFree);  // ✓
int __stdcall MV_CC_StartGrabbing(IN void* handle);  // ✓
int __stdcall MV_CC_StopGrabbing(IN void* handle);  // ✓
int __stdcall MV_CC_GetImageBuffer(IN void* handle, IN OUT MV_FRAME_OUT* pstFrame, IN unsigned int nMsec);  // ✓
int __stdcall MV_CC_FreeImageBuffer(IN void* handle, IN MV_FRAME_OUT* pstFrame);  // ✓
int __stdcall MV_CC_GetOneFrameTimeout(IN void* handle, IN OUT unsigned char* pData , IN unsigned int nDataSize, IN OUT MV_FRAME_OUT_INFO_EX* pstFrameInfo, IN unsigned int nMsec);  // ✓
```

- `MV_CC_StartGrabbing`✓ 和 `MV_CC_StopGrabbing`✓：开始和停止取流，不支持 CameraLink 设备。
- `MV_CC_GetImageBuffer`✓：
  - 必须先调用 `MV_CC_StartGrabbing`✓。
  - `nMsec`✓ 是超时时间，单位为毫秒（英文注释写明 “unit: millisecond”）。在超时之前，SDK 会一直等到有数据才返回。
  - 头文件说可以“输入INFINITE时表示无限等待，直到收到一帧数据或者停止取流”，但 **`INFINITE`? 在 `/opt/MVS/include` 中没有定义**（Linux 下没有这个宏），建议始终使用有限超时。
  - 超时返回哪个错误码，文档没有明确对应。常见问题把它描述为“接口报错无数据”，`MV_E_NODATA`✓（0x80000007）的定义是“超时，未收到数据”，推断就是这个码。
  - 调用 `MV_CC_Display`✓（已废弃）之后，就不能再用它取图。
- `MV_CC_FreeImageBuffer`✓：把缓存归还给 SDK，归还后 `MV_FRAME_OUT.pBufAddr`✓ 失效。必须与 `MV_CC_GetImageBuffer`✓ 一一配对。
- 回调取图与轮询取图互斥。在 `MV_CC_RegisterImageCallBackEx`✓ 的回调里，回调结束后 pData 失效。用 `MV_CC_RegisterImageCallBackEx2`✓ 并传 bAutoFree=false 时，需要自己调用 `MV_CC_FreeImageBuffer`✓；如果要在回调外使用 `MV_FRAME_OUT`✓ 结构体，必须先浅拷贝。回调中不要做耗时操作，也不要加锁。
- `MV_CC_GetOneFrameTimeout`✓ 需要调用者自己分配缓存，效率低于 `MV_CC_GetImageBuffer`✓（未废弃，见第 16 项）。
- **线程阻塞在 `MV_CC_GetImageBuffer`✓ 时调用 `MV_CC_StopGrabbing`✓ 会怎样**：头文件只在 INFINITE 的说明里提到“直到收到一帧数据或者停止取流”，这意味着停止取流会结束等待。但有限超时下的行为、此时的返回码，以及两个调用的先后是否安全，**文档未说明**。流程图中“退出线程”画在“停止取流”之前；示例的做法是先置位退出标志，`sleep(1)` 后再调用 StopGrabbing，不 join 线程。**建议**：取图超时设为 100–200 ms；停止时先置位标志并 join 取图线程，再调用 `MV_CC_StopGrabbing`✓。这样就避开了这个未定义的情形（U7）。

---

## P2 稳定性和其他

### 12. 异常和事件

来源：[CN] 事件及异常；[H:MvCameraControl.h]:144–181、1803–1925、2526–2540；[H:CameraParams.h]:1059–1110；[S]`General/ReconnectDemo/ReconnectDemo.cpp`:101–240；[INI]。

```c
typedef void(__stdcall *MvExceptionCallback)(unsigned int nMsgType, void *pUser);  // ✓
typedef void(__stdcall *MvEventCallback)(MV_EVENT_OUT_INFO * pEventInfo, void* pUser);  // ✓
typedef void(__stdcall *MvStreamExceptionCallback)(MV_CC_STREAM_EXCEPTION_INFO* pstStreamExceptionInfo, void* pUser);  // ✓
int __stdcall MV_CC_RegisterExceptionCallBack(IN void* handle, IN MvExceptionCallback cbException, IN void* pUser);  // ✓
int __stdcall MV_CC_RegisterAllEventCallBack(IN void* handle, IN MvEventCallback cbEvent, IN void* pUser);  // ✓
int __stdcall MV_CC_RegisterEventCallBackEx(IN void* handle, IN const char* strEventName, IN MvEventCallback cbEvent, IN void* pUser);  // ✓
int __stdcall MV_CC_RegisterStreamExceptionCallBack(IN void* handle, IN MvStreamExceptionCallback cbStreamException, IN void* pUser);  // ✓
int __stdcall MV_CC_EventNotificationOn(IN void* handle, IN const char* strEventName);  // ✓
int __stdcall MV_CC_EventNotificationOff(IN void* handle, IN const char* strEventName);  // ✓
int __stdcall MV_USB_SetEventNodeNum(IN void* handle, IN unsigned int nEventNodeNum);  // ✓

typedef enum _MV_CC_STREAM_EXCEPTION_TYPE_  // ✓
{
    MV_CC_STREAM_EXCEPTION_ABNORMAL_IMAGE = 0x4001,         // 图像异常，丢弃该帧 ✓
    MV_CC_STREAM_EXCEPTION_LIST_OVERFLOW = 0x4002,          // 缓存列表已满(没有及时取走图像) ✓
    MV_CC_STREAM_EXCEPTION_LIST_EMPTY = 0x4003,             // 缓存列表为空(取走后未及时归还) ✓
    MV_CC_STREAM_EXCEPTION_RECONNECTION = 0x4004,           // 触发一次断流恢复（仅USB3 Vision） ✓
    MV_CC_STREAM_EXCEPTION_DISCONNECTED = 0x4005,           // 断流恢复失败,取流被中止（仅USB3 Vision） ✓
    MV_CC_STREAM_EXCEPTION_DEVICE = 0x4006,                 // 设备异常,取流被中止（仅USB3 Vision） ✓
    MV_CC_STREAM_EXCEPTION_PARTIAL_IMAGE = 0x4007,          // 行高不足,丢弃残帧 ✓
    MV_CC_STREAM_EXCEPTION_IMAGE_BUFFER_OVERFLOW = 0x4008,  // 图像数据大小超过缓冲区容量(该帧丢弃) ✓
}MV_CC_STREAM_EXCEPTION_TYPE;  // ✓

typedef struct _MV_CC_STREAM_EXCEPTION_INFO_T_  // ✓
{
    char chSerialNumber[INFO_MAX_BUFFER_SIZE];   // 设备序列号 ✓
    unsigned int nStreamIndex;                   // 流通道序号 ✓
    MV_CC_STREAM_EXCEPTION_TYPE enExceptionType; // 流异常类型 ✓
    unsigned int nReserved[8];  // ✓
}MV_CC_STREAM_EXCEPTION_INFO;  // ✓

typedef struct _MV_EVENT_OUT_INFO_  // ✓
{
    char EventName[MAX_EVENT_NAME_SIZE];   // Event名称 ✓
    unsigned short nEventID;               // Event号 ✓
    unsigned short nStreamChannel;         // 流通道序号 ✓
    unsigned int nBlockIdHigh;             // 帧号高位 (暂无固件支持) ✓
    unsigned int nBlockIdLow;              // 帧号低位 (暂无固件支持) ✓
    unsigned int nTimestampHigh;           // 时间戳高位 ✓
    unsigned int nTimestampLow;            // 时间戳低位 ✓
    void* pEventData;                      // Event数据 (暂无固件支持) ✓
    unsigned int nEventDataSize;           // Event数据长度 (暂无固件支持) ✓
    unsigned int nReserved[16];  // ✓
}MV_EVENT_OUT_INFO;  // ✓
```

- **掉线等异常回调**：用 `MV_CC_RegisterExceptionCallBack`✓ 注册，要在 `MV_CC_OpenDevice`✓ 之后调用；传入 NULL 即注销。异常类型有 `MV_EXCEPTION_DEV_DISCONNECT`✓（0x00008001，设备断开连接）和 `MV_EXCEPTION_VERSION_CHECK`✓（0x00008002，SDK 与驱动版本不匹配）。文档要求“请勿通过异常事件回调函数执行耗时较长的操作”。
- **流异常回调**：用 `MV_CC_RegisterStreamExceptionCallBack`✓ 注册，类型见上面的枚举。回调中不能调用 StopGrabbing、CloseDevice 或 DestroyHandle，只能用于通知。**不支持虚拟相机**，也不支持导入第三方 cti 的场景。旧接口 `MV_USB_RegisterStreamExceptionCallBack`✓ 从 V4.6.0 起已废弃。
- **事件回调**：
  - 流程是 `MV_CC_RegisterEventCallBackEx`✓(handle, 事件名, cb, user) 订阅，`MV_CC_EventNotificationOn`✓ 开启，然后（对需要取流才产生的事件）调用 `MV_CC_StartGrabbing`✓；结束时调用 `MV_CC_EventNotificationOff`✓，再把回调设为 NULL 取消订阅。
  - 文档示例用的事件名是 `"ExposureEnd"`。文档还说“若要获取正常通知事件，需先通过客户端配置相机”。
  - 事件信息中的 `MV_EVENT_OUT_INFO.nTimestampHigh`✓/`nTimestampLow`✓ 单位**文档未说明**；`MV_EVENT_OUT_INFO.nBlockIdHigh`✓、`MV_EVENT_OUT_INFO.pEventData`✓ 标注了“暂无固件支持”。
  - USB3 事件在 SDK 内部默认有 5 个缓存节点，可用 `MV_USB_SetEventNodeNum`✓ 调整为 1–64，否则事件可能丢失。
  - [VXML] 中 `"EventSelector"` 的选项包括 ExposureStart、ExposureEnd、FrameStart、FrameEnd 等，可以用于 U4。真机是否支持未知。
- **断线重连的建议**：
  - 头文件：GigE 设备掉线后，要先调用 `MV_CC_CloseDevice`✓，再调用 `MV_CC_OpenDevice`✓。对 USB 设备没有单独说明。
  - ReconnectDemo 的流程：在异常回调里收到 `MV_EXCEPTION_DEV_DISCONNECT`✓ 后，`MV_CC_CloseDevice`✓ → `MV_CC_DestroyHandle`✓ → 循环枚举，直到找到序列号相同的设备 → `MV_CC_CreateHandle`✓ → `MV_CC_OpenDevice`✓ → 重新注册异常回调 → `MV_CC_StartGrabbing`✓。这个示例在回调里阻塞重连，与文档“不要在回调中做耗时操作”的要求矛盾。
  - SDK 内部对 USB 还有“断流恢复”机制，会通过流异常 `MV_CC_STREAM_EXCEPTION_RECONNECTION`✓ 和 `MV_CC_STREAM_EXCEPTION_DISCONNECTED`✓ 报告。[INI] 提到 StreamPayloadTimeout 大于 1000 ms 时会关闭这个机制。
  - **建议**：回调里只置位原子标志并唤醒监督线程，由监督线程按序列号重连。重连后要重新下发全部参数（相机可能已经断电重启），并重新对时，因为时间戳可能已经重置（U14）。可以用 `MV_CC_IsDeviceConnected`✓ 做周期性健康检查。

### 13. USB3 Vision 相机专用接口

来源：[CN] 设置参数（USB3 Vision相机专有配置）；[H:MvCameraControl.h]:2448–2580；[XLSX]；[INI]；[脚本]；[CN] 相机参数节点表；[VXML]。

```c
int __stdcall MV_USB_SetTransferSize(IN void* handle, IN unsigned int nTransferSize);  // ✓
int __stdcall MV_USB_GetTransferSize(IN void* handle, IN OUT unsigned int* pnTransferSize);  // ✓
int __stdcall MV_USB_SetTransferWays(IN void* handle, IN unsigned int nTransferWays);  // ✓
int __stdcall MV_USB_GetTransferWays(IN void* handle, IN OUT unsigned int* pnTransferWays);  // ✓
int __stdcall MV_USB_SetEventNodeNum(IN void* handle, IN unsigned int nEventNodeNum);  // ✓
int __stdcall MV_USB_SetSyncTimeOut(IN void* handle, IN unsigned int nMills);  // ✓
int __stdcall MV_USB_GetSyncTimeOut(IN void* handle, IN OUT unsigned int* pnMills);  // ✓
int __stdcall MV_CC_GetAllMatchInfo(IN void* handle, IN OUT MV_ALL_MATCH_INFO* pstInfo);  // ✓

typedef struct _MV_ALL_MATCH_INFO_  // ✓
{
    unsigned int nType;                    // [IN] 信息类型，如 MV_MATCH_TYPE_USB_DETECT ✓
    void* pInfo;                           // [OUT] 输出的信息缓存，由调用者分配 ✓
    unsigned int nInfoSize;                // [IN] 信息缓存的大小 ✓
}MV_ALL_MATCH_INFO;  // ✓

typedef struct _MV_MATCH_INFO_USB_DETECT_  // ✓
{
    int64_t nReceiveDataSize;              // 已接收数据大小 [Open和Close之间] ✓
    unsigned int nReceivedFrameCount;      // 已收到的帧数 ✓
    unsigned int nErrorFrameCount;         // 错误帧数 ✓
    unsigned int nReserved[2];  // ✓
}MV_MATCH_INFO_USB_DETECT;  // ✓
```

| 接口 | 默认值与范围 | 说明 |
|---|---|---|
| `MV_USB_SetTransferSize`✓ | 默认 1 MB；必须是 1024 的倍数，且 ≥0x8000；Linux 建议不超过 0x200000 | 调大可以降低 CPU 占用，但调得过大可能取不到图 |
| `MV_USB_SetTransferWays`✓ | 1–10；默认值由 SDK 按像素格式计算（例如 2000 万像素相机 Mono8 默认 3 个，其他情况默认 8 个） | 根据 PC 性能、帧率、图像大小调节 |
| `MV_USB_SetEventNodeNum`✓ | 1–64，默认 5 | 事件缓存 |
| `MV_USB_SetSyncTimeOut`✓ | ≥1000 ms，默认 1000 ms | 控制链路同步读写超时 |

- 文档的建议（[CN] 设置参数）：控制链路异常、命令传输慢导致超时时，调 `MV_USB_SetSyncTimeOut`✓；流链路带宽不足或系统资源不足时，调 `MV_USB_SetTransferSize`✓ 或 `MV_USB_SetTransferWays`✓。
- 同样的参数也可以写在 [INI] 中：TransferSize、TransferWays、EventBufferNum、StreamPayloadTimeout（默认 50 ms）、SIControlRegTimeout（默认 30 ms）、SyncTimeout。改完要重启应用程序才生效。[XLSX] 对 U3V 的每一项都标注了“**虚拟相机不支持**”。
- 带宽相关的相机节点：
  - 节点表：`"DeviceMaxThroughput"`（R，设备最大吞吐量）、`"DeviceConnectionSpeed"`（R，单位 Mbps）、`"DeviceLinkSpeed"`（R）。
  - [VXML]：`"DeviceLinkThroughputLimitMode"`（On/Off）和 `"DeviceLinkThroughputLimit"`（单位 KB，取流期间锁定）、`"DeviceLinkCurrentThroughput"`（KB，只读）、`"USBSpeedMode"`（HighSpeed=0x4 / SuperSpeed=0x8）、`"U3VCurrentSpeed"`、`"HighBandwidthMode"`。
- 主机端设置（[CN] 环境配置、[脚本]）：
  - `set_usbfs_memory_size.sh` 把 2000 写入 `/sys/module/usbcore/parameters/usbfs_memory_mb`。这只是运行时设置，脚本本身没有做持久化；本机当前值已经是 2000。文档建议使用 USB 相机时执行。
  - `set_usb_priority.sh` 会创建 udev 规则 `/etc/udev/rules.d/80-drivers-SDK-2bdf.rules`（厂商 ID 2bdf，MODE=0666，GROUP=plugdev），这样非 root 用户也能访问 U3V 相机。
- 带宽估算：1280×1024×1 B×60 Hz ≈ 78.6 MB/s，两台合计约 157 MB/s。

### 14. 宏定义（设备类型、访问模式等）

来源：[H:CameraParams.h]:160–321、549–550、1061–1062、1089；[H:MvCameraControl.h]:273–307。

```c
#define MV_UNKNOW_DEVICE 0x00000000                // 未知设备类型 ✓
#define MV_GIGE_DEVICE 0x00000001                  // GigE Vision设备 ✓
#define MV_1394_DEVICE 0x00000002                  // 1394-a/b 设备 ✓
#define MV_USB_DEVICE 0x00000004                   // USB3 Vision设备 ✓
#define MV_CAMERALINK_DEVICE 0x00000008            // 串口设备 ✓
#define MV_VIR_GIGE_DEVICE 0x00000010              // 虚拟GigE Vision设备 ✓
#define MV_VIR_USB_DEVICE 0x00000020               // 虚拟USB3 Vision设备 ✓
#define MV_GENTL_GIGE_DEVICE 0x00000040            // 自研网卡下GigE Vision设备 ✓
#define MV_GENTL_CAMERALINK_DEVICE 0x00000080      // CameraLink相机设备 ✓
#define MV_GENTL_CXP_DEVICE 0x00000100             // CoaXPress设备 ✓
#define MV_GENTL_XOF_DEVICE 0x00000200             // XoF设备 ✓
#define MV_GENTL_VIR_DEVICE 0x00000800             // 虚拟采集卡下的设备 ✓
#define MV_GENTL_XOC_DEVICE 0x00001000             // XoC设备 ✓

#define MV_ACCESS_Exclusive 1                      // 独占权限，其他APP只允许读CCP寄存器 ✓
#define MV_ACCESS_ExclusiveWithSwitch 2            // 可以从5模式下抢占权限，然后以独占权限打开 ✓
#define MV_ACCESS_Control 3                        // 控制权限，其他APP允许读所有寄存器 ✓
#define MV_ACCESS_ControlWithSwitch 4              // 可以从5的模式下抢占权限，然后以控制权限打开 ✓
#define MV_ACCESS_ControlSwitchEnable 5            // 以可被抢占的控制权限打开 ✓
#define MV_ACCESS_ControlSwitchEnableWithKey 6     // 可以从5的模式下抢占权限，然后以可被抢占的控制权限打开 ✓
#define MV_ACCESS_Monitor 7                        // 读模式打开设备，适用于控制权限下 ✓

#define MV_EXCEPTION_DEV_DISCONNECT 0x00008001     // 设备断开连接 ✓
#define MV_EXCEPTION_VERSION_CHECK 0x00008002      // SDK与驱动版本不匹配 ✓
#define MV_MATCH_TYPE_NET_DETECT 0x00000001        // 网络流量和丢包信息 ✓
#define MV_MATCH_TYPE_USB_DETECT 0x00000002        // host接收到来自USB3 Vision设备的字节总数 ✓
#define MV_MAX_DEVICE_NUM 256  // ✓
#define INFO_MAX_BUFFER_SIZE 64  // ✓
#define MAX_EVENT_NAME_SIZE 128  // ✓
```

- 访问模式只对 GigE 设备有效。对 USB3 设备和虚拟设备，这两个参数会被忽略，SDK 以控制权限打开（第 8d 项）。
- `MV_1394_DEVICE`✓ 在头文件里有定义，但没有出现在头文件注释中的设备类型表里。

### 15. 状态码（常见约 20 个）

来源：[H:MvErrorDefine.h]:14–160；[CN] 开发前必读、常见问题。

| 宏 | 值 | 含义（头文件注释） | 与本方案的关系 |
|---|---|---|---|
| `MV_OK`✓ | 0x00000000 | 成功，无错误 | |
| `MV_E_HANDLE`✓ | 0x80000000 | 错误或无效的句柄 | |
| `MV_E_SUPPORT`✓ | 0x80000001 | 不支持的功能 | |
| `MV_E_BUFOVER`✓ | 0x80000002 | 缓存已满 | |
| `MV_E_CALLORDER`✓ | 0x80000003 | 函数调用顺序错误 | 例如在取流前取图 |
| `MV_E_PARAMETER`✓ | 0x80000004 | 错误的参数 | |
| `MV_E_RESOURCE`✓ | 0x80000006 | 资源申请失败(内存) | |
| `MV_E_NODATA`✓ | 0x80000007 | 超时，未收到数据 | 取图超时（推断） |
| `MV_E_PRECONDITION`✓ | 0x80000008 | 前置条件有误，或运行环境已发生变化 | |
| `MV_E_NOENOUGH_BUF`✓ | 0x8000000A | 内存空间不足（传入内存偏小） | |
| `MV_E_ABNORMAL_IMAGE`✓ | 0x8000000B | 异常图像，可能是丢包导致图像不完整 | |
| `MV_E_NOOUTBUF`✓ | 0x8000000D | 没有可输出的缓存 | |
| `MV_E_DEV_OFFLINE`✓ | 0x80000020 | 设备已掉线 | |
| `MV_E_PARAMETER_RANGE`✓ | 0x80000025 | 参数超出范围限制 | |
| `MV_E_RESOURCE_IN_USE`✓ | 0x80000028 | 请求的资源（采集卡、设备和流等）已被占用 | |
| `MV_E_UNKNOW`✓ | 0x800000FF | 未知的错误 | |
| `MV_E_GC_RANGE`✓ | 0x80000102 | 值超出范围 | 设置超出 min/max 的参数 |
| `MV_E_GC_ACCESS`✓ | 0x80000106 | 节点访问条件有误 | 推测是写入被锁定节点时的返回码（U10） |
| `MV_E_GC_TIMEOUT`✓ | 0x80000107 | 超时 | |
| `MV_E_GC_NODE_NOT_FOUND`✓ | 0x80000109 | 节点不存在 | 真机没有某个节点时 |
| `MV_E_ACCESS_DENIED`✓ | 0x80000203 | 设备无访问权限 | 相机被其他程序占用（文档示例） |
| `MV_E_BUSY`✓ | 0x80000204 | 设备忙，或网络断开 | |
| `MV_E_USB_READ`✓ | 0x80000300 | 读usb出错 | |
| `MV_E_USB_WRITE`✓ | 0x80000301 | 写usb出错 | |
| `MV_E_USB_DEVICE`✓ | 0x80000302 | 设备异常 | |
| `MV_E_USB_BANDWIDTH`✓ | 0x80000304 | 带宽不足 | |
| `MV_E_USB_DRIVER`✓ | 0x80000305 | 驱动不匹配或者未装驱动 | |

V4.9.0 起又按子模块补充了 0x80000041–0x8000004D（设备返回的错误）等码，详见 `MvErrorDefine.h`。

### 16. 废弃接口

来源：[CN] 已弃用列表（`deprecated.html`）；[CN] 废弃接口分组；[H:MvObsoleteInterfaces.h]；[H:MvCameraControl.h]:735–759。

- [CN] `deprecated.html` 只列了 **2 个**：`MV_CAML_GetSupportBauderates`✓（建议改用 `MV_CAML_GetSupportBaudrates`✓）和 `MV_USB_RegisterStreamExceptionCallBack`✓（自 V4.6.0 废弃，建议改用 `MV_CC_RegisterStreamExceptionCallBack`✓）。
- [CN] 废弃接口分组页与 `MvObsoleteInterfaces.h` 中的函数集合**完全相同，共 114 个**（我用脚本做了集合比对）。废弃原因写的是：“新开发的万能接口代替了具体节点的设置、获取参数功能；效率低的接口由新的接口替代；实际开发中部分接口使用频率较低”。
- 头文件中的废弃函数**没有加 deprecated 编译属性**，`MvCameraControl.h` 又会自动包含 `MvObsoleteInterfaces.h`，所以误用这些函数时编译器不会给出警告。
- **`MV_CC_GetOneFrameTimeout`✓ 没有被废弃**：它声明在 `MvCameraControl.h`:759 的“图像采集”分组里，不在上述两份废弃清单中。头文件只说 `MV_CC_GetImageBuffer`✓ 比它效率更高。已废弃的 `MV_CC_GetOneFrame`✓ 和 `MV_CC_GetOneFrameEx`✓ 的注释反而建议改用 `MV_CC_GetOneFrameTimeOut`?，大小写与实际函数名不同（见“不一致之处”）。

<details><summary>全部 114 个废弃函数（MvObsoleteInterfaces.h）</summary>

`MV_CAML_GetDeviceBauderate`✓ `MV_CAML_GetSupportBauderates`✓ `MV_CAML_SetDeviceBauderate`✓ `MV_CC_BayerNoiseEstimate`✓ `MV_CC_BayerSpatialDenoise`✓ `MV_CC_ColorCorrect`✓ `MV_CC_ConvertPixelType`✓ `MV_CC_CreateHandleWithoutLog`✓ `MV_CC_Display`✓ `MV_CC_DisplayOneFrame`✓ `MV_CC_EnumerateTls`✓ `MV_CC_GetAcquisitionLineRate`✓ `MV_CC_GetAcquisitionMode`✓ `MV_CC_GetAOIoffsetX`✓ `MV_CC_GetAOIoffsetY`✓ `MV_CC_GetAutoExposureTimeLower`✓ `MV_CC_GetAutoExposureTimeUpper`✓ `MV_CC_GetBalanceRatioBlue`✓ `MV_CC_GetBalanceRatioGreen`✓ `MV_CC_GetBalanceRatioRed`✓ `MV_CC_GetBalanceWhiteAuto`✓ `MV_CC_GetBrightness`✓ `MV_CC_GetBurstFrameCount`✓ `MV_CC_GetDeviceUserID`✓ `MV_CC_GetExposureAutoMode`✓ `MV_CC_GetExposureTime`✓ `MV_CC_GetFrameRate`✓ `MV_CC_GetFrameSpecInfoAbility`✓ `MV_CC_GetGain`✓ `MV_CC_GetGainMode`✓ `MV_CC_GetGamma`✓ `MV_CC_GetGammaSelector`✓ `MV_CC_GetHeartBeatTimeout`✓ `MV_CC_GetHeight`✓ `MV_CC_GetHue`✓ `MV_CC_GetImageForBGR`✓ `MV_CC_GetImageForRGB`✓ `MV_CC_GetImageInfo`✓ `MV_CC_GetIntValue`✓ `MV_CC_GetOneFrame`✓ `MV_CC_GetOneFrameEx`✓ `MV_CC_GetPixelFormat`✓ `MV_CC_GetSaturation`✓ `MV_CC_GetSharpness`✓ `MV_CC_GetTlProxy`✓ `MV_CC_GetTriggerDelay`✓ `MV_CC_GetTriggerMode`✓ `MV_CC_GetTriggerSource`✓ `MV_CC_GetWidth`✓ `MV_CC_ImageSharpen`✓ `MV_CC_LSCCalib`✓ `MV_CC_LSCCorrect`✓ `MV_CC_NoiseEstimate`✓ `MV_CC_OpenParamsGUI`✓ `MV_CC_RegisterEventCallBack`✓ `MV_CC_RegisterImageCallBack`✓ `MV_CC_RegisterImageCallBackForBGR`✓ `MV_CC_RegisterImageCallBackForRGB`✓ `MV_CC_SaveImage`✓ `MV_CC_SaveImageEx`✓ `MV_CC_SaveImageEx2`✓ `MV_CC_SaveImageToFile`✓ `MV_CC_SavePointCloudData`✓ `MV_CC_SetAcquisitionLineRate`✓ `MV_CC_SetAcquisitionMode`✓ `MV_CC_SetAOIoffsetX`✓ `MV_CC_SetAOIoffsetY`✓ `MV_CC_SetAutoExposureTimeLower`✓ `MV_CC_SetAutoExposureTimeUpper`✓ `MV_CC_SetBalanceRatioBlue`✓ `MV_CC_SetBalanceRatioGreen`✓ `MV_CC_SetBalanceRatioRed`✓ `MV_CC_SetBalanceWhiteAuto`✓ `MV_CC_SetBayerCLUTParam`✓ `MV_CC_SetBrightness`✓ `MV_CC_SetBurstFrameCount`✓ `MV_CC_SetDeviceUserID`✓ `MV_CC_SetExposureAutoMode`✓ `MV_CC_SetExposureTime`✓ `MV_CC_SetFrameRate`✓ `MV_CC_SetFrameSpecInfoAbility`✓ `MV_CC_SetGain`✓ `MV_CC_SetGainMode`✓ `MV_CC_SetGamma`✓ `MV_CC_SetGammaSelector`✓ `MV_CC_SetHeartBeatTimeout`✓ `MV_CC_SetHeight`✓ `MV_CC_SetHue`✓ `MV_CC_SetIntValue`✓ `MV_CC_SetPixelFormat`✓ `MV_CC_SetSaturation`✓ `MV_CC_SetSDKLogPath`✓ `MV_CC_SetSharpness`✓ `MV_CC_SetTriggerDelay`✓ `MV_CC_SetTriggerMode`✓ `MV_CC_SetTriggerSource`✓ `MV_CC_SetWidth`✓ `MV_CC_SpatialDenoise`✓ `MV_CC_TriggerSoftwareExecute`✓ `MV_GIGE_ForceIp`✓ `MV_GIGE_GetGevSCDA`✓ `MV_GIGE_GetGevSCPD`✓ `MV_GIGE_GetGevSCPSPacketSize`✓ `MV_GIGE_GetGevSCSP`✓ `MV_GIGE_SetGevSCDA`✓ `MV_GIGE_SetGevSCPD`✓ `MV_GIGE_SetGevSCPSPacketSize`✓ `MV_GIGE_SetGevSCSP`✓ `MV_USB_RegisterStreamExceptionCallBack`✓ `MV_XML_GetChildren`✓ `MV_XML_GetNodeFeature`✓ `MV_XML_GetRootNode`✓ `MV_XML_RegisterUpdateCallBack`✓ `MV_XML_UpdateNodeFeature`✓

</details>

### 17. 节点核对

来源：
- [CN] 相机参数节点表。该页自述“相机不是所有的节点都支持，请以客户端中的参数列表为准”。
- [VXML]：虚拟 MV-CS016-10UC 的 XML。类型取 XML 元素名；读写属性取 ImposedAccessMode，没有该项时取底层寄存器的 AccessMode。
- **[XLSX] 不能用于这一项核对**：它的两个工作表是“工业相机SDK可配置化参数”和“修改说明”，内容是 SDK 自身写在 CommonParameters.ini 里的参数（ImageNodeNum、GvcpTimeout、TransferSize、BayerCvtQuality 等），**不包含任何相机节点**。

表中“锁”指 [VXML] 中取流期间是否锁定（见第 9 项）。两份资料不一致的地方用 **粗体** 标出。

| 节点名 | 类型 | 读写属性 | 可选值或范围 | 来源 |
|---|---|---|---|---|
| `"ExposureTime"` | IFloat | R/W | ≥0.0，单位 us；[VXML] 范围由设备寄存器给出；ExposureAuto≠Off 时锁定 | 节点表；[VXML] |
| `"ExposureAuto"` | IEnumeration | R/W | 0:Off、1:Once、2:Continuous | 节点表；[VXML] 一致 |
| `"Gain"` | IFloat | R/W | ≥0.0，单位 dB；[VXML] 范围由设备给出；GainAuto≠Off 时锁定 | 节点表；[VXML] |
| `"GainAuto"` | IEnumeration | R/W | 0:Off、1:Once、2:Continuous | 节点表；[VXML] 一致 |
| `"Width"` | IInteger | R/(W) | >0；[VXML] 的 min/max/inc 由设备给出，取流期间锁定 | 节点表；[VXML] |
| `"Height"` | IInteger | R/(W) | >0；同上，取流期间锁定 | 节点表；[VXML] |
| `"OffsetX"` | IInteger | R/W | ≥0；[VXML] 中 Min=0，max/inc 由设备给出，**取流中不锁定** | 节点表；[VXML] |
| `"OffsetY"` | IInteger | R/W | ≥0；[VXML] 中是否锁定取决于能力位 | 节点表；[VXML] |
| `"WidthMax"` | IInteger | R | >0（binning 之后的值） | 节点表；[VXML] |
| `"HeightMax"` | IInteger | R | >0 | 节点表；[VXML] |
| `"PixelFormat"` | IEnumeration | R/(W) | 节点表列出 Mono8/10/12/16、RGB8Packed、YUV422_8、BayerGR8/RG8/GB8/BG8 等，其中 BayerGB8 = 0x0108000A；[VXML] 有 38 个选项（含 BayerGB8，但多数受 pIsImplemented 控制），取流期间锁定 | 节点表；[VXML] |
| `"PayloadSize"` | IInteger | R | ≥0，单位字节 | 节点表；[VXML] |
| `"AcquisitionMode"` | IEnumeration | R/(W) | 0:SingleFrame、1:MultiFrame、2:Continuous | 节点表；[VXML] 一致 |
| `"AcquisitionFrameRate"` | Float | RW | 单位 Fps，min/max 由设备动态给出，不锁定 | **节点表中没有**；仅 [VXML] |
| `"AcquisitionFrameRateEnable"` | Boolean | RW | true/false | **节点表中没有**；[VXML]；示例中按 Bool 写入 |
| `"ResultingFrameRate"` | IFloat | R | ≥0.0 fps | 节点表写“实际采集帧率”，**[VXML] 写“允许的最大帧率”** |
| `"TriggerMode"` | IEnumeration | R/W | 0:Off、1:On；[VXML] 中仅在 ExposureMode=TriggerWidth 时于取流中锁定 | 节点表；[VXML] |
| `"BalanceWhiteAuto"` | IEnumeration | R/W | 0:Off、1:Continuous、2:Once（注意 Once=2、Continuous=1，与 ExposureAuto 的顺序相反）；[VXML] 中黑白像素格式下不可用 | 节点表；[VXML]；头文件枚举 `MV_BALANCEWHITE_AUTO_ONCE`✓ = 2 |
| `"GammaEnable"` | IBoolean | R/W | 0:Off、1:On | 节点表；[VXML] |
| 锐化开关 `"SharpnessEnable"` | Boolean | RW | true/false | **节点表中没有**；仅 [VXML]（另有 `"Sharpness"`、`"SharpnessAuto"`） |
| 降噪模式 `"DigitalNoiseReductionMode"` | Enumeration | RW | Off=0、Normal=1、Expert=2 | **节点表中没有**；仅 [VXML]（另有 `"NoiseReduction"`、`"DenoiseStrength"` 等整数节点） |
| 对比度开关 `"ContrastRatioEnable"` | Boolean | RW | true/false | **节点表中没有**；仅 [VXML]（另有 `"ContrastRatio"`） |
| 数字增益开关 `"DigitalShiftEnable"` | IBoolean | R/W | 0:Off、1:On | 节点表；[VXML]（`"DigitalShift"` 在节点表中为 IFloat、R） |
| `"LUTEnable"` | IBoolean | R/W | True/False | 节点表；[VXML] |
| `"SequencerMode"` | Enumeration | RW | Off=0、On=1，取流期间锁定 | **节点表中没有**；仅 [VXML] |
| `"BlackLevel"` | **IFloat（节点表）/ Integer（[VXML]）** | R/W | ≥0；[VXML] 中 min/max 由设备给出，说明为“Analog black level in percent”；另有 `"BlackLevelEnable"` | 节点表；[VXML] |
| `"DeviceSerialNumber"` | IString | R | 字符串（[VXML] 中 64 字节） | 节点表；[VXML] |
| `"DeviceUserID"` | IString | R/W | 字符串（[VXML] 中 64 字节） | 节点表；[VXML] |
| `"DeviceModelName"` | IString | R | 字符串 | 节点表；[VXML] |
| USB 速度 | 节点表：`"DeviceConnectionSpeed"`（IInteger，R，单位 Mbps）、`"DeviceLinkSpeed"`（IInteger，R）；[VXML]：`"USBSpeedMode"`（Enumeration：HighSpeed=0x4、SuperSpeed=0x8）、`"U3VCurrentSpeed"`（Integer，RO） | | | 节点表；[VXML]（**[VXML] 中没有 DeviceConnectionSpeed 和 DeviceLinkSpeed**） |
| 设备最大带宽 `"DeviceMaxThroughput"` | IInteger | R | ≥0；[VXML] 说明为 “max data in KB from the camera each second” | 节点表；[VXML] |
| `"DeviceLinkCurrentThroughput"` | Integer | RO | 单位 KB，“actual bandwidth the camera will use” | **节点表中没有**；仅 [VXML] |
| 传输队列当前块数 `"TransferQueueCurrentBlockCount"` | Integer | RO | 上限为 `"TransferQueueMaxBlockCount"`（RW，Min=3，取流期间锁定） | **节点表中没有**；仅 [VXML] |
| `"DeviceUptime"` | IInteger | R | ≥0；[VXML] 显示名为 “Device Uptime(s)”，推断单位为秒 | 节点表；[VXML] |
| `"DeviceTemperature"` | Float | R | 单位 °C；由 `"DeviceTemperatureSelector"`（Sensor=0、Mainboard=1）选择测温位置 | **节点表中没有**；仅 [VXML] |
| `"UserSetSelector"` | IEnumeration | R/W | 0:Default、1:UserSet1、2:UserSet2、3:UserSet3 | 节点表；[VXML] 一致 |
| `"UserSetSave"` | ICommand | W | –；[VXML] 中选择 Default 时不可用 | 节点表；[VXML] |
| `"UserSetDefault"` | IEnumeration | R/W | 0:Default、1–3:UserSet1–3（上电时加载的配置） | 节点表；[VXML] |
| （相关）`"UserSetLoad"` | ICommand | W | 取流期间锁定 | 节点表；[VXML] |

### 18. 常见问题：与 USB、权限、丢帧、相机占用、帧率相关的条目

来源：[CN] 常见问题（下面的条目按原页的“GigE相机问题”和“USB3 Vision相机问题”两节挑选，其中前一节的很多条目其实是通用的）；[CN] 环境配置；[脚本]。

| 问题 | 文档给出的原因和解决方法 |
|---|---|
| USB 相机打开失败 | ① 驱动没有正确安装，或被识别成其他厂商的驱动：用 lsusb 命令检查；② 使用了 USB2.0 的线或端口：必须连接到 3.0 接口；③ 相机被其他进程连接：在客户端查看连接状态，关闭占用相机的程序；④ libusb 版本冲突导致符号异常：用 `ldd libMvUsb3vTL.so` 查看实际依赖的 libusb |
| USB 取流异常、丢帧、帧号重置 | ① USB 带宽不足：在客户端的 U3V 传输配置中调整传输包大小；用 USB 脚本调大 USB 缓存；降低分辨率或帧率；② EMC 干扰导致流链路重置、帧号重置：检查环境，减少静电，加磁环 |
| 权限（非 root 访问 U3V） | [CN] 环境配置：`set_usb_priority.sh`（设置 udev 规则，使普通用户也能使用 U3 相机）；`set_usbfs_memory_size.sh`（设置 USB 缓存，以兼容多台大分辨率 U3 相机）。文档建议使用 USB 相机时执行后者 |
| 丢帧（通用） | 取到图像后没有及时释放，SDK 缓存不足：及时调用 `MV_CC_FreeImageBuffer`✓，并用 `MV_CC_SetImageNodeNum`✓ 增大缓存 |
| `MV_CC_GetImageBuffer`✓ 报错无数据 | ① 相机没有出图（触发配置有问题）；② 出图间隔大于接口的超时时间：调大 nMsec；③ 上层没有及时释放图像，SDK 无空间可用 |
| 相机不出图 | 配置了触发模式但没有给触发信号：检查 `"TriggerMode"` 和触发源 |
| 开始取流失败 | 工控机内存不足：降低缓存节点数；Linux 句柄资源不足：`ulimit -n 65535` |
| 相机被占用 | 被其他进程连接（见上文）。文档中“心跳超时后才释放”的条目属于 GigE，USB 相机不适用 |
| 帧率达不到 | 常见问题中**没有专门的条目**，最接近的是上面的带宽不足条目。帧率的限制因素见第 4 项和第 13 项 |
| 排查思路 | 先运行 MVS 客户端确认功能正常：客户端正常就重点查自己的程序，客户端也异常再按上述条目处理 |

### 19. 图像处理：Bayer 转 RGB

来源：[CN] 处理图像（像素格式转换）；[H:MvCameraControl.h]:2770–2880；[H:CameraParams.h]:722–740；[H:PixelType.h]:57、83；[XLSX]（IMG_PROCESSING）。

```c
int __stdcall MV_CC_ConvertPixelTypeEx(IN void* handle, IN OUT MV_CC_PIXEL_CONVERT_PARAM_EX* pstCvtParam);  // ✓
int __stdcall MV_CC_SetBayerCvtQuality(IN void* handle, IN unsigned int nBayerCvtQuality);  // ✓
int __stdcall MV_CC_SetBayerFilterEnable(IN void* handle, IN bool bFilterEnable);  // ✓
int __stdcall MV_CC_SetBayerGammaValue(IN void* handle, IN float fBayerGammaValue);  // ✓

typedef struct _MV_CC_PIXEL_CONVERT_PARAM_EX_  // ✓
{
    unsigned int nWidth;                   // [IN] 图像宽 ✓
    unsigned int nHeight;                  // [IN] 图像高 ✓
    enum MvGvspPixelType enSrcPixelType;   // [IN] 源像素格式 ✓
    unsigned char* pSrcData;               // [IN] 输入数据缓存 ✓
    unsigned int nSrcDataLen;              // [IN] 输入数据长度 ✓
    enum MvGvspPixelType enDstPixelType;   // [IN] 目标像素格式 ✓
    unsigned char* pDstBuffer;             // [OUT] 输出数据缓存 ✓
    unsigned int nDstLen;                  // [OUT] 输出数据长度 ✓
    unsigned int nDstBufferSize;           // [IN] 提供的输出缓冲区大小 ✓
    unsigned int nRes[4];  // ✓
}MV_CC_PIXEL_CONVERT_PARAM_EX;  // ✓
```

- 用法：先用 `MV_CC_SetBayerCvtQuality`✓ 设置插值质量（0 快速、1 均衡（默认）、2 最优、3 最优+；[XLSX] 注明 Linux aarch64 不支持“最优+”）。然后填写源和目标信息：源像素格式为 `PixelType_Gvsp_BayerGB8`✓，目标为 `PixelType_Gvsp_RGB8_Packed`✓ 或 `PixelType_Gvsp_BGR8_Packed`✓，输出缓冲区大小为 宽×高×3。最后调用 `MV_CC_ConvertPixelTypeEx`✓。
- 可选设置：平滑用 `MV_CC_SetBayerFilterEnable`✓（默认关闭）；Gamma 用 `MV_CC_SetBayerGammaValue`✓（0.1–4.0）。插值线程数在 [INI] 中用 BayerCvtThreadNum 设置，默认 4。
- 头文件中的转换能力表显示：BayerGB8 可以转为 Mono8、RGB24、BGR24、RGB24 Planar、YUV422 和 YUV422 YUYV。JPEG 压缩的图像不能用这个接口转换。
- **建议**：驱动节点直接发布原始 Bayer 图（ROS 编码为 bayer_gbrg8），把去马赛克留给下游按需处理，这样每台相机每秒可以省去约 236 MB 的 RGB 数据拷贝（1280×1024×3×60）。

---

## 文档、头文件及其他资料之间的不一致

| # | 不一致内容 | 出处 |
|---|---|---|
| 1 | [CN] 设置参数页的枚举示例把 `MVCC_ENUMVALUE`✓ 类型的变量传给 `MV_CC_GetEnumValueEx`✓，而头文件要求的是 `MVCC_ENUMVALUE_EX`✓ 指针，照抄示例在 C++ 下无法编译 | [CN] 设置参数 vs [H:MvCameraControl.h]:1306 |
| 2 | [CN] 初始化相机页说 `MV_CC_OpenDevice`✓ 默认“独占”访问权限；头文件说 USB3 设备和虚拟设备的 `nAccessMode`✓ 无效、“默认以控制权限打开” | [CN] 初始化相机 vs [H:MvCameraControl.h]:470–507 |
| 3 | `MV_CC_GetImageBuffer`✓ 的注释说可以传入 INFINITE，但 `/opt/MVS/include` 中没有定义这个宏 | [H:MvCameraControl.h]:694 |
| 4 | 废弃接口 `MV_CC_GetOneFrame`✓ / `MV_CC_GetOneFrameEx`✓ 的注释建议改用 `MV_CC_GetOneFrameTimeOut`?（大写 O），实际函数名是 `MV_CC_GetOneFrameTimeout`✓ | [H:MvObsoleteInterfaces.h]:174、197 |
| 5 | 头文件中仍在使用的接口，其注释引用了已废弃的函数：`MV_CC_GetImageBuffer`✓ 的注释提到 `MV_CC_Display`✓；`MV_CC_SetBayerCvtQuality`✓ 的注释提到 `MV_CC_GetImageForRGB`✓ 和 `MV_CC_GetImageForBGR`✓；`MV_CC_SetBayerGammaValue`✓ 的注释提到 `MV_CC_SaveImageToFile`✓ | [H:MvCameraControl.h]:690、2827、2861 |
| 6 | `deprecated.html` 只列出 2 个已弃用接口，而废弃接口分组页和 `MvObsoleteInterfaces.h` 中有 114 个 | [CN] |
| 7 | `"ResultingFrameRate"`：节点表写“相机的实际采集帧率”，[VXML] 写“当前设置下允许的最大帧率” | [CN] 节点表 vs [VXML] |
| 8 | `"BlackLevel"`：节点表中是 IFloat，[VXML] 中是 Integer | [CN] 节点表 vs [VXML] |
| 9 | `"DeviceTimestampIncrement"`：用户手册（据你转述）称其为“设备时间戳的最大值”，[VXML] 中是 “ns/tick”；[VXML] 内部还存在 ImposedAccessMode=RW 而寄存器为 RO 的矛盾 | 用户手册（不在资料范围内） vs [VXML] |
| 10 | 文档要求“请勿通过异常事件回调函数执行耗时较长的操作”，但 ReconnectDemo 在异常回调里循环枚举并重连 | [CN] 事件及异常 vs [S]`General/ReconnectDemo/ReconnectDemo.cpp`:101–240 |
| 11 | `MV_EVENT_OUT_INFO`✓ 的 BlockId 字段在头文件中标注“暂无固件支持”，文档示例却照常拼接并打印 BlockId | [H:CameraParams.h]:1092–1110 vs [CN] 事件及异常 |
| 12 | Linux 开发指南的示例代码使用了 Windows 专有写法（_beginthreadex、__int64、%I64d） | [CN] 采集图像、事件及异常 |
| 13 | [README] 标注的版本号是 4.5.0，而 SDK 实际是 4.9.0 | `/opt/MVS/Samples/README-CH` |
| 14 | [CN] 设置参数页把 `MV_USB_SetTransferWays`✓ 描述为“配置SDK内部的流通道缓存个数”，头文件则写的是“传输通道个数，范围1-10”（只是措辞不同） | [CN] 设置参数 vs [H:MvCameraControl.h]:2490 |

---

## 仍未解决的问题与建议的验证实验

除特别注明外，每个实验都要先在虚拟相机上跑通，再在 MV-CB013 真机上重做。真机的结论为准。

| 编号 | 问题 | 建议的验证实验 |
|---|---|---|
| U1 | `"DeviceTimestamp"` 的读数是 ns 还是 tick？`"DeviceTimestampIncrement"` 的实际值是多少？ | 读 Increment。然后间隔约 10 s 执行两次“记 `CLOCK_MONOTONIC` → Latch → 读 → 记 `CLOCK_MONOTONIC`”，计算设备差值与主机差值之比：约等于 1 说明是 ns，约等于 1/Increment 说明是 tick |
| U2 | 取流中能否执行 Latch？不执行 Latch 时，重复读 `"DeviceTimestamp"` 是实时值、锁存值还是旧的缓存值？ | 在取流中以 100 Hz 执行 Latch 并读值，检查返回码和单调性；不 Latch、每隔 10 ms 连续读 20 次，看值是否变化；再试一次先调用 `MV_CC_InvalidateNodes`✓ 后读 |
| U3 | 帧的 `nDevTimeStampHigh`✓/`nDevTimeStampLow`✓ 与 `"DeviceTimestamp"` 是否同一时钟、同一单位？ | 60 Hz 取流时，在取到每帧后立即 Latch 并读值，比较 帧时间戳 ≤ 锁存值 是否始终成立，以及差值的分布；同时检查相邻帧时间戳差是否约等于 16.67 ms（按 ns 或 tick 换算） |
| U4 | 帧时间戳对应曝光开始、曝光结束、读出还是传输完成？ | ① 若真机支持 ExposureStart/ExposureEnd/FrameStart 事件，把事件时间戳与同一帧的帧时间戳相减；② 固定帧率，把曝光在 1 ms 和 10 ms 之间切换：若“帧时间戳 − 曝光开始”随之变化 9 ms，说明帧时间戳在曝光结束或之后；③ 条件允许时，用相机的 Strobe/ExposureActive 输出接示波器，与主机 GPIO 对比 |
| U5 | `nHostTimeStamp`✓ 用的是哪个时钟、什么单位、在什么时刻打上？ | 在 `MV_CC_GetImageBuffer`✓ 返回后立刻读取 `CLOCK_REALTIME`、`CLOCK_MONOTONIC` 和 `CLOCK_MONOTONIC_RAW`，比较数量级（判断单位是 ms、us 还是 ns）和差值是否稳定；只在测试机上用 `date -s` 让系统时间跳变，看它是否跟着跳 |
| U6 | 同一句柄的多线程并发是否安全？进程退出时在静态析构里调用 `MV_CC_Finalize`✓ 是否安全？ | 两台相机各一个取图线程（60 Hz，超时 200 ms），另起一个控制线程以 100 Hz 执行 Latch + 读值，并每秒切换曝光和增益，连续运行 2 h，统计错误码、崩溃、帧号跳变和延迟；再分别跑“控制调用加锁”和“不加锁”两种版本对照；最后加载、卸载组件 100 次，并多次正常退出进程，检查是否挂起 |
| U7 | 取图线程阻塞在 `MV_CC_GetImageBuffer`✓ 时调用 `MV_CC_StopGrabbing`✓，会有什么结果？ | 取图线程用 5000 ms 超时等待，另一线程在不同时机调用 StopGrabbing，记录 GetImageBuffer 返回所需的时间和返回码，以及 StopGrabbing 的耗时和返回码，重复 1000 次 |
| U8 | `"ResultingFrameRate"` 表示实际帧率还是允许的最大帧率？ | 设置 `"AcquisitionFrameRateEnable"`=true、`"AcquisitionFrameRate"`=30，读 `"ResultingFrameRate"`：读数为 30 说明是实际帧率，读数为更高的值说明是最大值。再用帧时间戳统计实际帧率作对照 |
| U9 | 在 MV-CB013 上，帧率、曝光和 ROI 之间的制约关系是什么？ | 在全幅和若干 ROI 下扫描 `"ExposureTime"`，每一步记录 `"AcquisitionFrameRate"` 的 fMax、`"ResultingFrameRate"` 和实测帧率，找出 60 Hz 时允许的最大曝光 |
| U10 | 真机实际有哪些节点，类型、读写属性和锁定条件分别是什么？写入被锁定的节点会返回哪个错误码？ | 用 `MV_XML_GetGenICamXML`✓ 导出真机 XML，用本笔记的方法复核第 1、4、9、17 项（尤其是三个 DeviceTimestamp 节点的 ToolTip）；在取流中逐个写入 Width、OffsetX、ExposureTime 等节点，记录返回码 |
| U11 | `"DeviceUserID"` 断电后是否保留？ | 设置为 left 和 right，断电、重新插拔后重新枚举，检查 `chUserDefinedName`✓ |
| U12 | 对时一次（Latch + 读值）在 USB 上的往返延迟和抖动有多大？ | 采样 10000 次，记录 rtt 的分布（中位数、p99、最小值），据此确定样本筛选阈值；分别在空闲和两台相机满速取流时测量 |
| U13 | 两个时钟的漂移有多大？多久需要重新对时？线性模型够不够？ | 每秒对时一次，连续 2 h 以上（冷启动到热平衡），拟合 offset+drift，看残差和残差随时间的趋势，确定对时周期和窗口长度 |
| U14 | 设备时间戳在 StartGrabbing/StopGrabbing、重新打开、`"DeviceReset"`、断电和 UserSetLoad 之后是否会重置？ | 在每个动作前后各 Latch 一次，并读 `"DeviceUptime"` 作对照 |
| U15 | 两台相机 60 Hz 同时运行时，USB 带宽和主机资源是否足够？ | 用 `lsusb -t` 确认两台相机是否挂在不同的控制器上；跑 1 h，统计 `nErrorFrameCount`✓、流异常和帧号跳变；对比 TransferSize 和 TransferWays 的不同取值 |
| U16 | 虚拟相机的时间戳、事件和锁定行为能否代表真机？ | 在虚拟相机和真机上跑 U1–U4、U10，逐项对比；结论不一致的地方以真机为准，开发阶段的代码不要依赖虚拟相机特有的行为 |
| U17 | 帧信息中的水印字段（`nSecondCount`✓、`nCycleCount`✓、`nCycleOffset`✓、`nFrameCounter`✓）在 USB 相机上什么时候填充？与 `nDevTimeStampHigh`✓/`nDevTimeStampLow`✓ 是什么关系？ | 分别在关闭和开启 `"FrameSpecInfoSelector"`=Timestamp/Framecounter、`"FrameSpecInfo"`=true 的情况下取图，记录这几个字段与 `nDevTimeStampHigh`✓/`nDevTimeStampLow`✓ 的变化 |

---

## 名称核对（/opt/MVS/include）

核对方法：用脚本把 `/opt/MVS/include/*.h` 中的注释和字符串字面量去掉，只在剩下的代码里查找。

- 行内名称：反引号中的 C 标识符逐个查找；`A.b.c` 这种成员路径，每一段都要找到才标 ✓。带双引号的节点名、环境变量、路径和系统头文件中的名字（`CLOCK_MONOTONIC`、scanf、pthread_create 等）以及 C 关键字不在核对范围内。E 节中由示例程序自己定义的名字仍标为 ?，下表注明了它们在示例文件中的位置。
- `c` 代码块：每一行去掉注释并删除全部空白后，必须在头文件代码中原样出现；`typedef struct/enum` 中的行还必须出现在同名 typedef 内部，且顺序一致。

结果：行内共标注 664 处，涉及 344 个不同的名字，其中 ✓ 336 个、? 8 个。`c` 代码块共核对 540 行，✓ 540 行、? 0 行。

标为 ? 的名字：

| 名字 | 结果 | 头文件中的位置 | 说明 |
|---|---|---|---|
| INFINITE | ? | MvCameraControl.h:694 | 仅出现在注释中 |
| MV_CC_GetOneFrameTimeOut | ? | MvObsoleteInterfaces.h:174 | 仅出现在注释中 |
| PressEnterToExit | ? | – | 示例程序自身定义的名字（GrabImage_HighPerformance.cpp:13），不是 SDK 头文件中的名字 |
| PrintDeviceInfo | ? | – | 示例程序自身定义的名字（GrabImage_HighPerformance.cpp:23），不是 SDK 头文件中的名字 |
| WorkThread | ? | – | 示例程序自身定义的名字（GrabImage_HighPerformance.cpp:85），不是 SDK 头文件中的名字 |
| g_bExit | ? | – | 示例程序自身定义的名字（GrabImage_HighPerformance.cpp:8），不是 SDK 头文件中的名字 |
| g_nPayloadSize | ? | – | 示例程序自身定义的名字（GrabImage_HighPerformance.cpp:9），不是 SDK 头文件中的名字 |
| nIndex | ? | – | 示例程序自身定义的名字（GrabImage_HighPerformance.cpp:166），不是 SDK 头文件中的名字 |

<details><summary>全部已找到（✓）的名字及其在头文件代码中首次出现的位置</summary>

| 名字 | 位置 |
|---|---|
| AM_NA | CameraParams.h:1233 |
| AM_NI | CameraParams.h:1232 |
| AM_RO | CameraParams.h:1235 |
| AM_RW | CameraParams.h:1236 |
| AM_WO | CameraParams.h:1234 |
| EventName | CameraParams.h:1094 |
| IFT_IFloat | CameraParams.h:1220 |
| IFT_IInteger | CameraParams.h:1217 |
| MVCC_ENUMENTRY | CameraParams.h:1334 |
| MVCC_ENUMVALUE | CameraParams.h:1307 |
| MVCC_ENUMVALUE_EX | CameraParams.h:1321 |
| MVCC_FLOATVALUE | CameraParams.h:1369 |
| MVCC_INTVALUE_EX | CameraParams.h:1358 |
| MVCC_STRINGVALUE | CameraParams.h:1379 |
| MV_1394_DEVICE | CameraParams.h:162 |
| MV_ACCESS_Exclusive | CameraParams.h:315 |
| MV_ACCESS_Monitor | CameraParams.h:321 |
| MV_ACTION_CMD_INFO | CameraParams.h:1186 |
| MV_BALANCEWHITE_AUTO_ONCE | CameraParams.h:999 |
| MV_CAML_GetDeviceBauderate | MvObsoleteInterfaces.h:1817 |
| MV_CAML_GetSupportBauderates | MvObsoleteInterfaces.h:1834 |
| MV_CAML_GetSupportBaudrates | MvCameraControl.h:2428 |
| MV_CAML_SetDeviceBauderate | MvObsoleteInterfaces.h:1800 |
| MV_CC_BayerNoiseEstimate | MvObsoleteInterfaces.h:319 |
| MV_CC_BayerSpatialDenoise | MvObsoleteInterfaces.h:338 |
| MV_CC_ClearImageBuffer | MvCameraControl.h:778 |
| MV_CC_CloseDevice | MvCameraControl.h:580 |
| MV_CC_ColorCorrect | MvObsoleteInterfaces.h:387 |
| MV_CC_ConvertPixelType | MvObsoleteInterfaces.h:1913 |
| MV_CC_ConvertPixelTypeEx | MvCameraControl.h:2824 |
| MV_CC_CreateHandle | MvCameraControl.h:467 |
| MV_CC_CreateHandleWithoutLog | MvObsoleteInterfaces.h:1979 |
| MV_CC_CreateInterfaceByID | MvCameraControl.h:1166 |
| MV_CC_DEVICE_INFO | CameraParams.h:203 |
| MV_CC_DEVICE_INFO_LIST | CameraParams.h:216 |
| MV_CC_DestroyHandle | MvCameraControl.h:595 |
| MV_CC_Display | MvObsoleteInterfaces.h:499 |
| MV_CC_DisplayOneFrame | MvObsoleteInterfaces.h:1946 |
| MV_CC_EnumDevices | MvCameraControl.h:307 |
| MV_CC_EnumDevicesEx | MvCameraControl.h:347 |
| MV_CC_EnumDevicesEx2 | MvCameraControl.h:395 |
| MV_CC_EnumerateTls | MvObsoleteInterfaces.h:1959 |
| MV_CC_EventNotificationOff | MvCameraControl.h:1920 |
| MV_CC_EventNotificationOn | MvCameraControl.h:1905 |
| MV_CC_Finalize | MvCameraControl.h:237 |
| MV_CC_FreeImageBuffer | MvCameraControl.h:732 |
| MV_CC_GetAOIoffsetX | MvObsoleteInterfaces.h:643 |
| MV_CC_GetAOIoffsetY | MvObsoleteInterfaces.h:677 |
| MV_CC_GetAcquisitionLineRate | MvObsoleteInterfaces.h:1606 |
| MV_CC_GetAcquisitionMode | MvObsoleteInterfaces.h:985 |
| MV_CC_GetAllMatchInfo | MvCameraControl.h:565 |
| MV_CC_GetAutoExposureTimeLower | MvObsoleteInterfaces.h:711 |
| MV_CC_GetAutoExposureTimeUpper | MvObsoleteInterfaces.h:745 |
| MV_CC_GetBalanceRatioBlue | MvObsoleteInterfaces.h:1474 |
| MV_CC_GetBalanceRatioGreen | MvObsoleteInterfaces.h:1440 |
| MV_CC_GetBalanceRatioRed | MvObsoleteInterfaces.h:1406 |
| MV_CC_GetBalanceWhiteAuto | MvObsoleteInterfaces.h:1372 |
| MV_CC_GetBoolValue | MvCameraControl.h:1420 |
| MV_CC_GetBrightness | MvObsoleteInterfaces.h:779 |
| MV_CC_GetBurstFrameCount | MvObsoleteInterfaces.h:1572 |
| MV_CC_GetDeviceInfo | MvCameraControl.h:540 |
| MV_CC_GetDeviceUserID | MvObsoleteInterfaces.h:1538 |
| MV_CC_GetEnumEntrySymbolic | MvCameraControl.h:1344 |
| MV_CC_GetEnumValue | MvCameraControl.h:1285 |
| MV_CC_GetEnumValueEx | MvCameraControl.h:1306 |
| MV_CC_GetExposureAutoMode | MvObsoleteInterfaces.h:1053 |
| MV_CC_GetExposureTime | MvObsoleteInterfaces.h:905 |
| MV_CC_GetFloatValue | MvCameraControl.h:1382 |
| MV_CC_GetFrameRate | MvObsoleteInterfaces.h:821 |
| MV_CC_GetFrameSpecInfoAbility | MvObsoleteInterfaces.h:1508 |
| MV_CC_GetGain | MvObsoleteInterfaces.h:863 |
| MV_CC_GetGainMode | MvObsoleteInterfaces.h:1019 |
| MV_CC_GetGamma | MvObsoleteInterfaces.h:1236 |
| MV_CC_GetGammaSelector | MvObsoleteInterfaces.h:1202 |
| MV_CC_GetHeartBeatTimeout | MvObsoleteInterfaces.h:1640 |
| MV_CC_GetHeight | MvObsoleteInterfaces.h:609 |
| MV_CC_GetHue | MvObsoleteInterfaces.h:1304 |
| MV_CC_GetImageBuffer | MvCameraControl.h:713 |
| MV_CC_GetImageForBGR | MvObsoleteInterfaces.h:2100 |
| MV_CC_GetImageForRGB | MvObsoleteInterfaces.h:2067 |
| MV_CC_GetImageInfo | MvObsoleteInterfaces.h:62 |
| MV_CC_GetIntValue | MvObsoleteInterfaces.h:520 |
| MV_CC_GetIntValueEx | MvCameraControl.h:1247 |
| MV_CC_GetOneFrame | MvObsoleteInterfaces.h:191 |
| MV_CC_GetOneFrameEx | MvObsoleteInterfaces.h:214 |
| MV_CC_GetOneFrameTimeout | MvCameraControl.h:759 |
| MV_CC_GetOptimalPacketSize | MvCameraControl.h:2170 |
| MV_CC_GetPayloadSize | MvCameraControl.h:914 |
| MV_CC_GetPixelFormat | MvObsoleteInterfaces.h:947 |
| MV_CC_GetSDKVersion | MvCameraControl.h:261 |
| MV_CC_GetSaturation | MvObsoleteInterfaces.h:1338 |
| MV_CC_GetSharpness | MvObsoleteInterfaces.h:1270 |
| MV_CC_GetStringValue | MvCameraControl.h:1458 |
| MV_CC_GetTlProxy | MvObsoleteInterfaces.h:75 |
| MV_CC_GetTriggerDelay | MvObsoleteInterfaces.h:1121 |
| MV_CC_GetTriggerMode | MvObsoleteInterfaces.h:1087 |
| MV_CC_GetTriggerSource | MvObsoleteInterfaces.h:1155 |
| MV_CC_GetValidImageNum | MvCameraControl.h:795 |
| MV_CC_GetWidth | MvObsoleteInterfaces.h:575 |
| MV_CC_IMAGE | CameraParams.h:348 |
| MV_CC_ImageSharpen | MvObsoleteInterfaces.h:370 |
| MV_CC_Initialize | MvCameraControl.h:224 |
| MV_CC_InvalidateNodes | MvCameraControl.h:1647 |
| MV_CC_IsDeviceAccessible | MvCameraControl.h:448 |
| MV_CC_IsDeviceConnected | MvCameraControl.h:521 |
| MV_CC_LSCCalib | MvObsoleteInterfaces.h:437 |
| MV_CC_LSCCorrect | MvObsoleteInterfaces.h:452 |
| MV_CC_NoiseEstimate | MvObsoleteInterfaces.h:404 |
| MV_CC_OpenDevice | MvCameraControl.h:505 |
| MV_CC_OpenParamsGUI | MvObsoleteInterfaces.h:2120 |
| MV_CC_PIXEL_CONVERT_PARAM_EX | CameraParams.h:740 |
| MV_CC_RegisterBuffer | MvCameraControl.h:943 |
| MV_CC_RegisterEventCallBack | MvObsoleteInterfaces.h:484 |
| MV_CC_RegisterEventCallBackEx | MvCameraControl.h:1869 |
| MV_CC_RegisterExceptionCallBack | MvCameraControl.h:1825 |
| MV_CC_RegisterImageCallBack | MvObsoleteInterfaces.h:231 |
| MV_CC_RegisterImageCallBackEx | MvCameraControl.h:627 |
| MV_CC_RegisterImageCallBackEx2 | MvCameraControl.h:657 |
| MV_CC_RegisterImageCallBackForBGR | MvObsoleteInterfaces.h:2034 |
| MV_CC_RegisterImageCallBackForRGB | MvObsoleteInterfaces.h:2006 |
| MV_CC_RegisterStreamExceptionCallBack | MvCameraControl.h:1890 |
| MV_CC_STREAM_EXCEPTION_DISCONNECTED | CameraParams.h:1071 |
| MV_CC_STREAM_EXCEPTION_LIST_OVERFLOW | CameraParams.h:1068 |
| MV_CC_STREAM_EXCEPTION_RECONNECTION | CameraParams.h:1070 |
| MV_CC_SaveImage | MvObsoleteInterfaces.h:264 |
| MV_CC_SaveImageEx | MvObsoleteInterfaces.h:300 |
| MV_CC_SaveImageEx2 | MvObsoleteInterfaces.h:1872 |
| MV_CC_SaveImageToFile | MvObsoleteInterfaces.h:1890 |
| MV_CC_SavePointCloudData | MvObsoleteInterfaces.h:2141 |
| MV_CC_SetAOIoffsetX | MvObsoleteInterfaces.h:658 |
| MV_CC_SetAOIoffsetY | MvObsoleteInterfaces.h:692 |
| MV_CC_SetAcquisitionLineRate | MvObsoleteInterfaces.h:1621 |
| MV_CC_SetAcquisitionMode | MvObsoleteInterfaces.h:1000 |
| MV_CC_SetAutoExposureTimeLower | MvObsoleteInterfaces.h:726 |
| MV_CC_SetAutoExposureTimeUpper | MvObsoleteInterfaces.h:760 |
| MV_CC_SetBalanceRatioBlue | MvObsoleteInterfaces.h:1489 |
| MV_CC_SetBalanceRatioGreen | MvObsoleteInterfaces.h:1455 |
| MV_CC_SetBalanceRatioRed | MvObsoleteInterfaces.h:1421 |
| MV_CC_SetBalanceWhiteAuto | MvObsoleteInterfaces.h:1387 |
| MV_CC_SetBayerCLUTParam | MvObsoleteInterfaces.h:355 |
| MV_CC_SetBayerCvtQuality | MvCameraControl.h:2841 |
| MV_CC_SetBayerFilterEnable | MvCameraControl.h:2858 |
| MV_CC_SetBayerGammaValue | MvCameraControl.h:2875 |
| MV_CC_SetBoolValue | MvCameraControl.h:1439 |
| MV_CC_SetBrightness | MvObsoleteInterfaces.h:794 |
| MV_CC_SetBurstFrameCount | MvObsoleteInterfaces.h:1587 |
| MV_CC_SetCommandValue | MvCameraControl.h:1494 |
| MV_CC_SetDeviceUserID | MvObsoleteInterfaces.h:1553 |
| MV_CC_SetEnumValue | MvCameraControl.h:1325 |
| MV_CC_SetEnumValueByString | MvCameraControl.h:1363 |
| MV_CC_SetExposureAutoMode | MvObsoleteInterfaces.h:1068 |
| MV_CC_SetExposureTime | MvObsoleteInterfaces.h:920 |
| MV_CC_SetFloatValue | MvCameraControl.h:1401 |
| MV_CC_SetFrameRate | MvObsoleteInterfaces.h:836 |
| MV_CC_SetFrameSpecInfoAbility | MvObsoleteInterfaces.h:1523 |
| MV_CC_SetGain | MvObsoleteInterfaces.h:878 |
| MV_CC_SetGainMode | MvObsoleteInterfaces.h:1034 |
| MV_CC_SetGamma | MvObsoleteInterfaces.h:1251 |
| MV_CC_SetGammaSelector | MvObsoleteInterfaces.h:1217 |
| MV_CC_SetGrabStrategy | MvCameraControl.h:845 |
| MV_CC_SetHeartBeatTimeout | MvObsoleteInterfaces.h:1655 |
| MV_CC_SetHeight | MvObsoleteInterfaces.h:624 |
| MV_CC_SetHue | MvObsoleteInterfaces.h:1319 |
| MV_CC_SetImageNodeNum | MvCameraControl.h:818 |
| MV_CC_SetIntValue | MvObsoleteInterfaces.h:541 |
| MV_CC_SetIntValueEx | MvCameraControl.h:1266 |
| MV_CC_SetOutputQueueSize | MvCameraControl.h:863 |
| MV_CC_SetPixelFormat | MvObsoleteInterfaces.h:966 |
| MV_CC_SetSDKLogPath | MvObsoleteInterfaces.h:1929 |
| MV_CC_SetSaturation | MvObsoleteInterfaces.h:1353 |
| MV_CC_SetSharpness | MvObsoleteInterfaces.h:1285 |
| MV_CC_SetStringValue | MvCameraControl.h:1477 |
| MV_CC_SetTriggerDelay | MvObsoleteInterfaces.h:1136 |
| MV_CC_SetTriggerMode | MvObsoleteInterfaces.h:1102 |
| MV_CC_SetTriggerSource | MvObsoleteInterfaces.h:1170 |
| MV_CC_SetWidth | MvObsoleteInterfaces.h:590 |
| MV_CC_SpatialDenoise | MvObsoleteInterfaces.h:419 |
| MV_CC_StartGrabbing | MvCameraControl.h:672 |
| MV_CC_StopGrabbing | MvCameraControl.h:687 |
| MV_CC_TriggerSoftwareExecute | MvObsoleteInterfaces.h:1183 |
| MV_CHUNK_DATA_CONTENT | CameraParams.h:332 |
| MV_EVENT_OUT_INFO | CameraParams.h:1110 |
| MV_EXCEPTION_DEV_DISCONNECT | CameraParams.h:1061 |
| MV_EXCEPTION_VERSION_CHECK | CameraParams.h:1062 |
| MV_E_ABNORMAL_IMAGE | MvErrorDefine.h:34 |
| MV_E_ACCESS_DENIED | MvErrorDefine.h:121 |
| MV_E_BUFOVER | MvErrorDefine.h:26 |
| MV_E_BUSY | MvErrorDefine.h:122 |
| MV_E_CALLORDER | MvErrorDefine.h:27 |
| MV_E_DEV_OFFLINE | MvErrorDefine.h:57 |
| MV_E_GC_ACCESS | MvErrorDefine.h:99 |
| MV_E_GC_NODE_NOT_FOUND | MvErrorDefine.h:103 |
| MV_E_GC_RANGE | MvErrorDefine.h:95 |
| MV_E_GC_TIMEOUT | MvErrorDefine.h:100 |
| MV_E_HANDLE | MvErrorDefine.h:24 |
| MV_E_NODATA | MvErrorDefine.h:30 |
| MV_E_NOENOUGH_BUF | MvErrorDefine.h:33 |
| MV_E_NOOUTBUF | MvErrorDefine.h:36 |
| MV_E_PARAMETER | MvErrorDefine.h:28 |
| MV_E_PARAMETER_RANGE | MvErrorDefine.h:62 |
| MV_E_PRECONDITION | MvErrorDefine.h:31 |
| MV_E_RESOURCE | MvErrorDefine.h:29 |
| MV_E_RESOURCE_IN_USE | MvErrorDefine.h:65 |
| MV_E_SUPPORT | MvErrorDefine.h:25 |
| MV_E_UNKNOW | MvErrorDefine.h:82 |
| MV_E_USB_BANDWIDTH | MvErrorDefine.h:158 |
| MV_E_USB_DEVICE | MvErrorDefine.h:156 |
| MV_E_USB_DRIVER | MvErrorDefine.h:159 |
| MV_E_USB_READ | MvErrorDefine.h:154 |
| MV_E_USB_WRITE | MvErrorDefine.h:155 |
| MV_FRAME_OUT | CameraParams.h:525 |
| MV_FRAME_OUT_INFO_EX | CameraParams.h:515 |
| MV_GIGE_DEVICE_INFO | CameraParams.h:43 |
| MV_GIGE_ForceIp | MvObsoleteInterfaces.h:467 |
| MV_GIGE_GetGevSCDA | MvObsoleteInterfaces.h:1738 |
| MV_GIGE_GetGevSCPD | MvObsoleteInterfaces.h:1708 |
| MV_GIGE_GetGevSCPSPacketSize | MvObsoleteInterfaces.h:1674 |
| MV_GIGE_GetGevSCSP | MvObsoleteInterfaces.h:1768 |
| MV_GIGE_IssueActionCommand | MvCameraControl.h:2307 |
| MV_GIGE_MULTI_PART_INFO | CameraParams.h:434 |
| MV_GIGE_SetGevSCDA | MvObsoleteInterfaces.h:1753 |
| MV_GIGE_SetGevSCPD | MvObsoleteInterfaces.h:1723 |
| MV_GIGE_SetGevSCPSPacketSize | MvObsoleteInterfaces.h:1689 |
| MV_GIGE_SetGevSCSP | MvObsoleteInterfaces.h:1783 |
| MV_MATCH_INFO_USB_DETECT | CameraParams.h:582 |
| MV_MATCH_TYPE_USB_DETECT | CameraParams.h:550 |
| MV_OK | MvErrorDefine.h:14 |
| MV_USB3_DEVICE_INFO | CameraParams.h:70 |
| MV_USB_DEVICE | CameraParams.h:163 |
| MV_USB_RegisterStreamExceptionCallBack | MvObsoleteInterfaces.h:1851 |
| MV_USB_SetEventNodeNum | MvCameraControl.h:2540 |
| MV_USB_SetSyncTimeOut | MvCameraControl.h:2557 |
| MV_USB_SetTransferSize | MvCameraControl.h:2470 |
| MV_USB_SetTransferWays | MvCameraControl.h:2504 |
| MV_VIR_USB_DEVICE | CameraParams.h:166 |
| MV_XML_GetChildren | MvObsoleteInterfaces.h:107 |
| MV_XML_GetGenICamXML | MvCameraControl.h:1670 |
| MV_XML_GetNodeAccessMode | MvCameraControl.h:1511 |
| MV_XML_GetNodeFeature | MvObsoleteInterfaces.h:126 |
| MV_XML_GetNodeInterfaceType | MvCameraControl.h:1530 |
| MV_XML_GetRootNode | MvObsoleteInterfaces.h:90 |
| MV_XML_RegisterUpdateCallBack | MvObsoleteInterfaces.h:162 |
| MV_XML_UpdateNodeFeature | MvObsoleteInterfaces.h:143 |
| PixelType_Gvsp_BGR8_Packed | PixelType.h:84 |
| PixelType_Gvsp_BayerBG8 | PixelType.h:58 |
| PixelType_Gvsp_BayerGB8 | PixelType.h:57 |
| PixelType_Gvsp_BayerGR8 | PixelType.h:55 |
| PixelType_Gvsp_BayerRG8 | PixelType.h:56 |
| PixelType_Gvsp_Mono8 | PixelType.h:45 |
| PixelType_Gvsp_RGB8_Packed | PixelType.h:83 |
| SortMethod_SerialNumber | CameraParams.h:16 |
| SortMethod_UserID | CameraParams.h:17 |
| SpecialInfo | CameraParams.h:201 |
| bValue | MvCameraControl.h:1439 |
| cbEvent | MvCameraControl.h:1846 |
| cbException | MvCameraControl.h:1825 |
| chCurValue | CameraParams.h:1374 |
| chDeviceGUID | CameraParams.h:58 |
| chDeviceVersion | CameraParams.h:34 |
| chFamilyName | CameraParams.h:61 |
| chManufacturerName | CameraParams.h:32 |
| chModelName | CameraParams.h:33 |
| chSerialNumber | CameraParams.h:36 |
| chSymbolic | CameraParams.h:1330 |
| chUserDefinedName | CameraParams.h:37 |
| chVendorName | CameraParams.h:59 |
| enGrabStrategy | MvCameraControl.h:845 |
| enSortMethod | MvCameraControl.h:395 |
| fExposureTime | CameraParams.h:457 |
| fGain | CameraParams.h:456 |
| fMax | CameraParams.h:1364 |
| fMin | CameraParams.h:1365 |
| fValue | MvCameraControl.h:1401 |
| handle | MvCameraControl.h:415 |
| int64_t | CameraParams.h:447 |
| nAccessMode | MvCameraControl.h:448 |
| nActionTime | CameraParams.h:1176 |
| nAlignment | MvCameraControl.h:879 |
| nAverageBrightness | CameraParams.h:458 |
| nBayerCvtQuality | MvCameraControl.h:2841 |
| nBlockIdHigh | CameraParams.h:1099 |
| nCurValue | CameraParams.h:1301 |
| nCycleCount | CameraParams.h:453 |
| nCycleOffset | CameraParams.h:454 |
| nDevTimeStampHigh | CameraParams.h:444 |
| nDevTimeStampLow | CameraParams.h:445 |
| nDeviceNum | CameraParams.h:213 |
| nErrorFrameCount | CameraParams.h:578 |
| nExtendHeight | CameraParams.h:487 |
| nExtendWidth | CameraParams.h:486 |
| nFrameCounter | CameraParams.h:465 |
| nFrameNum | CameraParams.h:443 |
| nHostTimeStamp | CameraParams.h:447 |
| nInc | CameraParams.h:1342 |
| nLastFrameFlag | CameraParams.h:511 |
| nLostPacket | CameraParams.h:477 |
| nMax | CameraParams.h:1340 |
| nMaxLength | CameraParams.h:1376 |
| nMin | CameraParams.h:1341 |
| nMsec | MvCameraControl.h:713 |
| nMsgType | CameraParams.h:1519 |
| nNum | MvCameraControl.h:818 |
| nReceivedFrameCount | CameraParams.h:577 |
| nRes | CameraParams.h:523 |
| nReserved | CameraParams.h:68 |
| nSecondCount | CameraParams.h:452 |
| nSupportValue | CameraParams.h:1303 |
| nSupportedNum | CameraParams.h:1302 |
| nSwitchoverKey | MvCameraControl.h:505 |
| nTLayerType | CameraParams.h:181 |
| nTimestampHigh | CameraParams.h:1102 |
| nTimestampLow | CameraParams.h:1103 |
| nTriggerIndex | CameraParams.h:466 |
| nValue | CameraParams.h:1329 |
| pBufAddr | CameraParams.h:520 |
| pDeviceInfo | CameraParams.h:214 |
| pEventData | CameraParams.h:1105 |
| pEventInfo | MvCameraControl.h:155 |
| pInterfaceID | MvCameraControl.h:1166 |
| pUser | CameraParams.h:504 |
| pbValue | MvCameraControl.h:1420 |
| pstCvtParam | MvCameraControl.h:2824 |
| pstDevInfo | MvCameraControl.h:448 |
| pstDevList | MvCameraControl.h:307 |
| pstEnumEntry | MvCameraControl.h:1344 |
| pstEnumValue | MvCameraControl.h:1285 |
| pstFloatValue | MvCameraControl.h:1382 |
| pstFrame | MvCameraControl.h:142 |
| pstIntValue | MvCameraControl.h:1247 |
| pstStringValue | MvCameraControl.h:1458 |
| stUsb3VInfo | CameraParams.h:194 |
| strEventName | MvCameraControl.h:1869 |
| strKey | MvCameraControl.h:1247 |
| strManufacturerName | MvCameraControl.h:347 |
| strValue | MvCameraControl.h:1363 |
| uint64_t | CameraParams.h:343 |

</details>

---

## 附录：写代码用的精确定义

摘录方式：用脚本（scratchpad 中的 `tools/extract.py`）从 `/opt/MVS/include` 中原样截取以下内容：

- 函数的声明行；
- 紧邻其上的 Doxygen 注释中，中文段的 `@brief` 和每一条 `@param`；
- `typedef struct/enum` 从起始行到 `}名字;` 的整块文本（含原注释）；
- `#define` 和枚举值所在的整行。

唯一的加工是把 `@param` 说明中连续的空格压缩成一个，以及把 `|` 替换成全角“／”以免打乱表格（实际没有遇到）。头文件注释中常见的 `\~chinese … \~english …` 双语格式也原样保留。代码块中的行同样经过上文“名称核对”脚本的逐行比对，行尾的 ✓ 是核对结果，不属于头文件原文。

### A. 函数原型汇总

#### A1. 初始化

##### MV_CC_Initialize

位置：`MvCameraControl.h`:224。@brief：初始化SDK

```c
MV_CAMCTRL_API int __stdcall MV_CC_Initialize();  // ✓
```

无参数。

##### MV_CC_Finalize

位置：`MvCameraControl.h`:237。@brief：反初始化SDK，释放资源

```c
MV_CAMCTRL_API int __stdcall MV_CC_Finalize();  // ✓
```

无参数。

##### MV_CC_GetSDKVersion

位置：`MvCameraControl.h`:261。@brief：获取SDK版本号

```c
MV_CAMCTRL_API unsigned int __stdcall MV_CC_GetSDKVersion();  // ✓
```

无参数。

#### A2. 枚举与打开

**按 ID 打开的接口**：头文件里**没有**按序列号、User ID 或设备 ID 打开**相机**的函数（第 8c 项）。名字里带 “ByID” 的只有下面的 `MV_CC_CreateInterfaceByID`✓，它是给**采集卡**用的（@brief 为“通过采集卡ID创建采集卡句柄”），不适用于 USB3 相机。其余 `…ByGenTL` 接口是通过 GenTL 枚举和创建句柄的，也不是按 ID 打开。

##### MV_CC_EnumDevices

位置：`MvCameraControl.h`:307。@brief：枚举设备

```c
MV_CAMCTRL_API int __stdcall MV_CC_EnumDevices(IN unsigned int nTLayerType, IN OUT MV_CC_DEVICE_INFO_LIST* pstDevList);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `nTLayerType`✓ | [IN] | 枚举传输层, 参数定义参见CameraParams.h定义 |
| `pstDevList`✓ | [IN][OUT] | 设备列表 |

##### MV_CC_EnumDevicesEx

位置：`MvCameraControl.h`:347。@brief：根据厂商名字枚举设备

```c
MV_CAMCTRL_API int __stdcall MV_CC_EnumDevicesEx(IN unsigned int nTLayerType, IN OUT MV_CC_DEVICE_INFO_LIST* pstDevList, IN const char* strManufacturerName);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `nTLayerType`✓ | [IN] | 枚举传输层，参数定义参见CameraParams.h |
| `pstDevList`✓ | [IN][OUT] | 设备列表 |
| `strManufacturerName`✓ | [IN] | 厂商名字 |

##### MV_CC_EnumDevicesEx2

位置：`MvCameraControl.h`:395。@brief：枚举设备扩展（可指定排序方式枚举、根据厂商名字过滤）

```c
MV_CAMCTRL_API int __stdcall MV_CC_EnumDevicesEx2(IN unsigned int nTLayerType, IN OUT MV_CC_DEVICE_INFO_LIST* pstDevList, IN const char* strManufacturerName, IN MV_SORT_METHOD enSortMethod);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `nTLayerType`✓ | [IN] | 枚举传输层（区分每一种传输层类型，不耦合），参数定义参见CameraParams.h |
| `pstDevList`✓ | [IN][OUT] | 设备列表 |
| `strManufacturerName`✓ | [IN] | 厂商名字（可传NULL，即不过滤） |
| `enSortMethod`✓ | [IN] | 排序方式 |

##### MV_CC_IsDeviceAccessible

位置：`MvCameraControl.h`:448。@brief：设备是否可连接

```c
MV_CAMCTRL_API bool __stdcall MV_CC_IsDeviceAccessible(IN MV_CC_DEVICE_INFO* pstDevInfo, IN unsigned int nAccessMode);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `pstDevInfo`✓ | [IN] | 设备信息结构体 |
| `nAccessMode`✓ | [IN] | 访问权限，参数定义参见CameraParams.h定义 |

##### MV_CC_CreateHandle

位置：`MvCameraControl.h`:467。@brief：创建设备句柄

```c
MV_CAMCTRL_API int __stdcall MV_CC_CreateHandle(IN OUT void ** handle, IN const MV_CC_DEVICE_INFO* pstDevInfo);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN][OUT] | 设备句柄 |
| `pstDevInfo`✓ | [IN] | 设备信息结构体 |

##### MV_CC_OpenDevice

位置：`MvCameraControl.h`:505。@brief：打开设备

```c
#ifndef __cplusplus  // ✓
MV_CAMCTRL_API int __stdcall MV_CC_OpenDevice(IN void* handle, IN unsigned int nAccessMode, IN unsigned short nSwitchoverKey);  // ✓
#else  // ✓
MV_CAMCTRL_API int __stdcall MV_CC_OpenDevice(IN void* handle, IN unsigned int nAccessMode = MV_ACCESS_Exclusive, IN unsigned short nSwitchoverKey = 0);  // ✓
#endif  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `nAccessMode`✓ | [IN] | 访问权限, 参数定义参见CameraParams.h定义 |
| `nSwitchoverKey`✓ | [IN] | 切换访问权限时的密钥 （仅对 GigE Vision 类型的设备有效） |

##### MV_CC_CreateInterfaceByID

位置：`MvCameraControl.h`:1166。@brief：通过采集卡ID创建采集卡句柄

```c
MV_CAMCTRL_API int __stdcall MV_CC_CreateInterfaceByID(IN OUT void ** handle, IN const char* pInterfaceID);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN][OUT] | 采集卡句柄 |
| `pInterfaceID`✓ | [IN] | 采集卡ID |

#### A3. 参数读写

按类型分：Int 用 `MV_CC_GetIntValueEx`✓ / `MV_CC_SetIntValueEx`✓；Float 用 `MV_CC_GetFloatValue`✓ / `MV_CC_SetFloatValue`✓；Enum 用 `MV_CC_GetEnumValue`✓ / `MV_CC_GetEnumValueEx`✓ / `MV_CC_SetEnumValue`✓ / `MV_CC_SetEnumValueByString`✓（按字符串设置），以及 `MV_CC_GetEnumEntrySymbolic`✓（数值转符号）；Bool 用 `MV_CC_GetBoolValue`✓ / `MV_CC_SetBoolValue`✓；String 用 `MV_CC_GetStringValue`✓ / `MV_CC_SetStringValue`✓；Command 只有 `MV_CC_SetCommandValue`✓。

##### MV_CC_GetIntValueEx

位置：`MvCameraControl.h`:1247。@brief：获取Integer属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_GetIntValueEx(IN void* handle,IN const char* strKey,IN OUT MVCC_INTVALUE_EX *pstIntValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值，如获取宽度信息则为"Width" |
| `pstIntValue`✓ | [IN][OUT] | 返回给调用者有关设备属性结构体指针 |

##### MV_CC_SetIntValueEx

位置：`MvCameraControl.h`:1266。@brief：设置Integer型属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_SetIntValueEx(IN void* handle,IN const char* strKey,IN int64_t nValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值，如获取宽度信息则为"Width" |
| `nValue`✓ | [IN] | 想要设置的设备的属性值 |

##### MV_CC_GetFloatValue

位置：`MvCameraControl.h`:1382。@brief：获取Float属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_GetFloatValue(IN void* handle,IN const char* strKey,IN OUT MVCC_FLOATVALUE *pstFloatValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值 |
| `pstFloatValue`✓ | [IN][OUT] | 返回给调用者有关设备属性结构体指针 |

##### MV_CC_SetFloatValue

位置：`MvCameraControl.h`:1401。@brief：设置Float型属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_SetFloatValue(IN void* handle,IN const char* strKey,IN float fValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值 |
| `fValue`✓ | [IN] | 想要设置的设备的属性值 |

##### MV_CC_GetEnumValue

位置：`MvCameraControl.h`:1285。@brief：获取Enum属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_GetEnumValue(IN void* handle,IN const char* strKey,IN OUT MVCC_ENUMVALUE *pstEnumValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值，如获取像素格式信息则为"PixelFormat" |
| `pstEnumValue`✓ | [IN][OUT] | 返回给调用者有关设备属性结构体指针 |

##### MV_CC_GetEnumValueEx

位置：`MvCameraControl.h`:1306。@brief：获取Enum属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_GetEnumValueEx(IN void* handle, IN const char* strKey, IN OUT MVCC_ENUMVALUE_EX *pstEnumValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值，如获取像素格式信息则为"PixelFormat" |
| `pstEnumValue`✓ | [IN][OUT] | 返回给调用者有关设备属性结构体指针 |

##### MV_CC_SetEnumValue

位置：`MvCameraControl.h`:1325。@brief：设置Enum型属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_SetEnumValue(IN void* handle,IN const char* strKey,IN unsigned int nValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值，如获取像素格式信息则为"PixelFormat" |
| `nValue`✓ | [IN] | 想要设置的设备的属性值 |

##### MV_CC_SetEnumValueByString

位置：`MvCameraControl.h`:1363。@brief：设置Enum型属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_SetEnumValueByString(IN void* handle,IN const char* strKey,IN const char* strValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值，如获取像素格式信息则为"PixelFormat" |
| `strValue`✓ | [IN] | 想要设置的设备的属性字符串 |

##### MV_CC_GetEnumEntrySymbolic

位置：`MvCameraControl.h`:1344。@brief：获取Enum型节点指定值的符号

```c
MV_CAMCTRL_API int __stdcall MV_CC_GetEnumEntrySymbolic(IN void* handle,IN const char* strKey,IN OUT MVCC_ENUMENTRY* pstEnumEntry);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值，如获取像素格式信息则为"PixelFormat" |
| `pstEnumEntry`✓ | [IN][OUT] | 想要获取的设备的属性符号 |

##### MV_CC_GetBoolValue

位置：`MvCameraControl.h`:1420。@brief：获取Boolean属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_GetBoolValue(IN void* handle,IN const char* strKey,IN OUT bool *pbValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值 |
| `pbValue`✓ | [IN][OUT] | 返回给调用者有关设备属性值 |

##### MV_CC_SetBoolValue

位置：`MvCameraControl.h`:1439。@brief：设置Boolean型属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_SetBoolValue(IN void* handle,IN const char* strKey,IN bool bValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值 |
| `bValue`✓ | [IN] | 想要设置的设备的属性值 |

##### MV_CC_GetStringValue

位置：`MvCameraControl.h`:1458。@brief：获取String属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_GetStringValue(IN void* handle,IN const char* strKey,IN OUT MVCC_STRINGVALUE *pstStringValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值 |
| `pstStringValue`✓ | [IN][OUT] | 返回给调用者有关设备属性结构体指针 |

##### MV_CC_SetStringValue

位置：`MvCameraControl.h`:1477。@brief：设置String型属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_SetStringValue(IN void* handle,IN const char* strKey,IN const char* strValue);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值 |
| `strValue`✓ | [IN] | 想要设置的设备的属性值 |

##### MV_CC_SetCommandValue

位置：`MvCameraControl.h`:1494。@brief：设置Command型属性值

```c
MV_CAMCTRL_API int __stdcall MV_CC_SetCommandValue(IN void* handle,IN const char* strKey);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄/采集卡句柄 |
| `strKey`✓ | [IN] | 属性键值 |

#### A4. 取流与取图（含像素格式转换）

##### MV_CC_SetImageNodeNum

位置：`MvCameraControl.h`:818。@brief：设置SDK内部图像缓存节点个数，大于等于1，在抓图前调用

```c
MV_CAMCTRL_API int __stdcall MV_CC_SetImageNodeNum(IN void* handle, IN unsigned int nNum);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `nNum`✓ | [IN] | 缓存节点个数 |

##### MV_CC_SetGrabStrategy

位置：`MvCameraControl.h`:845。@brief：设置取流策略

```c
MV_CAMCTRL_API int __stdcall MV_CC_SetGrabStrategy(IN void* handle, IN MV_GRAB_STRATEGY enGrabStrategy);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `enGrabStrategy`✓ | [IN] | 策略枚举值 |

##### MV_CC_StartGrabbing

位置：`MvCameraControl.h`:672。@brief：开始取流

```c
MV_CAMCTRL_API int __stdcall MV_CC_StartGrabbing(IN void* handle);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |

##### MV_CC_GetImageBuffer

位置：`MvCameraControl.h`:713。@brief：获取一帧图片（与 MV_CC_Display() 不能同时使用）

```c
MV_CAMCTRL_API int __stdcall MV_CC_GetImageBuffer(IN void* handle, IN OUT MV_FRAME_OUT* pstFrame, IN unsigned int nMsec);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `pstFrame`✓ | [IN][OUT] | 图像数据和图像信息 |
| `nMsec`✓ | [IN] | 等待超时时间，输入INFINITE时表示无限等待，直到收到一帧数据或者停止取流 |

##### MV_CC_FreeImageBuffer

位置：`MvCameraControl.h`:732。@brief：释放图像缓存（此接口用于释放不再使用的图像缓存，与 MV_CC_GetImageBuffer() 配套使用）

```c
MV_CAMCTRL_API int __stdcall MV_CC_FreeImageBuffer(IN void* handle, IN MV_FRAME_OUT* pstFrame);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `pstFrame`✓ | [IN] | 图像数据和图像数据 |

##### MV_CC_StopGrabbing

位置：`MvCameraControl.h`:687。@brief：停止取流

```c
MV_CAMCTRL_API int __stdcall MV_CC_StopGrabbing(IN void* handle);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |

##### MV_CC_ConvertPixelTypeEx

位置：`MvCameraControl.h`:2824。@brief：像素格式转换

```c
MV_CAMCTRL_API int __stdcall MV_CC_ConvertPixelTypeEx(IN void* handle, IN OUT MV_CC_PIXEL_CONVERT_PARAM_EX* pstCvtParam);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `pstCvtParam`✓ | [IN][OUT] | 像素格式转换参数结构体 |

##### MV_CC_SetBayerCvtQuality

位置：`MvCameraControl.h`:2841。@brief：设置插值算法类型

```c
MV_CAMCTRL_API int __stdcall MV_CC_SetBayerCvtQuality(IN void* handle, IN unsigned int nBayerCvtQuality);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `nBayerCvtQuality`✓ | [IN] | Bayer的插值方法 0-快速 1-均衡（默认为均衡） 2-最优 3-最优+ |

#### A5. 异常与事件

##### MV_CC_RegisterExceptionCallBack

位置：`MvCameraControl.h`:1825。@brief：注册异常消息回调，在打开设备之后调用

```c
MV_CAMCTRL_API int __stdcall MV_CC_RegisterExceptionCallBack(IN void* handle, IN MvExceptionCallback cbException, IN void* pUser);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `cbException`✓ | [IN] | 异常回调函数指针 |
| `pUser`✓ | [IN] | 用户自定义变量 |

##### MV_CC_RegisterEventCallBackEx

位置：`MvCameraControl.h`:1869。@brief：注册单个事件回调，在打开设备之后调用

```c
MV_CAMCTRL_API int __stdcall MV_CC_RegisterEventCallBackEx(IN void* handle, IN const char* strEventName, IN MvEventCallback cbEvent, IN void* pUser);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `strEventName`✓ | [IN] | 事件名称 |
| `cbEvent`✓ | [IN] | 事件回调函数指针 |
| `pUser`✓ | [IN] | 用户自定义变量 |

##### MV_CC_RegisterAllEventCallBack

位置：`MvCameraControl.h`:1846。@brief：注册全部事件回调，在打开设备之后调用

```c
MV_CAMCTRL_API int __stdcall MV_CC_RegisterAllEventCallBack(IN void* handle, IN MvEventCallback cbEvent, IN void* pUser);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `cbEvent`✓ | [IN] | 事件回调函数指针 |
| `pUser`✓ | [IN] | 用户自定义变量 |

##### MV_CC_EventNotificationOn

位置：`MvCameraControl.h`:1905。@brief：开启设备指定事件

```c
MV_CAMCTRL_API int __stdcall MV_CC_EventNotificationOn(IN void* handle, IN const char* strEventName);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `strEventName`✓ | [IN] | 事件名称 |

##### MV_CC_EventNotificationOff

位置：`MvCameraControl.h`:1920。@brief：关闭设备指定事件

```c
MV_CAMCTRL_API int __stdcall MV_CC_EventNotificationOff(IN void* handle, IN const char* strEventName);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |
| `strEventName`✓ | [IN] | 事件名称 |

#### A6. 关闭与释放

反初始化 `MV_CC_Finalize`✓ 见 A1，释放图像缓存 `MV_CC_FreeImageBuffer`✓ 见 A4。

##### MV_CC_CloseDevice

位置：`MvCameraControl.h`:580。@brief：关闭设备

```c
MV_CAMCTRL_API int __stdcall MV_CC_CloseDevice(IN void* handle);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |

##### MV_CC_DestroyHandle

位置：`MvCameraControl.h`:595。@brief：销毁设备句柄

```c
MV_CAMCTRL_API int __stdcall MV_CC_DestroyHandle(IN void * handle);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `handle`✓ | [IN] | 设备句柄 |

### B. 结构体完整定义

`MV_CC_DEVICE_INFO`✓ 的联合体中引用的其他设备信息结构体（GigE、CameraLink 等），以及 `MV_FRAME_OUT_INFO_EX`✓ 中引用的 `MV_CHUNK_DATA_CONTENT`✓、`MV_CC_IMAGE`✓、`MV_GIGE_MULTI_PART_INFO`✓，都不在本次范围内，没有展开。

##### MV_CC_DEVICE_INFO_LIST

位置：`CameraParams.h`:211–216

```c
typedef struct _MV_CC_DEVICE_INFO_LIST_  // ✓
{
    unsigned int        nDeviceNum;                                 ///< [OUT] \~chinese 在线设备数量           \~english Online Device Number ✓
    MV_CC_DEVICE_INFO*  pDeviceInfo[MV_MAX_DEVICE_NUM];             ///< [OUT] \~chinese 支持最多256个设备      \~english Support up to 256 devices ✓

}MV_CC_DEVICE_INFO_LIST;  // ✓
```

##### MV_CC_DEVICE_INFO

位置：`CameraParams.h`:175–203

```c
typedef struct _MV_CC_DEVICE_INFO_  // ✓
{
    unsigned short          nMajorVer;                              ///< [OUT] \~chinese 主要版本               \~english Major Version ✓
    unsigned short          nMinorVer;                              ///< [OUT] \~chinese 次要版本               \~english Minor Version ✓
    unsigned int            nMacAddrHigh;                           ///< [OUT] \~chinese 高MAC地址              \~english High MAC Address ✓
    unsigned int            nMacAddrLow;                            ///< [OUT] \~chinese 低MAC地址              \~english Low MAC Address ✓
    unsigned int            nTLayerType;                            ///< [OUT] \~chinese 设备传输层协议类型     \~english Device Transport Layer Protocol Type ✓

    unsigned int            nDevTypeInfo;                           ///< [OUT] \~chinese 设备类型信息         \~english Device Type Info ✓
                                                                    ///<  \~chinese 设备类型规则         \~english Device Type Rules
                                                                    ///< 7 - 0 bit:      \~chinese 预留           \~english  Reserved
                                                                    ///< 15 - 8 bit：    \~chinese 产品子类别     \~english  Product subtype
                                                                    ///< 23 - 16 bit：   \~chinese 产品类型       \~english  product type
                                                                    ///< 31 - 24bit：    \~chinese 产品线         \~english  Product Line  产品线   //eg: 0x01 标准产品/2D Produces;  0x02 3D产品/3D Produces ; 0x03 智能ID产品/Intelligent ID products
    unsigned int            nReserved[3];                           ///<       \~chinese 预留                   \~english Reserved ✓

    union
    {
        MV_GIGE_DEVICE_INFO stGigEInfo;                             ///< [OUT] \~chinese GigE Vision设备信息              \~english GigE Device Info ✓
        MV_USB3_DEVICE_INFO stUsb3VInfo;                            ///< [OUT] \~chinese USB3 Vision设备信息               \~english USB Device Info ✓
        MV_CamL_DEV_INFO    stCamLInfo;                             ///< [OUT] \~chinese CameraLink设备信息        \~english CameraLink Device Info ✓
        MV_CML_DEVICE_INFO  stCMLInfo;                              ///< [OUT] \~chinese 采集卡CameraLink设备信息   \~english CameraLink Device Info On Frame Grabber ✓
        MV_CXP_DEVICE_INFO  stCXPInfo;                              ///< [OUT] \~chinese 采集卡CoaXPress设备信息    \~english CoaXPress Device Info On Frame Grabber ✓
        MV_XOF_DEVICE_INFO  stXoFInfo;                              ///< [OUT] \~chinese 采集卡XoF设备信息          \~english XoF Device Info On Frame Grabber ✓
        MV_XOC_DEVICE_INFO  stXoCInfo;                              ///< [OUT] \~chinese 采集卡XoC设备信息          \~english XoC Device Info On Frame Grabber ✓
        MV_GENTL_VIR_DEVICE_INFO stVirInfo;                         ///< [OUT] \~chinese 采集卡虚拟设备信息, 仅支持协议MV_GENTL_VIR_DEVICE   \~english Virtual Device Info On Frame Grabber,device transport layer protocol type is MV_GENTL_VIR_DEVICE ✓
    }SpecialInfo;  // ✓

}MV_CC_DEVICE_INFO;  // ✓
```

##### MV_USB3_DEVICE_INFO

位置：`CameraParams.h`:49–70

```c
typedef struct _MV_USB3_DEVICE_INFO_  // ✓
{
    unsigned char       CrtlInEndPoint;                             ///< [OUT] \~chinese 控制输入端点           \~english Control input endpoint ✓
    unsigned char       CrtlOutEndPoint;                            ///< [OUT] \~chinese 控制输出端点           \~english Control output endpoint ✓
    unsigned char       StreamEndPoint;                             ///< [OUT] \~chinese 流端点                 \~english Flow endpoint ✓
    unsigned char       EventEndPoint;                              ///< [OUT] \~chinese 事件端点               \~english Event endpoint ✓
    unsigned short      idVendor;                                   ///< [OUT] \~chinese 供应商ID号             \~english Vendor ID Number ✓
    unsigned short      idProduct;                                  ///< [OUT] \~chinese 产品ID号               \~english Device ID Number ✓
    unsigned int        nDeviceNumber;                              ///< [OUT] \~chinese 设备索引号             \~english Device Number ✓
    unsigned char       chDeviceGUID[INFO_MAX_BUFFER_SIZE];         ///< [OUT] \~chinese 设备GUID号             \~english Device GUID Number ✓
    unsigned char       chVendorName[INFO_MAX_BUFFER_SIZE];         ///< [OUT] \~chinese 供应商名字             \~english Vendor Name ✓
    unsigned char       chModelName[INFO_MAX_BUFFER_SIZE];          ///< [OUT] \~chinese 型号名字               \~english Model Name ✓
    unsigned char       chFamilyName[INFO_MAX_BUFFER_SIZE];         ///< [OUT] \~chinese 家族名字               \~english Family Name ✓
    unsigned char       chDeviceVersion[INFO_MAX_BUFFER_SIZE];      ///< [OUT] \~chinese 设备版本               \~english Device Version ✓
    unsigned char       chManufacturerName[INFO_MAX_BUFFER_SIZE];   ///< [OUT] \~chinese 制造商名字             \~english Manufacturer Name ✓
    unsigned char       chSerialNumber[INFO_MAX_BUFFER_SIZE];       ///< [OUT] \~chinese 序列号                 \~english Serial Number ✓
    unsigned char       chUserDefinedName[INFO_MAX_BUFFER_SIZE];    ///< [OUT] \~chinese 用户自定义名字         \~english User Defined Name ✓
    unsigned int        nbcdUSB;                                    ///< [OUT] \~chinese 支持的USB协议          \~english Support USB Protocol ✓
    unsigned int        nDeviceAddress;                             ///< [OUT] \~chinese 设备地址               \~english Device Address ✓
	unsigned int        nReserved[2];                               ///<       \~chinese 预留                   \~english Reserved ✓

}MV_USB3_DEVICE_INFO;  // ✓
```

##### MV_FRAME_OUT

位置：`CameraParams.h`:518–525

```c
typedef struct _MV_FRAME_OUT_  // ✓
{
    unsigned char*          pBufAddr;                               ///< [OUT] \~chinese 图像指针地址           \~english  pointer of image ✓
    MV_FRAME_OUT_INFO_EX    stFrameInfo;                            ///< [OUT] \~chinese 图像信息               \~english information of the specific image ✓

    unsigned int            nRes[16];                               ///<       \~chinese 预留                   \~english Reserved ✓

}MV_FRAME_OUT;  // ✓
```

##### MV_FRAME_OUT_INFO_EX

位置：`CameraParams.h`:437–515

```c
typedef struct _MV_FRAME_OUT_INFO_EX_  // ✓
{
    unsigned short          nWidth;                                 ///< [OUT] \~chinese 图像宽(最大65535，超出请用nExtendWidth)    \~english Image Width (over 65535, use nExtendWidth) ✓
    unsigned short          nHeight;                                ///< [OUT] \~chinese 图像高(最大65535，超出请用nExtendHeight)   \~english Image Height(over 65535, use nExtendHeight) ✓
    enum MvGvspPixelType    enPixelType;                            ///< [OUT] \~chinese 像素格式               \~english Pixel Type ✓

    unsigned int            nFrameNum;                              ///< [OUT] \~chinese 帧号                   \~english Frame Number ✓
    unsigned int            nDevTimeStampHigh;                      ///< [OUT] \~chinese 时间戳高32位           \~english Timestamp high 32 bits ✓
    unsigned int            nDevTimeStampLow;                       ///< [OUT] \~chinese 时间戳低32位           \~english Timestamp low 32 bits ✓
    unsigned int            nReserved0;                             ///< [OUT] \~chinese 保留，8字节对齐        \~english Reserved, 8-byte aligned ✓
    int64_t                 nHostTimeStamp;                         ///< [OUT] \~chinese 主机生成的时间戳       \~english Host-generated timestamp ✓

    unsigned int            nFrameLen;                              ///< [OUT] \~chinese 帧的长度(4GB以上图像使用nFrameLenEx替代)               \~english The Length of Frame ✓

    /// \~chinese 设备水印时标      \~english Device frame-specific time scale
    unsigned int            nSecondCount;                           ///< [OUT] \~chinese 秒数                   \~english The Seconds ✓
    unsigned int            nCycleCount;                            ///< [OUT] \~chinese 周期数                 \~english The Count of Cycle ✓
    unsigned int            nCycleOffset;                           ///< [OUT] \~chinese 周期偏移量             \~english The Offset of Cycle ✓

    float                   fGain;                                  ///< [OUT] \~chinese 增益                   \~english Gain ✓
    float                   fExposureTime;                          ///< [OUT] \~chinese 曝光时间               \~english Exposure Time ✓
    unsigned int            nAverageBrightness;                     ///< [OUT] \~chinese 平均亮度               \~english Average brightness ✓

    /// \~chinese 白平衡相关        \~english White balance
    unsigned int            nRed;                                   ///< [OUT] \~chinese 红色                   \~english Red ✓
    unsigned int            nGreen;                                 ///< [OUT] \~chinese 绿色                   \~english Green ✓
    unsigned int            nBlue;                                  ///< [OUT] \~chinese 蓝色                   \~english Blue ✓

    unsigned int            nFrameCounter;                          ///< [OUT] \~chinese 总帧数                 \~english Frame Counter ✓
    unsigned int            nTriggerIndex;                          ///< [OUT] \~chinese 触发计数               \~english Trigger Counting ✓

    unsigned int            nInput;                                 ///< [OUT] \~chinese 输入                   \~english Input ✓
    unsigned int            nOutput;                                ///< [OUT] \~chinese 输出                   \~english Output ✓

    /// \~chinese ROI区域           \~english ROI Region
    unsigned short          nOffsetX;                               ///< [OUT] \~chinese 水平偏移量             \~english OffsetX ✓
    unsigned short          nOffsetY;                               ///< [OUT] \~chinese 垂直偏移量             \~english OffsetY ✓
    unsigned short          nChunkWidth;                            ///< [OUT] \~chinese Chunk宽                \~english The Width of Chunk ✓
    unsigned short          nChunkHeight;                           ///< [OUT] \~chinese Chunk高                \~english The Height of Chunk ✓

    unsigned int            nLostPacket;                            ///< [OUT] \~chinese 本帧丢包数             \~english Lost Packet Number In This Frame ✓

    unsigned int            nUnparsedChunkNum;                      ///< [OUT] \~chinese 未解析的Chunkdata个数  \~english Unparsed Chunk Number ✓
    union
    {
        MV_CHUNK_DATA_CONTENT*  pUnparsedChunkContent;              ///< [OUT] \~chinese 未解析的Chunk          \~english Unparsed Chunk Content ✓
        int64_t                 nAligning;                          ///< [OUT] \~chinese 校准                   \~english Aligning ✓
    }UnparsedChunkList;  // ✓

    unsigned int            nExtendWidth;                           ///< [OUT] \~chinese 图像宽(扩展变量)       \~english Image Width ✓
    unsigned int            nExtendHeight;                          ///< [OUT] \~chinese 图像高(扩展变量)       \~english Image Height ✓

    uint64_t                nFrameLenEx;                            ///< [OUT] \~chinese 帧的长度               \~english The Length of Frame ✓

    unsigned int            nExtraType;                             ///< [OUT] \~chinese 判断携带的额外信息的类型：子图(SubImageList)还是多图(MultiPartArray) MV_FRAME_EXTRA_INFO_TYPE类型 ✓

    unsigned int            nSubImageNum;                           ///< [OUT] \~chinese 图像缓存中的子图(多图)个数  \~english Sub Image（MulitiPart） Number ✓

    union
    {
        MV_CC_IMAGE* pstSubImage;                                   ///< [OUT] \~chinese 子图信息 \~english Sub image info ✓
        MV_GIGE_MULTI_PART_INFO* pstPartInfo;                       ///< [OUT] \~chinese 图像部分信息 \~english Image Parts Information ✓
        int64_t      nAligning;                                     ///< [OUT] \~chinese 校准 \~english Aligning ✓
    } SubImageList;  // ✓

    union
    {
        void*               pUser;                                  ///< [OUT] \~chinese 自定义指针(外部注册缓存时，内存地址对应的用户自定义指针)          \~english Custom pointer (user-defined pointer corresponding to memory address when registering external cache) ✓
        int64_t             nAligning;                              ///< [OUT] \~chinese 校准                   \~english Aligning ✓
    }UserPtr;  // ✓

    unsigned int            nFirstLineEncoderCount;                 ///< [OUT] \~chinese 首行编码器计数        \~english First line encoder count ✓
    unsigned int            nLastLineEncoderCount;                  ///< [OUT] \~chinese 尾行编码器计数        \~english Last line encoder count ✓

    unsigned int            nLastFrameFlag;                         ///< [OUT] \~chinese 电平结束时的最后一帧  \~english last level frame flag ✓

    unsigned int            nReserved[23];                          ///<       \~chinese 预留                   \~english Reserved ✓

}MV_FRAME_OUT_INFO_EX;  // ✓
```

##### MVCC_INTVALUE_EX

位置：`CameraParams.h`:1349–1358

```c
typedef struct _MVCC_INTVALUE_EX_T  // ✓
{
    int64_t             nCurValue;                                  ///< [OUT] \~chinese 当前值                 \~english Current Value ✓
    int64_t             nMax;                                       ///< [OUT] \~chinese 最大值                 \~english Max ✓
    int64_t             nMin;                                       ///< [OUT] \~chinese 最小值                 \~english Min ✓
    int64_t             nInc;                                       ///< [OUT] \~chinese Inc                    \~english Inc ✓

    unsigned int        nReserved[16];                              ///<       \~chinese 预留                   \~english Reserved ✓

}MVCC_INTVALUE_EX;  // ✓
```

##### MVCC_FLOATVALUE

位置：`CameraParams.h`:1361–1369

```c
typedef struct _MVCC_FLOATVALUE_T  // ✓
{
    float               fCurValue;                                  ///< [OUT] \~chinese 当前值                 \~english Current Value ✓
    float               fMax;                                       ///< [OUT] \~chinese 最大值                 \~english Max ✓
    float               fMin;                                       ///< [OUT] \~chinese 最小值                 \~english Min ✓

    unsigned int        nReserved[4];                               ///<       \~chinese 预留                   \~english Reserved ✓

}MVCC_FLOATVALUE;  // ✓
```

##### MVCC_ENUMVALUE

位置：`CameraParams.h`:1299–1307

```c
typedef struct _MVCC_ENUMVALUE_T  // ✓
{
    unsigned int        nCurValue;                                  ///< [OUT] \~chinese 当前值                 \~english Current Value ✓
    unsigned int        nSupportedNum;                              ///< [OUT] \~chinese 数据的有效数据个数     \~english Number of valid data ✓
    unsigned int        nSupportValue[MV_MAX_XML_SYMBOLIC_NUM];     ///< [OUT] \~chinese 支持的枚举值           \~english Support Value ✓

    unsigned int        nReserved[4];                               ///<       \~chinese 预留                   \~english Reserved ✓

}MVCC_ENUMVALUE;  // ✓
```

##### MVCC_ENUMVALUE_EX

位置：`CameraParams.h`:1313–1321

```c
typedef struct _MVCC_ENUMVALUE_EX_T  // ✓
{
    unsigned int        nCurValue;                                  ///< [OUT] \~chinese 当前值                 \~english Current Value ✓
    unsigned int        nSupportedNum;                              ///< [OUT] \~chinese 数据的有效数据个数     \~english Number of valid data ✓
    unsigned int        nSupportValue[MV_MAX_ENUM_SYMBOLIC_NUM];   ///< [OUT] \~chinese 支持的枚举值           \~english Support Value ✓

    unsigned int        nReserved[4];                               ///<       \~chinese 预留                   \~english Reserved ✓

}MVCC_ENUMVALUE_EX;  // ✓
```

##### MVCC_ENUMENTRY

位置：`CameraParams.h`:1327–1334

```c
typedef struct _MVCC_ENUMENTRY_T  // ✓
{
    unsigned int        nValue;                                     ///< [IN]  \~chinese 指定值                 \~english Value ✓
    char                chSymbolic[MV_MAX_SYMBOLIC_LEN];            ///< [OUT] \~chinese 指定值对应的符号       \~english Symbolic ✓

    unsigned int        nReserved[4];                               ///< \~chinese 预留                         \~english Reserved ✓

}MVCC_ENUMENTRY;  // ✓
```

##### MVCC_STRINGVALUE

位置：`CameraParams.h`:1372–1379

```c
typedef struct _MVCC_STRINGVALUE_T  // ✓
{
    char                chCurValue[256];                            ///< [OUT] \~chinese 当前值                 \~english Current Value ✓

    int64_t             nMaxLength;                                 ///< [OUT] \~chinese 最大长度               \~english MaxLength ✓
    unsigned int        nReserved[2];                               ///<       \~chinese 预留                   \~english Reserved ✓

}MVCC_STRINGVALUE;  // ✓
```

##### MV_CC_PIXEL_CONVERT_PARAM_EX

位置：`CameraParams.h`:724–740

```c
typedef struct _MV_CC_PIXEL_CONVERT_PARAM_EX_  // ✓
{
    unsigned int            nWidth;                                 ///< [IN]  \~chinese 图像宽                 \~english Width ✓
    unsigned int            nHeight;                                ///< [IN]  \~chinese 图像高                 \~english Height ✓

    enum MvGvspPixelType    enSrcPixelType;                         ///< [IN]  \~chinese 源像素格式             \~english Source pixel format ✓
    unsigned char*          pSrcData;                               ///< [IN]  \~chinese 输入数据缓存           \~english Input data buffer ✓
    unsigned int            nSrcDataLen;                            ///< [IN]  \~chinese 输入数据长度           \~english Input data length ✓

    enum MvGvspPixelType    enDstPixelType;                         ///< [IN]  \~chinese 目标像素格式           \~english Destination pixel format ✓
    unsigned char*          pDstBuffer;                             ///< [OUT] \~chinese 输出数据缓存           \~english Output data buffer ✓
    unsigned int            nDstLen;                                ///< [OUT] \~chinese 输出数据长度           \~english Output data length ✓
    unsigned int            nDstBufferSize;                         ///< [IN]  \~chinese 提供的输出缓冲区大小   \~english Provided output buffer size ✓

    unsigned int            nRes[4];                                ///<       \~chinese 预留                   \~english Reserved ✓

}MV_CC_PIXEL_CONVERT_PARAM_EX;  // ✓
```

#### B附. 数组长度

下表由脚本从 B、C 两节摘录的结构体中解析数组字段，再用 `CameraParams.h` 中的宏展开得到长度。宏的定义见 D4。

| 结构体 | 字段 | 长度表达式 | 长度 |
|---|---|---|---|
| MV_CC_DEVICE_INFO_LIST | `pDeviceInfo`✓ | MV_MAX_DEVICE_NUM | 256 |
| MV_CC_DEVICE_INFO | `nReserved`✓ | 3 | 3 |
| MV_USB3_DEVICE_INFO | `chDeviceGUID`✓ | INFO_MAX_BUFFER_SIZE | 64 |
| MV_USB3_DEVICE_INFO | `chVendorName`✓ | INFO_MAX_BUFFER_SIZE | 64 |
| MV_USB3_DEVICE_INFO | `chModelName`✓ | INFO_MAX_BUFFER_SIZE | 64 |
| MV_USB3_DEVICE_INFO | `chFamilyName`✓ | INFO_MAX_BUFFER_SIZE | 64 |
| MV_USB3_DEVICE_INFO | `chDeviceVersion`✓ | INFO_MAX_BUFFER_SIZE | 64 |
| MV_USB3_DEVICE_INFO | `chManufacturerName`✓ | INFO_MAX_BUFFER_SIZE | 64 |
| MV_USB3_DEVICE_INFO | `chSerialNumber`✓ | INFO_MAX_BUFFER_SIZE | 64 |
| MV_USB3_DEVICE_INFO | `chUserDefinedName`✓ | INFO_MAX_BUFFER_SIZE | 64 |
| MV_USB3_DEVICE_INFO | `nReserved`✓ | 2 | 2 |
| MV_FRAME_OUT | `nRes`✓ | 16 | 16 |
| MV_FRAME_OUT_INFO_EX | `nReserved`✓ | 23 | 23 |
| MVCC_INTVALUE_EX | `nReserved`✓ | 16 | 16 |
| MVCC_FLOATVALUE | `nReserved`✓ | 4 | 4 |
| MVCC_ENUMVALUE | `nSupportValue`✓ | MV_MAX_XML_SYMBOLIC_NUM | 64 |
| MVCC_ENUMVALUE | `nReserved`✓ | 4 | 4 |
| MVCC_ENUMVALUE_EX | `nSupportValue`✓ | MV_MAX_ENUM_SYMBOLIC_NUM | 256 |
| MVCC_ENUMVALUE_EX | `nReserved`✓ | 4 | 4 |
| MVCC_ENUMENTRY | `chSymbolic`✓ | MV_MAX_SYMBOLIC_LEN | 64 |
| MVCC_ENUMENTRY | `nReserved`✓ | 4 | 4 |
| MVCC_STRINGVALUE | `chCurValue`✓ | 256 | 256 |
| MVCC_STRINGVALUE | `nReserved`✓ | 2 | 2 |
| MV_CC_PIXEL_CONVERT_PARAM_EX | `nRes`✓ | 4 | 4 |
| MV_EVENT_OUT_INFO | `EventName`✓ | MAX_EVENT_NAME_SIZE | 128 |
| MV_EVENT_OUT_INFO | `nReserved`✓ | 16 | 16 |

#### B附. 本机实测 sizeof（x86_64，g++ 11.4.0）

这些数值只用于在初始化或跨语言绑定时做自检，不是头文件内容。

| 类型 | sizeof（字节） |
|---|---|
| `MV_CC_DEVICE_INFO_LIST`✓ | 2056 |
| `MV_CC_DEVICE_INFO`✓ | 636 |
| `MV_USB3_DEVICE_INFO`✓ | 540 |
| `MV_FRAME_OUT`✓ | 336 |
| `MV_FRAME_OUT_INFO_EX`✓ | 264 |
| `MVCC_INTVALUE_EX`✓ | 96 |
| `MVCC_FLOATVALUE`✓ | 28 |
| `MVCC_ENUMVALUE`✓ | 280 |
| `MVCC_ENUMVALUE_EX`✓ | 1048 |
| `MVCC_ENUMENTRY`✓ | 84 |
| `MVCC_STRINGVALUE`✓ | 272 |
| `MV_CC_PIXEL_CONVERT_PARAM_EX`✓ | 72 |
| `MV_EVENT_OUT_INFO`✓ | 232 |

### C. 回调函数类型的定义

事件回调的参数结构体 `MV_EVENT_OUT_INFO`✓ 一并列出。

##### MvExceptionCallback

位置：`MvCameraControl.h`:181。@brief：异常消息回调

```c
typedef void(__stdcall *MvExceptionCallback)(unsigned int nMsgType, void *pUser);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `nMsgType`✓ | [OUT] | 异常类型 |
| `pUser`✓ | [OUT] | 用户自定义变量 |

##### MvEventCallback

位置：`MvCameraControl.h`:155。@brief：事件回调函数

```c
typedef void(__stdcall *MvEventCallback)(MV_EVENT_OUT_INFO * pEventInfo, void* pUser);  // ✓
```

| 参数 | 方向 | 头文件 @param 原文 |
|---|---|---|
| `pEventInfo`✓ | [OUT] | 事件信息 |
| `pUser`✓ | [OUT] | 用户自定义变量 |

##### MV_EVENT_OUT_INFO

位置：`CameraParams.h`:1092–1110

```c
typedef struct _MV_EVENT_OUT_INFO_  // ✓
{
    char                EventName[MAX_EVENT_NAME_SIZE];             ///< [OUT] \~chinese Event名称              \~english Event name ✓

    unsigned short      nEventID;                                   ///< [OUT] \~chinese Event号                \~english Event ID ✓
    unsigned short      nStreamChannel;                             ///< [OUT] \~chinese 流通道序号             \~english Circulation number ✓

    unsigned int        nBlockIdHigh;                               ///< [OUT] \~chinese 帧号高位   (暂无固件支持)           \~english BlockId high, not support ✓
    unsigned int        nBlockIdLow;                                ///< [OUT] \~chinese 帧号低位   (暂无固件支持)           \~english BlockId low, not support ✓

    unsigned int        nTimestampHigh;                             ///< [OUT] \~chinese 时间戳高位             \~english Timestramp high ✓
    unsigned int        nTimestampLow;                              ///< [OUT] \~chinese 时间戳低位             \~english Timestramp low ✓

    void*               pEventData;                                 ///< [OUT] \~chinese Event数据     (暂无固件支持)        \~english Event data, not support ✓
    unsigned int        nEventDataSize;                             ///< [OUT] \~chinese Event数据长度 (暂无固件支持)        \~english Event data len, not support ✓

    unsigned int        nReserved[16];                              ///<       \~chinese 预留                   \~english Reserved ✓

}MV_EVENT_OUT_INFO;  // ✓
```

### D. 常量

#### D1. MV_OK

位置：`MvErrorDefine.h`:14

```c
#define MV_OK                                       0x00000000  ///< \~chinese 成功，无错误             \~english Succeeded, no error ✓
```

#### D2. 设备类型宏（含虚拟设备 MV_VIR_GIGE_DEVICE、MV_VIR_USB_DEVICE、MV_GENTL_VIR_DEVICE）

位置：`CameraParams.h`:160–172

```c
#define MV_UNKNOW_DEVICE                0x00000000                  ///< \~chinese 未知设备类型，保留意义       \~english Unknown Device Type, Reserved ✓
#define MV_GIGE_DEVICE                  0x00000001                  ///< \~chinese GigE Vision设备              \~english GigE Version Device ✓
#define MV_1394_DEVICE                  0x00000002                  ///< \~chinese 1394-a/b 设备                \~english 1394-a/b Device ✓
#define MV_USB_DEVICE                   0x00000004                  ///< \~chinese USB3 Vision设备                    \~english USB3 Version Device ✓
#define MV_CAMERALINK_DEVICE            0x00000008                  ///< \~chinese 串口设备（包含Camera Link设备和串口光源控制器）          \~english CameraLink Device ✓
#define MV_VIR_GIGE_DEVICE              0x00000010                  ///< \~chinese 虚拟GigE Vision设备，包含虚拟GigE Vision采集卡下的设备                 \~english Virtual GigE Device, including GenTL virtual devices. ✓
#define MV_VIR_USB_DEVICE               0x00000020                  ///< \~chinese 虚拟USB3 Vision设备，不支持虚拟采集卡下的设备             \~english Virtual USB Device that does not support GenTL virtual devices. ✓
#define MV_GENTL_GIGE_DEVICE            0x00000040                  ///< \~chinese 自研网卡下GigE Vision设备，某些卡不支持此协议，如GE1104    \~english GenTL GigE Device ✓
#define MV_GENTL_CAMERALINK_DEVICE      0x00000080                  ///< \~chinese CameraLink相机设备          \~english GenTL CameraLink Camera Device ✓
#define MV_GENTL_CXP_DEVICE             0x00000100                  ///< \~chinese CoaXPress设备              \~english GenTL CoaXPress Device ✓
#define MV_GENTL_XOF_DEVICE             0x00000200                  ///< \~chinese XoF设备                    \~english GenTL XoF Device ✓
#define MV_GENTL_VIR_DEVICE             0x00000800                  ///< \~chinese 虚拟采集卡下的设备，不支持虚拟GigE Vision采集卡下的设备。        \~english GenTL Virtual Device that does not support GenTL virtual GigE devices. ✓
#define MV_GENTL_XOC_DEVICE             0x00001000                  ///< \~chinese XoC设备                    \~english GenTL XoC Device ✓
```

#### D3. 访问模式宏

位置：`CameraParams.h`:315–321

```c
#define MV_ACCESS_Exclusive                     1                   /// \~chinese 独占权限，其他APP只允许读CCP寄存器                    \~english Exclusive authority, other APP is only allowed to read the CCP register ✓
#define MV_ACCESS_ExclusiveWithSwitch           2                   /// \~chinese 可以从5模式下抢占权限，然后以独占权限打开             \~english You can seize the authority from the 5 mode, and then open with exclusive authority ✓
#define MV_ACCESS_Control                       3                   /// \~chinese 控制权限，其他APP允许读所有寄存器                     \~english Control authority, allows other APP reading all registers ✓
#define MV_ACCESS_ControlWithSwitch             4                   /// \~chinese 可以从5的模式下抢占权限，然后以控制权限打开           \~english You can seize the authority from the 5 mode, and then open with control authority ✓
#define MV_ACCESS_ControlSwitchEnable           5                   /// \~chinese 以可被抢占的控制权限打开                              \~english Open with seized control authority ✓
#define MV_ACCESS_ControlSwitchEnableWithKey    6                   /// \~chinese 可以从5的模式下抢占权限，然后以可被抢占的控制权限打开 \~english You can seize the authority from the 5 mode, and then open with seized control authority ✓
#define MV_ACCESS_Monitor                       7                   /// \~chinese 读模式打开设备，适用于控制权限下                      \~english Open with read mode and is available under control authority ✓
```

#### D3附. 异常类型宏

位置：`CameraParams.h`:1061, 1062

```c
#define MV_EXCEPTION_DEV_DISCONNECT     0x00008001                  ///< \~chinese 设备断开连接                 \~english The device is disconnected ✓
#define MV_EXCEPTION_VERSION_CHECK      0x00008002                  ///< \~chinese SDK与驱动版本不匹配          \~english SDK does not match the driver version ✓
```

#### D4. 数组长度相关的宏

位置：`CameraParams.h`:46–1325

```c
#define INFO_MAX_BUFFER_SIZE            64  // ✓
#define MV_MAX_DEVICE_NUM               256  // ✓
#define MAX_EVENT_NAME_SIZE             128  // ✓
#define MV_MAX_XML_SYMBOLIC_NUM         64  // ✓
#define MV_MAX_ENUM_SYMBOLIC_NUM                 256  // ✓
#define MV_MAX_SYMBOLIC_LEN         64  // ✓
```

#### D5. 像素格式常量（`enum MvGvspPixelType`，`PixelType.h`:31 起）

先列出组成这些常量的辅助宏，再列出各常量所在的行：

```c
#define MV_GVSP_PIX_MONO                                0x01000000  // ✓
#define MV_GVSP_PIX_COLOR                               0x02000000  // ✓
#define MV_PIXEL_BIT_COUNT(n)                           ((n) << 16)  // ✓

    PixelType_Gvsp_Mono8                    = (MV_GVSP_PIX_MONO | MV_PIXEL_BIT_COUNT(8) | 0x0001),                  ///< Mono8 ✓
    PixelType_Gvsp_BayerGR8                 = (MV_GVSP_PIX_MONO | MV_PIXEL_BIT_COUNT(8) | 0x0008),                  ///< BayerGR8 ✓
    PixelType_Gvsp_BayerRG8                 = (MV_GVSP_PIX_MONO | MV_PIXEL_BIT_COUNT(8) | 0x0009),                  ///< BayerRG8 ✓
    PixelType_Gvsp_BayerGB8                 = (MV_GVSP_PIX_MONO | MV_PIXEL_BIT_COUNT(8) | 0x000A),                  ///< BayerGB8 ✓
    PixelType_Gvsp_BayerBG8                 = (MV_GVSP_PIX_MONO | MV_PIXEL_BIT_COUNT(8) | 0x000B),                  ///< BayerBG8 ✓
    PixelType_Gvsp_RGB8_Packed              =   (MV_GVSP_PIX_COLOR | MV_PIXEL_BIT_COUNT(24) | 0x0014),                  ///< RGB8_Packed ✓
```

下表是本机编译后打印出的实际数值。与 [CN] 相机参数节点表中 `"PixelFormat"` 的取值一致（例如 BayerGB8 = 0x0108000A）。

| 常量 | 数值 |
|---|---|
| `PixelType_Gvsp_Mono8`✓ | 0x01080001 |
| `PixelType_Gvsp_BayerGR8`✓ | 0x01080008 |
| `PixelType_Gvsp_BayerRG8`✓ | 0x01080009 |
| `PixelType_Gvsp_BayerGB8`✓ | 0x0108000A |
| `PixelType_Gvsp_BayerBG8`✓ | 0x0108000B |
| `PixelType_Gvsp_RGB8_Packed`✓ | 0x02180014 |

#### D6. 相关枚举（`MV_CC_SetGrabStrategy`✓ 和 `MV_CC_EnumDevicesEx2`✓ 的参数类型）

##### MV_GRAB_STRATEGY

位置：`CameraParams.h`:528–535

```c
typedef enum _MV_GRAB_STRATEGY_  // ✓
{
    MV_GrabStrategy_OneByOne            = 0,                        ///< \~chinese 从旧到新一帧一帧的获取图像   \~english Grab One By One ✓
    MV_GrabStrategy_LatestImagesOnly    = 1,                        ///< \~chinese 获取列表中最新的一帧图像     \~english Grab The Latest Image ✓
    MV_GrabStrategy_LatestImages        = 2,                        ///< \~chinese 获取列表中最新的图像         \~english Grab The Latest Images ✓
    MV_GrabStrategy_UpcomingImage       = 3,                        ///< \~chinese 等待下一帧图像               \~english Grab The Upcoming Image ✓

}MV_GRAB_STRATEGY;  // ✓
```

##### MV_SORT_METHOD

位置：`CameraParams.h`:14–21

```c
typedef enum _MV_SORT_METHOD_  // ✓
{
    SortMethod_SerialNumber   = 0,                  ///< \~chinese 按序列号排序                     \~english Sorting by SerialNumber ✓
    SortMethod_UserID         = 1,                  ///< \~chinese 按用户自定义名字排序             \~english Sorting by UserID ✓
    SortMethod_CurrentIP_ASC  = 2,                  ///< \~chinese 按当前IP地址排序（升序） ，只对GigE Vision相机有效，其它类型相机按默认排序）         \~english Sorting by current IP（Ascending, Available for GEV cameras only. Other types of cameras are sorted by default） ✓
    SortMethod_CurrentIP_DESC = 3,                  ///< \~chinese 按当前IP地址排序（降序） ，只对GigE Vision相机有效，其它类型相机按默认排序）         \~english Sorting by current IP（Descending, Available for GEV cameras only. Other types of cameras are sorted by default） ✓

}MV_SORT_METHOD;  // ✓
```

### E. 示例程序 GrabImage_HighPerformance 的完整调用流程

来源：`/opt/MVS/Samples/64/C++/General/GrabImage_HighPerformance/GrabImage_HighPerformance.cpp`（共 281 行，已通读）。

下面按执行顺序列出它调用的每个 SDK 函数。“原文”是源文件中那一行的原样内容，行号为文件行号。`pthread_create` 等非 SDK 调用也列出来，只是为了说明线程关系。`PrintDeviceInfo`? 只读取 `MV_CC_DEVICE_INFO`✓ 的字段并打印，不调用任何 SDK 函数。

**主线程**

1. L129 `MV_CC_Initialize`✓：无参数。原文 `nRet = MV_CC_Initialize();`
2. L138–139 `MV_CC_EnumDevices`✓：调用前先 `memset(&stDeviceList, 0, sizeof(MV_CC_DEVICE_INFO_LIST));`，然后原文 `nRet = MV_CC_EnumDevices(MV_GIGE_DEVICE | MV_USB_DEVICE | MV_GENTL_CAMERALINK_DEVICE | MV_GENTL_CXP_DEVICE | MV_GENTL_XOF_DEVICE | MV_GENTL_XOC_DEVICE, &stDeviceList);`
   - 第一个参数是传输层类型掩码，共 6 个标志，其中**不含** `MV_VIR_USB_DEVICE`✓。按头文件的说明，`MV_USB_DEVICE`✓ 已包含虚拟 USB 相机。
   - 第二个参数是输出列表。如果 `MV_CC_DEVICE_INFO_LIST.nDeviceNum`✓ 为 0，程序直接退出。
3. L176 `MV_CC_CreateHandle`✓：原文 `nRet = MV_CC_CreateHandle(&handle, stDeviceList.pDeviceInfo[nIndex]);`。`handle`✓ 在 L124 初始化为 NULL；`nIndex`? 由 L167 的 `scanf` 读入，并在 L169 检查不越界。传入的是列表中的指针，没有做拷贝。
4. L184 `MV_CC_OpenDevice`✓：原文 `nRet = MV_CC_OpenDevice(handle);`。只传了一个参数；在 C++ 编译下，另外两个参数取头文件中的默认值 `nAccessMode = MV_ACCESS_Exclusive`、`nSwitchoverKey = 0`（对 USB3 设备这两个参数无效，见 A2）。
5. L194 `MV_CC_GetOptimalPacketSize`✓：原文 `int nPacketSize = MV_CC_GetOptimalPacketSize(handle);`。**仅当** `stDeviceList.pDeviceInfo[nIndex]->nTLayerType == MV_GIGE_DEVICE` 时调用（L192）；USB3 相机会跳过这一步和第 6 步。
6. L197 `MV_CC_SetIntValueEx`✓：原文 `nRet = MV_CC_SetIntValueEx(handle,"GevSCPSPacketSize",nPacketSize);`。仅在 GigE 相机且 `nPacketSize > 0` 时调用；失败只打印 Warning，不退出。
7. L210 `MV_CC_SetEnumValue`✓：原文 `nRet = MV_CC_SetEnumValue(handle, "TriggerMode", 0);`。按枚举数值 0 写入，即 Off（关闭触发，自由运行）。
8. L219 `MV_CC_GetPayloadSize`✓：原文 `nRet = MV_CC_GetPayloadSize(handle, &g_nPayloadSize, &nAlignment);`。`g_nPayloadSize`? 是 `uint64_t`✓ 全局变量（L9），`nAlignment`✓ 是 `unsigned int`（L218）。取到的值之后**没有被使用**。
9. L226 `MV_CC_StartGrabbing`✓：原文 `nRet = MV_CC_StartGrabbing(handle);`。调用前**没有**调用 `MV_CC_SetImageNodeNum`✓ 或 `MV_CC_SetGrabStrategy`✓，所以缓存节点数和取图策略都是默认值（节点数 1，策略 OneByOne，见第 10 项）。
10. L234 （非 SDK）原文 `nRet = pthread_create(&nThreadID, NULL ,WorkThread , handle);`：把 `handle`✓ 作为线程参数，传给取图线程。
11. L241 （非 SDK）`PressEnterToExit()`?：等用户按回车，然后 `g_bExit = true;`（L19）、`sleep(1);`（L20）。**没有 pthread_join**。
12. L244 `MV_CC_StopGrabbing`✓：原文 `nRet = MV_CC_StopGrabbing(handle);`
13. L252 `MV_CC_CloseDevice`✓：原文 `nRet = MV_CC_CloseDevice(handle);`
14. L260 `MV_CC_DestroyHandle`✓：原文 `nRet = MV_CC_DestroyHandle(handle);`，随后 L266 执行 `handle = NULL;`
15. L271 `MV_CC_DestroyHandle`✓（错误路径）：原文 `MV_CC_DestroyHandle(handle);`。只在 `do { … } while (0)` 中途 `break` 时、`handle != NULL` 的情况下执行，不检查返回值。注意：在这条路径上，即使已经打开了设备或开始了取流，也不会先调用 StopGrabbing 或 CloseDevice。
16. L276 `MV_CC_Finalize`✓：原文 `MV_CC_Finalize();`。无论成功与否都会执行，不检查返回值。

**取图线程 `WorkThread`?（L85–119，参数 `pUser`✓ 就是主线程传入的 `handle`✓）**

- 进入循环前：L89 `MV_FRAME_OUT stOutFrame = {0};`，L90 `memset(&stOutFrame, 0, sizeof(MV_FRAME_OUT));`。只清零这一次，循环中不再清零。
- 每次循环：
  - L94 `MV_CC_GetImageBuffer`✓：原文 `nRet = MV_CC_GetImageBuffer(pUser, &stOutFrame, 1000);`，超时 1000 ms。成功时打印 `MV_FRAME_OUT_INFO_EX.nExtendWidth`✓、`nExtendHeight`✓ 和 `nFrameNum`✓；失败时打印返回码。
  - L106 `MV_CC_FreeImageBuffer`✓：原文 `nRet = MV_CC_FreeImageBuffer(pUser, &stOutFrame);`。调用条件是 L104 `if(NULL != stOutFrame.pBufAddr)`，**而不是**看 `MV_CC_GetImageBuffer`✓ 是否返回 `MV_OK`✓。Free 之后 SDK 会不会把 `pBufAddr`✓ 置空，头文件没有说明；如果不置空，下一次取图失败时会对同一缓存再 Free 一次。
  - L112 检查 `g_bExit`?，为真就退出循环。

**这个示例没有做的事**（写驱动时需要自己补上）：没有设置缓存节点数和取图策略，没有注册异常回调，没有设置帧率和曝光，没有 join 取图线程就调用了 `MV_CC_StopGrabbing`✓，错误路径上也没有停流和关闭设备。
