# hik_camera_ws —— 海康双相机 ROS2 采集（第 1–5 步）

```text
hik_camera_ws/
├── src/
│   ├── hik_camera_interfaces/   # 消息和服务：FrameMeta.msg、SyncStatus.msg、SetValue.srv、SetRoi.srv
│   └── hik_camera_driver/       # 核心库 + 驱动类（第 1、2 步）+ ROS2 组件节点（第 3 步）
│       ├── src/hik_camera_node.cpp          # 相机节点（每台相机一个）
│       ├── src/stereo_coordinator_node.cpp  # 协调节点 /stereo：同时开始 / 停止、配对监控
│       ├── launch/single_camera.launch.py   # 单相机（第 3 步验收）
│       ├── launch/stereo.launch.py          # 双相机 + 协调节点，同一个容器（正式使用）
│       └── config/laptop_virtual.yaml、lab_real.yaml
└── tools/hik_probe/             # 探针程序（不是 ROS 包；放在 src 外面，colcon 不会编译它）
```

## 一、编译

```bash
source /opt/ros/humble/setup.bash      # 笔记本（Humble）
# source /opt/ros/jazzy/setup.bash     # 实验室主机（Jazzy）
cd hik_camera_ws
colcon build --symlink-install
source install/setup.bash
```

编译输出里应能看到 `找到海康 SDK：/opt/MVS/lib/64/libMvCameraControl.so`。**我这边没有 ROS 环境，节点代码只做过模拟头文件的语法检查，第一次编译可能会有报错**，把完整的错误信息发给我即可。

单元测试（不需要相机）：

```bash
./install/hik_camera_driver/lib/hik_camera_driver/test_core
./install/hik_camera_driver/lib/hik_camera_driver/test_driver
```

## 二、运行（以笔记本 + 虚拟相机为例）

运行前关闭 MVS 客户端里的相机连接。**终端 1**：

```bash
ros2 launch hik_camera_driver single_camera.launch.py camera:=left config:=laptop_virtual.yaml
```

启动日志会依次显示：打开相机 → 参数表结果（失败的项以 WARN 显示）→ ROI → 启动检查 → `就绪，等待 ~/start`，最后显示启动报告的保存位置（默认在 `~/.ros/hik_camera/reports/`）。

**终端 2**（每个新终端都要先 `source install/setup.bash`）：

```bash
ros2 service call /stereo/left/start std_srvs/srv/Trigger          # 开始出图
ros2 topic hz /stereo/left/image_raw                                # 应约为 60（虚拟相机可能偏低，属正常）
ros2 run rqt_image_view rqt_image_view                              # 选择 /stereo/left/image_raw
ros2 service call /stereo/left/get_status std_srvs/srv/Trigger      # 详细状态
ros2 service call /stereo/left/stop std_srvs/srv/Trigger            # 停止
```

运行中修改参数：

```bash
ros2 service call /stereo/left/set_exposure hik_camera_interfaces/srv/SetValue "{value: 3000.0}"
ros2 service call /stereo/left/set_gain hik_camera_interfaces/srv/SetValue "{value: 2.0}"
ros2 service call /stereo/left/set_roi hik_camera_interfaces/srv/SetRoi "{width: 640, height: 480, offset_x: 320, offset_y: 272}"
ros2 param set /stereo/left exposure_us 4000.0       # 和 set_exposure 效果相同
ros2 topic echo /stereo/left/frame_meta --once       # 查看一帧的附加信息
```

终端 1 每 10 秒打印一行状态（新增帧、帧号跳变、丢包、超时、错误、对时状态）。

## 三、第 3 步验收清单

| # | 检查项 | 笔记本（虚拟相机） | 实验室主机（真机，`config:=lab_real.yaml`） |
|---|---|---|---|
| 1 | 编译通过 | Humble | **Jazzy** |
| 2 | 启动日志：`failed_required=0`，最后显示“就绪” | ✓ | ✓ |
| 3 | 启动检查的编码 | `rgb8` | `bayer_gbrg8`，PayloadSize OK |
| 4 | 调用 start 后，`ros2 topic hz` | 有数据（帧率仅供参考） | **约 60 Hz** |
| 5 | rqt_image_view 能看到画面 | ✓ | ✓，并检查颜色（见第四节） |
| 6 | `frame_meta` 的 `time_source` | 2（接收时间，正常） | **0（设备时间）** |
| 7 | get_status：对时 | sync fail（正常） | `ready=1 prov=0`，约 +5 ppm |
| 8 | set_exposure / set_gain 返回 success，画面亮度变化 | ✓ | ✓ |
| 9 | set_roi 返回 success，画面尺寸变成 640x480，然后恢复全幅 | ✓ | ✓ |
| 10 | stop 后 hz 归零；Ctrl+C 退出后可以重新启动，没有“相机被占用” | ✓ | ✓ |

实验室主机上：把 get_status 的输出和终端 1 的状态行拍照发给我。

## 四、颜色检查（真机必做一次）

真机发布的是 Bayer 原始图（`bayer_gbrg8`）。用红色和蓝色的物体对着相机，在 rqt_image_view 里看颜色是否正确。

- **颜色正确**：说明 BayerGB8 → `bayer_gbrg8` 的对应关系是对的。
- **红蓝颠倒**：告诉我，我修改像素格式映射表（只需改一行）。
- **rqt_image_view 显示不了 Bayer 图**（报编码不支持）：告诉我。可以加一个 `image_proc` 节点转成彩色图来查看，或者在节点里加一个可选的转换开关。

## 五、常见问题

| 现象 | 原因和处理 |
|---|---|
| 启动时“打开相机失败……没有找到 user_id=left” | User ID 没设置，或者 MVS 客户端还连着相机。错误信息里会列出当前能找到的所有相机 |
| 返回 0x80000203 | 相机被其他程序占用（MVS、hik_probe、上一次没退出的节点）。用 `ps aux | grep -E "MVS|component_container|hik_"` 查找 |
| start 返回“启动配置有错误” | 启动日志里有 FAILED_REQUIRED 或者不支持的像素格式，按日志修改配置 |
| 编译找不到 `MvCameraControl.h` | 检查 `/opt/MVS/include` 是否存在；或者设置环境变量 `MVCAM_SDK_PATH` |
| 运行时报找不到 `libMvCameraControl.so` | 节点已经设置了 RPATH；如果仍然报错，执行 MVS 安装目录下的 `set_env_path.sh`，或者把 `/opt/MVS/lib/64` 加入 `LD_LIBRARY_PATH` |


---

## 六、双相机（第 4、5 步）

### 1. 启动

```bash
ros2 launch hik_camera_driver stereo.launch.py config:=laptop_virtual.yaml   # 笔记本
ros2 launch hik_camera_driver stereo.launch.py config:=lab_real.yaml         # 实验室主机
```

一个组件容器里有三个节点：`/stereo/left`、`/stereo/right`（相机）和 `/stereo`（协调节点）。可以用 `ros2 node list` 确认。

### 2. 同时开始 / 停止两台相机

```bash
ros2 service call /stereo/start std_srvs/srv/Trigger       # 同时向两台相机发送 start，并清零配对统计
ros2 service call /stereo/stop  std_srvs/srv/Trigger
```

返回信息里分别列出左右相机的结果，例如 `start 左[成功：已开始取流] 右[成功：已开始取流]`。单台相机的 `~/start` 仍然可以单独用来调试。

### 3. 看同步状态

```bash
ros2 topic echo /stereo/sync_status                          # 每秒一次
ros2 service call /stereo/get_status std_srvs/srv/Trigger    # 配对统计 + 左右相机的详细状态（适合拍照）
```

容器终端每 10 秒打印一行汇总，示意：

```
配对(近10s) 600对 平均3.91ms p99 3.92ms 最大3.93ms | fps L59.99 R59.99 | 累计 配对36000 未配对L2 R0 最大8.10ms | 帧号跳变L0 R0 消息丢失L0 R0 非设备时间L0 R0
```

| 字段 | 含义 | 正常值（真机） |
|---|---|---|
| 平均 / p99 / 最大 | 左右配对的时间差 | 平均值在 0–8.33 ms 之间，同一次运行中基本不变；最大 ≤ 8.33 ms |
| fps L / R | 最近 10 秒的帧率 | 约 60 |
| 未配对 L / R | 找不到对应帧的帧数 | 只在开始和结束时出现几个 |
| 帧号跳变 | 相机或 SDK 丢帧 | 0 |
| 消息丢失 | ROS 传输中丢了 frame_meta 消息 | 0 |
| 非设备时间 | 时间戳不是由设备时间换算的帧 | 真机 0；虚拟相机等于总帧数（正常） |

### 4. 第 4 步验收：30 分钟稳定性测试（实验室主机）

```bash
ros2 launch hik_camera_driver stereo.launch.py config:=lab_real.yaml   # 终端 1
ros2 service call /stereo/start std_srvs/srv/Trigger                   # 终端 2
# 等待 30 分钟，期间可以观察终端 1 每 10 秒的状态行
ros2 service call /stereo/get_status std_srvs/srv/Trigger              # 拍照
ros2 service call /stereo/stop std_srvs/srv/Trigger
```

**通过标准**：两路 fps 都约为 60；帧号跳变、消息丢失均为 0；未配对只有开头和结尾的几个；配对最大 ≤ 8.33 ms；两台相机的对时状态都是 `ready=1 prov=0`；没有掉线。

### 5. 第 5 步验收：录制

```bash
ros2 bag record -o test_bag /stereo/left/image_raw /stereo/right/image_raw \
                /stereo/left/frame_meta /stereo/right/frame_meta /stereo/sync_status
# 录 1 分钟后 Ctrl+C
ros2 bag info test_bag      # 两路图像各约 3600 条/分钟
```

注意：两路 1280×1024 Bayer 图像每分钟约 9.4 GB，注意磁盘空间。

## 七、还没有实现的部分（第 6 步，可选）

- **掉线自动重连**：目前掉线后会在状态里显示 `disconnected=1` 和错误码，需要手动重启 launch。
- **相位对齐**：把左右错位从“随机 0–8.33 ms”压到约 1 ms。
- 这两项要不要做、先做哪一项，可以根据测试结果再决定。


## 八、后续新增的功能（简要，详细用法见 docs/快速上手.md）

| 功能 | 用法 |
|---|---|
| 一键状态 | `ros2 run hik_camera_driver camstat.py`（`--watch 2` 自动刷新） |
| 白平衡校准 | `ros2 service call /stereo/<left|right>/white_balance_once std_srvs/srv/Trigger`，返回的比例填进配置文件的 `balance_ratio_*` |
| 通用参数读写 | `read_node` / `set_node` 服务，任何相机参数（对比度、Gamma、锐化……） |
| 演示窗口 | `stereo.launch.py ... demo:=true`；同一进程内显示，支持放大缩小、分辨率 / 帧率调节、截图 |
| 录制数据工具 | `tools/bag_fps.py`（帧率概要）、`tools/bag_to_pairs.py`（配对导出图片） |

工作空间根目录的 `.gitignore` 已经排除了 build、install、log，用 GitHub 同步时只上传源码，每台电脑各自编译。
