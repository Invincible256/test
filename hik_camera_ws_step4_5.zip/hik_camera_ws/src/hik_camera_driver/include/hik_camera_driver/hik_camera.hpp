// hik_camera.hpp —— 海康 USB3 相机驱动类（一台相机一个对象）
//
// 职责：
//   - 按 User ID 和 / 或序列号找到并打开相机（SDK 没有“按 ID 打开”的接口，只能枚举后比较）
//   - 通用参数读写：实现 ParamTable 的 NodeAccess 接口，另外提供读取范围的函数
//   - 开始 / 停止取流；内部的取图线程把每一帧交给回调函数
//   - 对时：内部线程每秒执行一次 Latch + 读 DeviceTimestamp，交给 ClockSync；
//           每帧的设备 tick 换算成主机时间（CLOCK_MONOTONIC）后随帧一起交出
//   - ROI 修改：宽高在取流中被锁定，setRoi() 会自动停流 → 按正确顺序设置 → 重新开流
//   - 掉线检测：SDK 异常回调置位标志（重连由上层处理，第 6 步）
//
// 线程模型：
//   取图线程：只调用 MV_CC_GetImageBuffer / MV_CC_FreeImageBuffer，以及用户回调。
//   对时线程：每 sync_period 执行一次 syncOnce()。
//   其他所有 SDK 调用（设参、读参、对时、开始 / 停止）都在 ctl_ 锁内串行执行。
//   hik_probe 在真机上验证过“取图线程 + 20 Hz 对时线程”同时运行不出错（压力测试见笔记 U6，待做）。
//
// 回调约束：回调在取图线程中执行，Frame::data 只在回调期间有效（之后缓存会被还给 SDK）。
//           回调里只做拷贝和发布，不要做耗时操作，否则会丢帧。
//
// 本头文件不包含海康 SDK 头文件。

#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include "hik_camera_driver/clock_sync.hpp"
#include "hik_camera_driver/param_table.hpp"
#include "hik_camera_driver/pixel_format.hpp"
#include "hik_camera_driver/sdk_context.hpp"

namespace hik_camera_driver {

// 自定义错误码（负数，与 SDK 的 0x8xxxxxxx 区分）
enum : int {
  kErrNotFound = -1,    // 没有找到匹配的相机
  kErrAmbiguous = -2,   // 有多台相机匹配
  kErrBadState = -3,    // 当前状态下不能执行（例如未打开、正在取流）
  kErrInvalidArg = -4,  // 参数不合法（例如 ROI 越界或不符合步进）
  kErrSdkInit = -5,     // SDK 初始化失败
};
std::string errorString(int code);  // "0x80000106 节点访问条件有误" 之类

struct CameraSelector {
  std::string user_id;  // 非空时必须匹配 Device User ID
  std::string serial;   // 非空时必须匹配序列号（两者都填时都要匹配）
  std::string describe() const;
};

struct IntInfo { int64_t cur = 0, min = 0, max = 0, inc = 1; };
struct FloatInfo { double cur = 0, min = 0, max = 0; };
struct EnumInfo {
  std::string cur;
  unsigned int cur_value = 0;
  std::vector<std::pair<std::string, unsigned int>> entries;  // 符号名 → 数值
};

enum class TimeSource {
  kDevice,             // 设备时间换算（正常）
  kDeviceProvisional,  // 设备时间换算，但模型样本不足（用名义斜率，精度稍差）
  kReceive,            // 无法换算（例如虚拟相机时间戳为 0），使用接收时刻
};
const char* toString(TimeSource s);

struct Frame {
  const uint8_t* data = nullptr;  // 只在回调期间有效
  std::size_t size = 0;
  uint32_t width = 0, height = 0;
  uint32_t pixel_type = 0;
  std::optional<PixelFormatInfo> format;  // 不认识的格式为空
  uint32_t frame_num = 0;
  uint64_t dev_ticks = 0;
  uint32_t lost_packet = 0;
  float exposure_us = 0, gain_db = 0;
  int64_t recv_mono_ns = 0;    // GetImageBuffer 返回时的主机时间（CLOCK_MONOTONIC）
  int64_t stamp_mono_ns = 0;   // 帧的时间戳（CLOCK_MONOTONIC）：设备时间换算结果，或退回接收时刻
  TimeSource time_source = TimeSource::kReceive;
  uint64_t seq = 0;            // 本次取流中的序号，从 0 开始
};
using FrameCallback = std::function<void(const Frame&)>;

struct HikCameraOptions {
  unsigned int image_node_num = 30;    // SDK 图像缓存数（默认只有 1 个，必须调大）
  unsigned int grab_timeout_ms = 200;
  double sync_period_s = 1.0;          // 取流中的对时间隔
  int startup_sync_samples = 10;       // 开始取流前先连续对时几次，保证第一帧就有模型
  int startup_sync_interval_ms = 50;
  ClockSyncConfig clock;               // nominal_ns_per_tick ≤ 0 时，从 DeviceTimestampIncrement 推算
};

struct CameraStats {
  uint64_t frames = 0;
  uint64_t grab_timeouts = 0;          // GetImageBuffer 超时（MV_E_NODATA）
  uint64_t grab_errors = 0;            // 其他取图错误
  int last_grab_error = 0;
  uint64_t frame_num_gaps = 0;         // 帧号不连续的次数
  uint64_t lost_packet_frames = 0;     // nLostPacket > 0 的帧数
  uint64_t receive_time_frames = 0;    // 时间戳退回接收时刻的帧数
  uint64_t provisional_frames = 0;
  uint64_t callback_exceptions = 0;
  uint64_t sync_ok = 0, sync_failed = 0;
  int last_sync_error = 0;
  uint32_t last_frame_num = 0;
};

class HikCamera : public NodeAccess {
 public:
  explicit HikCamera(HikCameraOptions opt = {});
  ~HikCamera() override;  // 自动停流并关闭
  HikCamera(const HikCamera&) = delete;
  HikCamera& operator=(const HikCamera&) = delete;

  // ---- 打开 / 关闭 ----
  int open(const CameraSelector& sel);  // 失败时 lastError() 给出原因（包括当前枚举到的设备）
  void close();
  bool isOpen() const;
  const DeviceDesc& device() const { return dev_; }
  double nominalNsPerTick() const { return nominal_ns_per_tick_; }
  std::string lastError() const;

  // ---- 参数（NodeAccess 接口，供 ParamTable 使用）----
  int setInt(const std::string& name, int64_t v) override;
  int setFloat(const std::string& name, double v) override;
  int setEnum(const std::string& name, const std::string& symbol) override;
  int setBool(const std::string& name, bool v) override;
  int setString(const std::string& name, const std::string& v) override;
  int read(const std::string& name, ParamType type, std::string& out) override;

  int getIntInfo(const std::string& name, IntInfo& out);
  int getFloatInfo(const std::string& name, FloatInfo& out);
  int getEnumInfo(const std::string& name, EnumInfo& out);
  int getBool(const std::string& name, bool& out);
  int getString(const std::string& name, std::string& out);

  // ---- 取流 ----
  int start(FrameCallback cb);  // 设缓存 → 启动前对时 → StartGrabbing → 启动取图和对时线程
  int stop();                   // 退出标志 → join 线程 → StopGrabbing
  bool isGrabbing() const { return grabbing_; }

  struct Roi { int64_t width = 0, height = 0, offset_x = 0, offset_y = 0; };
  int getRoi(Roi& out);
  // 检查范围和步进；取流中会自动停流、设置、重新开流（沿用原回调）。失败时尽量恢复原 ROI。
  int setRoi(const Roi& r, std::string* detail = nullptr);

  // ---- 对时 ----
  int syncOnce();  // Latch + 读 DeviceTimestamp，加入 ClockSync
  ClockSyncState clockState() const;

  // ---- 状态 ----
  CameraStats stats() const;
  bool disconnected() const { return disconnected_; }

  // 内部使用：SDK 异常回调的转发目标
  void handleSdkException(unsigned int msg_type);

 private:
  int ensureOpenLocked() const;
  int startImpl(FrameCallback cb);
  int stopImpl();
  void grabLoop();
  void syncLoop();
  void setError(const std::string& e) const;

  HikCameraOptions opt_;
  SdkContext& sdk_;
  void* h_ = nullptr;
  DeviceDesc dev_;
  double nominal_ns_per_tick_ = 0.0;
  std::unique_ptr<ClockSync> clock_;

  mutable std::mutex ctl_;        // 串行化控制类 SDK 调用
  std::mutex lifecycle_;          // open / close / start / stop / setRoi 互斥
  std::atomic<bool> run_{false}, grabbing_{false}, disconnected_{false};
  std::thread grab_th_, sync_th_;
  std::mutex sync_wait_mtx_;
  std::condition_variable sync_cv_;
  FrameCallback cb_;

  mutable std::mutex stats_mtx_;
  CameraStats stats_;
  uint64_t seq_ = 0;
  bool have_last_fn_ = false;

  mutable std::mutex err_mtx_;
  mutable std::string last_error_;
};

}  // namespace hik_camera_driver
