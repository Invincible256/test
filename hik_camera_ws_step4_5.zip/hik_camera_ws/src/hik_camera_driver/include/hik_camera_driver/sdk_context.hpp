// sdk_context.hpp —— 进程内唯一的海康 SDK 上下文
//
// 为什么需要它（sdk_notes.md 第 2、7、8 项）：
//   1. MV_CC_Initialize / MV_CC_Finalize 每个进程只能各调用一次。两个相机组件运行在同一个
//      组件容器进程里，不能各自初始化，必须共享。
//   2. MV_CC_EnumDevices 的结果存放在 SDK 内部，下一次枚举会覆盖上一次的结果（笔记本上实测）。
//      两个组件同时枚举会互相干扰，所以枚举要加锁，并立即按值拷贝设备信息。
//
// 用法：
//   auto& sdk = SdkContext::instance();     // 第一次调用时执行 MV_CC_Initialize
//   std::vector<DeviceDesc> devs; sdk.enumerate(devs);
//   ……
//   sdk.finalize();                          // 独立程序在 main 返回前调用；ROS 进程可以不调用
//
// 反初始化：如果没有显式调用 finalize()，静态对象析构时会自动调用 MV_CC_Finalize（前提是已没有
//   打开的相机）。静态析构阶段调用是否安全，文档没有说明（笔记 U6），独立程序建议显式调用。
//
// 本头文件不包含海康 SDK 头文件，上层代码（ROS 节点）不需要直接依赖 SDK 头文件。

#pragma once

#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace hik_camera_driver {

// 一台被枚举到的设备（按值拷贝，枚举结果被覆盖后仍然有效）
struct DeviceDesc {
  std::string model, serial, user_id, vendor, device_version;
  uint32_t tlayer_type = 0;   // 传输层类型：真机 0x4（USB），虚拟相机可能是 0x4 或 0x20
  bool is_virtual = false;    // 序列号以 "Vir" 开头
  std::shared_ptr<const void> raw;  // 内部使用：MV_CC_DEVICE_INFO 的拷贝

  std::string describe() const;     // "MV-CB013-A0UC-S serial=xxx user_id=left"
};

class SdkContext {
 public:
  static SdkContext& instance();

  SdkContext(const SdkContext&) = delete;
  SdkContext& operator=(const SdkContext&) = delete;

  int initResult() const { return init_ret_; }  // MV_CC_Initialize 的返回值，0 表示成功
  bool ok() const { return init_ret_ == 0 && !finalized_; }
  uint32_t sdkVersion() const;                  // 例如 0x04090003

  // 枚举 USB 相机（真机和虚拟相机都会被列出）。线程安全。返回 SDK 返回码。
  int enumerate(std::vector<DeviceDesc>& out);

  // 由 HikCamera 在打开 / 关闭相机时调用，用于防止在相机还没关闭时反初始化
  void registerHandle();
  void unregisterHandle();
  int openHandles() const;

  // 显式反初始化。还有打开的相机时拒绝执行，返回 -3。重复调用返回 0。
  int finalize();

 private:
  SdkContext();
  ~SdkContext();

  int init_ret_ = 0;
  bool finalized_ = false;
  int open_handles_ = 0;
  mutable std::mutex mtx_;       // 保护 open_handles_ / finalized_
  std::mutex enum_mtx_;          // 枚举互斥
};

}  // namespace hik_camera_driver
