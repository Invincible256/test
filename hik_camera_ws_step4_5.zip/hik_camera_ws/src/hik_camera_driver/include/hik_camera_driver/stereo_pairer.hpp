// stereo_pairer.hpp —— 左右相机帧的在线配对与同步统计（纯逻辑，不依赖 ROS 和 SDK）
//
// 配对规则：两台相机各自自由运行，按换算后的拍摄时刻配对。左右两帧的时间差 ≤ 半个帧周期
//           才算一对；否则判为“未配对”（例如另一台相机丢帧、刚开始或刚结束取流）。
// 理论：自由运行时，配对误差在 0 到 T/2 之间（60 Hz 时 ≤ 8.33 ms），真机实测平均约 3.9 ms。
//
// 做法：两路帧按时间顺序进入两个队列。处理时只看“截止时刻”之前的帧（给另一路留出到达时间），
//       每次比较两个队首：时间差 ≤ T/2 → 配成一对，同时出队；否则时间更早的那一帧判为未配对并出队。
//
// 统计：最近 window 内的配对误差（平均、p99、最大）和帧率；以及自开始以来的累计值：
//       配对数、未配对数、帧号不连续（相机 / SDK 丢帧）、序号不连续（ROS 传输丢消息）、非设备时间帧数。

#pragma once

#include <cstddef>
#include <cstdint>
#include <deque>
#include <string>

namespace hik_camera_driver {

enum class Side { kLeft = 0, kRight = 1 };

struct PairerFrame {
  int64_t stamp_ns = 0;      // 换算后的拍摄时刻（两路必须是同一个时钟）
  uint64_t seq = 0;          // 节点发布序号（重新开流后从 0 开始）
  uint32_t frame_num = 0;    // 相机帧号
  bool device_time = true;   // 时间戳是否由设备时间换算（不含临时模型）
};

struct PairerStats {
  double period_ms = 0, window_s = 0;
  // 窗口
  std::size_t window_pairs = 0;
  double window_mean_ms = 0, window_p99_ms = 0, window_max_ms = 0;
  double left_fps = 0, right_fps = 0;
  // 累计
  uint64_t total_pairs = 0, unpaired[2] = {0, 0};
  double total_max_ms = 0;
  uint64_t frames[2] = {0, 0}, frame_num_gaps[2] = {0, 0}, seq_gaps[2] = {0, 0}, not_device_time[2] = {0, 0};

  std::string summary() const;  // 一行文字，适合打印和拍照
};

class StereoPairer {
 public:
  StereoPairer(double fps = 60.0, double window_s = 10.0);

  void setFps(double fps);
  void add(Side side, const PairerFrame& f);
  // 配对截止时刻之前的帧。cutoff_ns 通常取“当前时间 − 0.3 s”（同一时钟）
  void process(int64_t cutoff_ns);
  // 计算统计；now_ns 用于确定窗口（同一时钟）
  PairerStats stats(int64_t now_ns) const;
  void reset();

 private:
  struct Diff { int64_t t; double ms; };
  struct SideState {
    std::deque<PairerFrame> queue;
    std::deque<int64_t> recent;  // 窗口内的帧时间，用于算帧率
    bool have_last = false;
    PairerFrame last;
  };
  void trim(int64_t now_ns);

  double period_ns_, window_ns_;
  SideState side_[2];
  std::deque<Diff> diffs_;
  PairerStats totals_;
};

}  // namespace hik_camera_driver
