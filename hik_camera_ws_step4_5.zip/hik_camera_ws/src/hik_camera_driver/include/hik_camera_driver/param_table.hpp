// param_table.hpp —— 按顺序写入相机参数的“参数表”
//
// 用途：相机启动时，把配置里列出的参数（参数分类文档中的 B 类，以及 A 类的初始值）
//       按固定顺序写入相机，记录每一项的返回码和读回值，生成启动报告。
//
// 配置格式：每项一个字符串，便于放进 ROS2 YAML 的字符串数组参数：
//       "节点名:类型:值"              默认为必需项
//       "节点名:类型:值:optional"     可选项：相机没有这个节点或写入失败时只警告
//       "节点名:类型:值:required"     显式声明为必需项
//   类型：int / float / enum / bool / string
//   例：  "TriggerMode:enum:Off"
//         "ExposureTime:float:5000"
//         "AcquisitionFrameRateEnable:bool:true"
//         "GammaEnable:bool:false:optional"
//   值里可以含冒号（例如字符串），只有最后一段等于 optional / required 时才被当作标志。
//
// 有意不支持 command 类型：避免配置写错时执行 DeviceReset、UserSetSave 等命令。
//
// 写入失败不会中断，所有项都会尝试一遍，报告里给出完整结果；是否允许继续启动由调用方根据
// ApplyReport::allRequiredOk() 决定。
//
// 读回值与设定值不一致只记为“不一致”（警告），不算失败：相机可能把值调整到合法值（步进、范围），
// 而且实测 AcquisitionFrameRate 写入后立即读回的值可能不是最新值。
//
// 不依赖 ROS，也不依赖海康 SDK：真正的读写由 NodeAccess 接口实现（第 2 步的 HikCamera）。

#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace hik_camera_driver {

enum class ParamType { kInt, kFloat, kEnum, kBool, kString };
const char* toString(ParamType t);

struct ParamEntry {
  std::string name;
  ParamType type = ParamType::kString;
  std::string value;     // 原始文本
  bool required = true;
  // 解析后的数值（按类型使用其中之一）
  int64_t int_value = 0;
  double float_value = 0.0;
  bool bool_value = false;

  std::string toSpec() const;  // 还原成配置字符串
};

struct ParseIssue {
  std::size_t index;   // 第几项（从 0 开始）
  std::string spec;    // 原始字符串
  std::string message;
};

struct ParseResult {
  std::vector<ParamEntry> entries;
  std::vector<ParseIssue> errors;    // 无法解析的项（不会进入 entries）
  std::vector<ParseIssue> warnings;  // 例如同一节点出现多次（后写的生效）
  bool ok() const { return errors.empty(); }
};

ParseResult parseParamSpecs(const std::vector<std::string>& specs);

// 节点读写接口。返回值为 SDK 返回码，0 表示成功。
class NodeAccess {
 public:
  virtual ~NodeAccess() = default;
  virtual int setInt(const std::string& name, int64_t v) = 0;
  virtual int setFloat(const std::string& name, double v) = 0;
  virtual int setEnum(const std::string& name, const std::string& symbol) = 0;
  virtual int setBool(const std::string& name, bool v) = 0;
  virtual int setString(const std::string& name, const std::string& v) = 0;
  // 读回当前值为文本：int 十进制；float 任意精度小数；enum 符号名；bool "true"/"false"；string 原文
  virtual int read(const std::string& name, ParamType type, std::string& out) = 0;
};

enum class ApplyStatus {
  kOk,              // 写入成功，读回一致
  kMismatch,        // 写入成功，读回不一致（警告）
  kReadbackFailed,  // 写入成功，读回失败（警告）
  kFailedOptional,  // 可选项写入失败（警告）
  kFailedRequired,  // 必需项写入失败（错误）
};
const char* toString(ApplyStatus s);

struct ApplyItem {
  ParamEntry entry;
  int set_ret = 0;
  int read_ret = 0;
  std::string readback;
  ApplyStatus status = ApplyStatus::kOk;

  std::string line() const;  // 一行文字，用于启动报告
};

struct ApplyReport {
  std::vector<ApplyItem> items;
  std::size_t countOf(ApplyStatus s) const;
  bool allRequiredOk() const { return countOf(ApplyStatus::kFailedRequired) == 0; }
  std::string summary() const;              // 一行统计
  std::vector<std::string> lines() const;   // 每项一行
};

// 按顺序写入并读回核对
ApplyReport applyParams(const std::vector<ParamEntry>& entries, NodeAccess& access);

// 读回值与设定值是否一致（float 允许 0.1% 或 1e-3 的误差）
bool valuesMatch(const ParamEntry& e, const std::string& readback);

std::string retHex(int ret);  // "0x80000106"

}  // namespace hik_camera_driver
