// clock_sync.hpp —— 相机设备时钟 → 主机时钟 的换算
//
// 作用：每帧图像带的是相机自己的时间（tick，从相机上电开始计数）。ClockSync 通过定期“对时”
//       建立直线模型  主机时间 = 截距 + 斜率 × tick，把每帧的 tick 换算成主机时间，
//       让左右相机、机械臂关节数据处在同一条时间轴上。
//
// 对时样本的采集方法（由调用方完成，见 HikCamera 驱动类）：
//       t0 = 读主机时钟
//       执行 DeviceTimestampLatch，再读 DeviceTimestamp 得到 tick（必须先 Latch，否则读到旧值）
//       t1 = 读主机时钟
//       认为该 tick 对应主机时间 (t0 + t1) / 2；往返时间 t1 - t0 越短，误差越小。
//
// 真机实测（MV-CB013-A0UC-S，hik_probe，2026-11-10）：
//       DeviceTimestampIncrement = 100000000，含义为时钟频率 100 MHz → 1 tick = 10 ns
//       相机时钟比主机慢约 5 ppm；取流中对时往返时间最小约 0.35 ms、中位约 0.41 ms、p99 约 1.5 ms
//       只用往返时间最短的样本拟合，残差标准差约 7 µs
//
// 主机时钟的选择：ClockSync 本身不关心用哪个主机时钟，只要求所有样本和换算结果用同一个时钟。
//       建议用 CLOCK_MONOTONIC（不会被网络校时调整）拟合，发布 ROS 消息时再换算到 ROS 时间。
//
// 线程安全：addSample() 和 toHost() 可以在不同线程同时调用（内部加锁，拟合结果按快照读取）。
//
// 不依赖 ROS，也不依赖海康 SDK。

#pragma once

#include <cstddef>
#include <cstdint>
#include <deque>
#include <mutex>
#include <optional>
#include <string>

namespace hik_camera_driver {

// 一次对时采样
struct SyncSample {
  int64_t host_t0_ns = 0;  // Latch 前的主机时间
  int64_t host_t1_ns = 0;  // 读回 tick 后的主机时间
  int64_t dev_ticks = 0;   // 相机时间戳（tick）

  int64_t rttNs() const { return host_t1_ns - host_t0_ns; }
  // 中点用 t0 + rtt/2 计算，避免两个大数相加溢出
  int64_t hostMidNs() const { return host_t0_ns + rttNs() / 2; }
};

struct ClockSyncConfig {
  // 名义上每个 tick 多少纳秒。>0 时用于：样本不足时的临时换算，以及检查拟合出的斜率是否合理。
  // CB013 真机为 10.0（由 DeviceTimestampIncrement = 1e8 Hz 得到，见 nsPerTickFromIncrement）。
  // =0 表示未知，此时必须攒够 min_samples 个样本才能换算。
  double nominal_ns_per_tick = 0.0;

  int64_t window_ns = 30'000'000'000LL;   // 只用最近 30 s 内的样本（适应快慢差的缓慢变化）
  std::size_t max_samples = 600;           // 窗口内最多保留的样本数
  double keep_fraction = 0.3;              // 拟合时只用往返时间最短的 30% 样本
  std::size_t min_samples = 5;             // 少于这个数，不做直线拟合
  int64_t min_span_ns = 2'000'000'000LL;   // 参与拟合的样本至少跨越 2 s，否则斜率误差太大，改用名义斜率
  int64_t max_rtt_ns = 5'000'000;          // 往返时间超过 5 ms 的样本直接丢弃
  double max_rate_error_ppm = 1000.0;      // 拟合斜率与名义值相差超过这个比例，视为异常，不采用
  int64_t reset_tolerance_ticks = 0;       // tick 比上一次小超过这个量，判定为相机时钟复位
};

enum class AddResult {
  kAccepted,        // 已加入并更新模型
  kRejectedRtt,     // 往返时间过长
  kRejectedInvalid, // tick ≤ 0，或主机时间不合法（虚拟相机的时间戳全为 0 时会走到这里）
  kClockReset,      // tick 倒退：相机重启 / 重连。旧样本已清空，本样本作为新的起点
};

const char* toString(AddResult r);

// 当前模型的快照，用于日志和状态发布
struct ClockSyncState {
  bool ready = false;          // 已有可用于换算的模型
  bool provisional = false;    // 样本不足，用名义斜率临时换算（精度较差）
  std::size_t window_samples = 0;  // 窗口内样本数
  std::size_t fit_samples = 0;     // 实际参与拟合的样本数
  double ns_per_tick = 0.0;        // 拟合斜率
  double rate_error_ppm = 0.0;     // 相对名义值的快慢差（名义值未知时为 0）
  double residual_rms_ns = 0.0;    // 参与拟合样本的残差均方根
  double residual_max_ns = 0.0;    // 参与拟合样本的最大残差
  int64_t fit_rtt_threshold_ns = 0;  // 被选中样本的往返时间上限
  int64_t last_sample_host_ns = 0;   // 最近一次接受样本的主机时间
  std::size_t total_accepted = 0, total_rejected_rtt = 0, total_rejected_invalid = 0, total_resets = 0;

  std::string summary() const;  // 一行文字，适合打印 / 放进结论卡
};

// 由 DeviceTimestampIncrement 推算每 tick 纳秒数。
// 真机实测该节点是时钟频率（Hz）：1e8 → 10 ns。
// 不在 100 kHz – 10 GHz 范围内的值返回 0（未知，由拟合决定斜率），避免把其他含义的值误当频率。
double nsPerTickFromIncrement(int64_t increment);

class ClockSync {
 public:
  explicit ClockSync(ClockSyncConfig cfg = {});

  AddResult addSample(const SyncSample& s);

  // 把 tick 换算成主机时间（ns）。模型未就绪时返回 std::nullopt。
  std::optional<int64_t> toHost(int64_t dev_ticks) const;

  ClockSyncState state() const;
  void reset();  // 清空全部样本和模型（统计计数保留）

  const ClockSyncConfig& config() const { return cfg_; }

 private:
  struct Model {
    bool valid = false;
    bool provisional = false;
    // 主机时间 = y_ref + slope × (tick - x_ref)，参考点取自样本，避免大数相乘损失精度
    //         = y_ref + cy + slope × ((tick - x_ref) - cx)，cx / cy 是拟合样本的质心
    int64_t x_ref = 0;
    int64_t y_ref = 0;
    long double cx = 0, cy = 0;
    long double slope = 0;
  };

  void evictLocked(int64_t newest_host_ns);
  void refitLocked();

  ClockSyncConfig cfg_;
  mutable std::mutex mtx_;
  std::deque<SyncSample> samples_;  // 按到达顺序
  Model model_;
  ClockSyncState stats_;
  int64_t last_ticks_ = 0;
  bool have_last_ = false;
};

}  // namespace hik_camera_driver
