// pixel_format.hpp —— 海康 SDK 像素格式 → ROS 图像编码
//
// 数值取自 /opt/MVS/include/PixelType.h（sdk_notes.md 附录 D5，已逐项核对）：
//   Mono8 0x01080001、BayerGR8 0x01080008、BayerRG8 0x01080009、BayerGB8 0x0108000A、
//   BayerBG8 0x0108000B、RGB8_Packed 0x02180014
// 真机 MV-CB013-A0UC-S 默认输出 BayerGB8；虚拟相机 MV-CS016-10UC 默认输出 RGB8_Packed（hik_probe 实测）。
//
// Bayer 命名规则：海康的 “BayerGB” 指第一行是 G B、第二行是 R G，即 2×2 排列 GBRG，
// 对应 ROS 的 "bayer_gbrg8"。这一对应关系必须用颜色明显的物体（红、蓝）实测确认一次。
//
// 只收录已核对的格式。不认识的格式返回 std::nullopt，调用方应报错，不要猜测。
// 不依赖 ROS，也不依赖海康 SDK。

#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>

namespace hik_camera_driver {

struct PixelFormatInfo {
  uint32_t sdk_value;        // 海康 MvGvspPixelType 数值
  const char* name;          // 海康名称
  const char* ros_encoding;  // sensor_msgs/image_encodings 中的字符串
  uint32_t bits_per_pixel;
  uint32_t channels;
  bool is_bayer;
};

std::optional<PixelFormatInfo> lookupPixelFormat(uint32_t sdk_value);
std::optional<PixelFormatInfo> lookupPixelFormatByName(const std::string& name);  // 如 "BayerGB8"

// 每行字节数（ROS Image.step）。bits_per_pixel 不是 8 的整数倍的格式不在表中，所以这里整除是安全的。
std::size_t rowBytes(const PixelFormatInfo& f, uint32_t width);
// 一帧应有的字节数，用于和 SDK 返回的帧长度、PayloadSize 交叉检查
std::size_t frameBytes(const PixelFormatInfo& f, uint32_t width, uint32_t height);

std::string pixelFormatHex(uint32_t v);  // "0x0108000A"

}  // namespace hik_camera_driver
