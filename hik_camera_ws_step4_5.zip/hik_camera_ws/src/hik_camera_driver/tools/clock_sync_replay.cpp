// clock_sync_replay.cpp —— 用 hik_probe 在真机上录下的数据回放验证 ClockSync
//
// 用法：clock_sync_replay <hik_probe 输出目录> [--latch-every N] [--window S]
//   --latch-every N   每 N 个对时样本只用 1 个（hik_probe 是 20 Hz，N=20 相当于正式方案的 1 Hz）。默认 20
//   --window S        滑动窗口秒数，默认 30
//
// 做法：按主机时间顺序依次“播放”对时样本和图像帧；每来一帧，就用当时已有的模型换算
//       （和正式运行时一样，只能用过去的样本），统计：
//   - 接收时刻 − 换算出的帧时间：应为正且非常稳定（hik_probe 离线分析结果：中位约 9.85 ms，标准差约 0.02 ms）
//   - 两台相机的最近帧时间差：应在 0 到半个帧周期之间
// 最后打印一张“结论卡”，可直接拍照。

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

#include "hik_camera_driver/clock_sync.hpp"

using namespace hik_camera_driver;

namespace {

std::vector<std::string> parseCsvLine(const std::string& line) {
  std::vector<std::string> out;
  std::string cur;
  bool inq = false;
  for (std::size_t i = 0; i < line.size(); ++i) {
    char c = line[i];
    if (inq) {
      if (c == '"' && i + 1 < line.size() && line[i + 1] == '"') { cur += '"'; ++i; }
      else if (c == '"') inq = false;
      else cur += c;
    } else if (c == '"') inq = true;
    else if (c == ',') { out.push_back(cur); cur.clear(); }
    else if (c != '\r') cur += c;
  }
  out.push_back(cur);
  return out;
}

struct Table {
  std::vector<std::string> header;
  std::vector<std::vector<std::string>> rows;
  int col(const std::string& name) const {
    for (std::size_t i = 0; i < header.size(); ++i)
      if (header[i] == name) return static_cast<int>(i);
    return -1;
  }
};

bool loadCsv(const std::string& path, Table& t) {
  std::ifstream f(path);
  if (!f) return false;
  std::string line;
  if (!std::getline(f, line)) return false;
  t.header = parseCsvLine(line);
  while (std::getline(f, line))
    if (!line.empty()) t.rows.push_back(parseCsvLine(line));
  return true;
}

double pct(std::vector<double> v, double p) {
  if (v.empty()) return NAN;
  std::sort(v.begin(), v.end());
  double k = (v.size() - 1) * p;
  std::size_t i = static_cast<std::size_t>(k);
  return i + 1 < v.size() ? v[i] + (v[i + 1] - v[i]) * (k - i) : v[i];
}
double stdev(const std::vector<double>& v) {
  if (v.size() < 2) return NAN;
  double m = 0;
  for (double x : v) m += x;
  m /= v.size();
  double s = 0;
  for (double x : v) s += (x - m) * (x - m);
  return std::sqrt(s / v.size());
}

struct CamResult {
  std::string tag;
  std::vector<int64_t> stamps;  // 换算出的帧时间（跳过第 1 秒）
  std::vector<std::string> card;
};

CamResult replayCamera(const std::string& dir, const std::string& tag, int every, double window_s) {
  CamResult res;
  res.tag = tag;
  auto C = [&](const std::string& s) { res.card.push_back(tag + " " + s); };

  // 名义斜率：从节点表读取 DeviceTimestampIncrement（真机为 1e8 Hz → 10 ns/tick）
  ClockSyncConfig cfg;
  cfg.window_ns = static_cast<int64_t>(window_s * 1e9);
  Table nodes;
  if (loadCsv(dir + "/" + tag + "_nodes_before.csv", nodes)) {
    int cn = nodes.col("node"), cv = nodes.col("value"), cr = nodes.col("read_ret");
    for (auto& r : nodes.rows)
      if (r[cn] == "DeviceTimestampIncrement" && r[cr] == "0x00000000") cfg.nominal_ns_per_tick = nsPerTickFromIncrement(std::atoll(r[cv].c_str()));
  }
  C("nominal_ns_per_tick=" + std::to_string(cfg.nominal_ns_per_tick));

  Table lat, frm;
  if (!loadCsv(dir + "/" + tag + "_latch_run.csv", lat) || !loadCsv(dir + "/" + tag + "_frames.csv", frm)) {
    C("缺少 latch_run.csv 或 frames.csv");
    return res;
  }
  struct Ev { int64_t t; bool is_latch; SyncSample s; int64_t ticks, recv; };
  std::vector<Ev> ev;
  int a0 = lat.col("t0_mono_ns"), a1 = lat.col("t1_mono_ns"), ad = lat.col("dev_ts"), ac = lat.col("ret_cmd"), ar = lat.col("ret_read");
  int k = 0;
  for (auto& r : lat.rows) {
    if (r[ac] != "0x00000000" || r[ar] != "0x00000000") continue;
    if ((k++ % every) != 0) continue;
    SyncSample s{std::atoll(r[a0].c_str()), std::atoll(r[a1].c_str()), std::atoll(r[ad].c_str())};
    ev.push_back({s.host_t1_ns, true, s, 0, 0});  // 样本在 t1 时刻才可用
  }
  int fd = frm.col("dev_ts"), fr = frm.col("recv_mono_ns");
  for (auto& r : frm.rows) {
    int64_t recv = std::atoll(r[fr].c_str());
    ev.push_back({recv, false, {}, std::atoll(r[fd].c_str()), recv});
  }
  std::stable_sort(ev.begin(), ev.end(), [](const Ev& x, const Ev& y) { return x.t < y.t; });

  ClockSync cs(cfg);
  std::vector<double> latency_ms;
  std::size_t frames = 0, not_ready = 0, provisional = 0;
  int64_t first_recv = -1;
  std::map<std::string, int> add_results;
  for (auto& e : ev) {
    if (e.is_latch) { add_results[toString(cs.addSample(e.s))]++; continue; }
    frames++;
    if (first_recv < 0) first_recv = e.recv;
    auto h = cs.toHost(static_cast<int64_t>(e.ticks));
    if (!h) { not_ready++; continue; }
    if (cs.state().provisional) provisional++;
    if (e.recv < first_recv + 1'000'000'000LL) continue;  // 跳过开始取流后的第 1 秒
    latency_ms.push_back((e.recv - *h) / 1e6);
    res.stamps.push_back(*h);
  }
  std::string ar_s;
  for (auto& kv : add_results) ar_s += kv.first + "=" + std::to_string(kv.second) + " ";
  C("对时样本(每" + std::to_string(every) + "个取1): " + ar_s);
  C("最终模型: " + cs.state().summary());
  char b[256];
  std::snprintf(b, sizeof b, "帧 %zu，模型未就绪 %zu，临时模型 %zu", frames, not_ready, provisional);
  C(b);
  std::snprintf(b, sizeof b, "在线换算: 接收-帧时间 ms 中位%.3f p1 %.3f p99 %.3f std %.4f", pct(latency_ms, .5), pct(latency_ms, .01),
                pct(latency_ms, .99), stdev(latency_ms));
  C(b);
  return res;
}

}  // namespace

int main(int argc, char** argv) {
  if (argc < 2) {
    std::fprintf(stderr, "用法: %s <hik_probe 输出目录> [--latch-every N] [--window S]\n", argv[0]);
    return 2;
  }
  std::string dir = argv[1];
  int every = 20;
  double window_s = 30;
  for (int i = 2; i + 1 < argc; i += 2) {
    std::string a = argv[i];
    if (a == "--latch-every") every = std::max(1, std::atoi(argv[i + 1]));
    else if (a == "--window") window_s = std::atof(argv[i + 1]);
  }
  // 从 devices.csv 找到被选中的相机标签（与 hik_probe 的命名规则一致：优先 User ID）
  Table dev;
  std::vector<std::string> tags;
  double fps = 60;
  if (loadCsv(dir + "/devices.csv", dev)) {
    int cu = dev.col("user_id"), cs = dev.col("serial"), cl = dev.col("selected");
    for (auto& r : dev.rows) {
      if (r[cl] != "1") continue;
      std::string t = r[cu].empty() ? r[cs] : r[cu];
      for (auto& ch : t) if (!(isalnum(static_cast<unsigned char>(ch)) || ch == '-' || ch == '_')) ch = '_';
      tags.push_back(t);
    }
  }
  std::ifstream env(dir + "/env.txt");
  for (std::string line; std::getline(env, line);) {
    auto p = line.find("fps=");
    if (line.rfind("options:", 0) == 0 && p != std::string::npos) fps = std::atof(line.c_str() + p + 4);
  }
  std::vector<std::string> card{"==== ClockSync 回放结论卡 " + dir + " ===="};
  std::vector<CamResult> res;
  for (auto& t : tags) {
    res.push_back(replayCamera(dir, t, every, window_s));
    card.insert(card.end(), res.back().card.begin(), res.back().card.end());
  }
  if (res.size() >= 2 && !res[0].stamps.empty() && !res[1].stamps.empty()) {
    std::vector<int64_t> b = res[1].stamps;
    std::sort(b.begin(), b.end());
    std::vector<double> d;
    double half = 500.0 / fps;
    std::size_t over = 0;
    for (int64_t t : res[0].stamps) {
      auto it = std::lower_bound(b.begin(), b.end(), t);
      double best = 1e18;
      if (it != b.end()) best = std::min(best, std::fabs(double(*it - t)));
      if (it != b.begin()) best = std::min(best, std::fabs(double(*(it - 1) - t)));
      best /= 1e6;
      if (best > half) { over++; continue; }  // 超过半个周期：未配对
      d.push_back(best);
    }
    char buf[256];
    std::snprintf(buf, sizeof buf, "配对(在线换算) ms: 平均%.3f 中位%.3f p99 %.3f 最大%.3f；未配对 %zu（阈值 %.2f ms）",
                  d.empty() ? NAN : [&] { double s = 0; for (double x : d) s += x; return s / d.size(); }(), pct(d, .5), pct(d, .99),
                  d.empty() ? NAN : *std::max_element(d.begin(), d.end()), over, half);
    card.push_back(buf);
  }
  for (auto& l : card) std::printf("%s\n", l.c_str());
  std::ofstream out(dir + "/replay_brief.txt");
  for (auto& l : card) out << l << "\n";
  std::printf("（已写入 %s/replay_brief.txt）\n", dir.c_str());
  return 0;
}
