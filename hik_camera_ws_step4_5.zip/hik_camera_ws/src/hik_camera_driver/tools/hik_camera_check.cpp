// hik_camera_check.cpp —— 用 HikCamera 驱动类在真机 / 虚拟相机上做一次完整验收
//
// 结果应与 hik_probe 的真机结果一致（交接文档第 4 节）：
//   60 Hz 无丢帧；“接收 − 帧时间”中位约 9.85 ms、标准差约 0.02 ms；配对误差在 0–8.33 ms 之间
//
// 用法：hik_camera_check [--ids left,right] [--fps 60] [--exposure 5000] [--duration 30]
//                         [--label NAME] [--settings FILE] [--no-roi-test] [--no-restore]
//
// 安全性：参数在结束时恢复原值（--no-restore 关闭）；不执行 UserSetSave；参数表不允许命令节点。

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <csignal>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include <sys/stat.h>
#include <unistd.h>

#include "hik_camera_driver/hik_camera.hpp"

using namespace hik_camera_driver;

namespace {

std::atomic<bool> g_abort{false};
void onSig(int) { g_abort = true; }

struct Opt {
  std::vector<std::string> ids{"left", "right"};
  double fps = 60, exposure = 5000;
  int duration = 30;
  std::string label, settings_file;
  bool roi_test = true, restore = true;
};

struct Rec { int64_t stamp, recv; uint32_t w, h, frame_num; std::size_t size; TimeSource src; };

struct Cam {
  std::string id;
  std::unique_ptr<HikCamera> cam;
  std::mutex m;
  std::vector<Rec> recs;
  std::vector<ParamEntry> originals;
  bool opened = false, started = false;
};

std::vector<std::string> defaultSettings(const Opt& o) {
  char e[64], f[64];
  std::snprintf(e, sizeof e, "%.3f", o.exposure);
  std::snprintf(f, sizeof f, "%.3f", o.fps);
  return {"AcquisitionMode:enum:Continuous", "TriggerSelector:enum:FrameBurstStart", "TriggerMode:enum:Off",
          "ExposureAuto:enum:Off", std::string("ExposureTime:float:") + e, "GainAuto:enum:Off",
          "BalanceWhiteAuto:enum:Off:optional", "AcquisitionFrameRateEnable:bool:true",
          std::string("AcquisitionFrameRate:float:") + f, "GammaEnable:bool:false:optional",
          "SharpnessEnable:bool:false:optional", "DigitalShiftEnable:bool:false:optional",
          "ContrastRatioEnable:bool:false:optional", "LUTEnable:bool:false:optional", "SequencerMode:enum:Off:optional"};
}

double pct(std::vector<double> v, double p) {
  if (v.empty()) return NAN;
  std::sort(v.begin(), v.end());
  double k = (v.size() - 1) * p;
  std::size_t i = static_cast<std::size_t>(k);
  return i + 1 < v.size() ? v[i] + (v[i + 1] - v[i]) * (k - i) : v[i];
}
double sd(const std::vector<double>& v) {
  if (v.size() < 2) return NAN;
  double m = 0;
  for (double x : v) m += x;
  m /= v.size();
  double s = 0;
  for (double x : v) s += (x - m) * (x - m);
  return std::sqrt(s / v.size());
}
std::string F(const char* fmt, ...) __attribute__((format(printf, 1, 2)));
std::string F(const char* fmt, ...) {
  char b[1024];
  va_list ap;
  va_start(ap, fmt);
  std::vsnprintf(b, sizeof b, fmt, ap);
  va_end(ap);
  return b;
}

}  // namespace

int main(int argc, char** argv) {
  Opt o;
  for (int i = 1; i < argc; ++i) {
    std::string a = argv[i];
    auto next = [&]() -> std::string { if (i + 1 >= argc) { std::fprintf(stderr, "%s 缺少参数\n", a.c_str()); std::exit(2); } return argv[++i]; };
    if (a == "--ids") { o.ids.clear(); std::string s = next(), cur; for (char c : s) { if (c == ',') { if (!cur.empty()) o.ids.push_back(cur); cur.clear(); } else cur += c; } if (!cur.empty()) o.ids.push_back(cur); }
    else if (a == "--fps") o.fps = std::atof(next().c_str());
    else if (a == "--exposure") o.exposure = std::atof(next().c_str());
    else if (a == "--duration") o.duration = std::atoi(next().c_str());
    else if (a == "--label") o.label = next();
    else if (a == "--settings") o.settings_file = next();
    else if (a == "--no-roi-test") o.roi_test = false;
    else if (a == "--no-restore") o.restore = false;
    else { std::fprintf(stderr, "未知参数 %s\n", a.c_str()); return 2; }
  }
  std::signal(SIGINT, onSig);

  // 输出目录
  char host[128] = {0};
  gethostname(host, sizeof host - 1);
  char ts[32];
  time_t tt = time(nullptr);
  strftime(ts, sizeof ts, "%Y%m%d_%H%M%S", localtime(&tt));
  std::string dir = std::string("check_out/") + ts + "_" + host + (o.label.empty() ? "" : "_" + o.label);
  mkdir("check_out", 0755);
  mkdir(dir.c_str(), 0755);
  std::vector<std::string> card{"==== hik_camera_check 结论卡 " + dir + " ===="};
  std::vector<std::string> log;
  std::mutex card_mtx;  // 启动线程里也可能写结论卡
  auto C = [&](const std::string& s) { std::lock_guard<std::mutex> lk(card_mtx); card.push_back(s); std::printf("%s\n", s.c_str()); };
  auto L = [&](const std::string& s) { log.push_back(s); std::printf("%s\n", s.c_str()); };

  auto& sdk = SdkContext::instance();
  C(F("SDK 0x%08X init=%s", sdk.sdkVersion(), retHex(sdk.initResult()).c_str()));

  // 参数表
  std::vector<std::string> specs = defaultSettings(o);
  if (!o.settings_file.empty()) {
    specs.clear();
    std::ifstream f(o.settings_file);
    for (std::string line; std::getline(f, line);) if (!line.empty() && line[0] != '#') specs.push_back(line);
  }
  ParseResult parsed = parseParamSpecs(specs);
  for (auto& e : parsed.errors) C("配置错误: " + e.spec + " → " + e.message);

  HikCameraOptions ho;  // 默认：缓存 30、每秒对时、开流前对时 10 次
  std::vector<std::unique_ptr<Cam>> cams;
  for (auto& id : o.ids) {
    auto c = std::make_unique<Cam>();
    c->id = id;
    c->cam = std::make_unique<HikCamera>(ho);
    int r = c->cam->open({id, ""});
    if (r != 0) { C(id + " 打开失败: " + c->cam->lastError()); cams.push_back(std::move(c)); continue; }
    c->opened = true;
    HikCamera& h = *c->cam;
    C(id + " " + h.device().describe() + F(" nominal=%.3f ns/tick", h.nominalNsPerTick()));
    // 记录原值，用于结束时恢复
    for (auto& e : parsed.entries) {
      std::string v;
      if (h.read(e.name, e.type, v) == 0) {
        auto p = parseParamSpecs({e.name + ":" + toString(e.type) + ":" + v + (e.required ? "" : ":optional")});
        if (p.ok() && !p.entries.empty()) c->originals.push_back(p.entries[0]);
      }
    }
    ApplyReport rep = applyParams(parsed.entries, h);
    C(id + " " + rep.summary());
    for (auto& it : rep.items) {
      L(id + " " + it.line());
      if (it.status != ApplyStatus::kOk) C(id + "   " + it.line());
    }
    // 启动检查
    EnumInfo pf;
    IntInfo w, hh, payload;
    FloatInfo res;
    if (h.getEnumInfo("PixelFormat", pf) == 0 && h.getIntInfo("Width", w) == 0 && h.getIntInfo("Height", hh) == 0 &&
        h.getIntInfo("PayloadSize", payload) == 0) {
      auto fmt = lookupPixelFormat(pf.cur_value);
      std::size_t expect = fmt ? frameBytes(*fmt, static_cast<uint32_t>(w.cur), static_cast<uint32_t>(hh.cur)) : 0;
      C(id + F(" 检查: PixelFormat=%s(%s) %lldx%lld PayloadSize=%lld 预期=%zu %s", pf.cur.c_str(),
               fmt ? fmt->ros_encoding : "未知格式", (long long)w.cur, (long long)hh.cur, (long long)payload.cur, expect,
               (fmt && (long long)expect == payload.cur) ? "OK" : "不一致"));
    }
    if (h.getFloatInfo("ResultingFrameRate", res) == 0) C(id + F(" 检查: ResultingFrameRate=%.3f（目标 %.3f）", res.cur, o.fps));
    EnumInfo usb;
    if (h.getEnumInfo("USBSpeedMode", usb) == 0) C(id + " 检查: USBSpeedMode=" + usb.cur);
    cams.push_back(std::move(c));
  }

  // 同时启动（两个线程并行，尽量缩短启动先后差）
  std::vector<std::thread> th;
  for (auto& cp : cams) {
    if (!cp->opened) continue;
    Cam* c = cp.get();
    th.emplace_back([c, &C] {
      int r = c->cam->start([c](const Frame& f) {
        std::lock_guard<std::mutex> lk(c->m);
        c->recs.push_back({f.stamp_mono_ns, f.recv_mono_ns, f.width, f.height, f.frame_num, f.size, f.time_source});
      });
      c->started = (r == 0);
      if (r != 0) C(c->id + " start 失败: " + c->cam->lastError());
    });
  }
  for (auto& t : th) t.join();
  C(F("取流 %d 秒……", o.duration));
  int half = o.duration / 2;
  for (int s = 0; s < o.duration && !g_abort; ++s) {
    std::this_thread::sleep_for(std::chrono::seconds(1));
    if (s == half) {  // 取流中修改曝光（A 类在线修改），再改回来
      for (auto& cp : cams) if (cp->started) {
        int r1 = cp->cam->setFloat("ExposureTime", o.exposure * 0.8);
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        int r2 = cp->cam->setFloat("ExposureTime", o.exposure);
        C(cp->id + " 取流中改曝光: " + retHex(r1) + " / 改回: " + retHex(r2));
      }
    }
  }

  // ROI 测试（只对第一台）：取流中改成中心 640x480 → 运行 2 秒 → 改回全幅
  std::string roi_result = "未测试";
  if (o.roi_test && !cams.empty() && cams[0]->started && !g_abort) {
    HikCamera& h = *cams[0]->cam;
    IntInfo wmax, hmax;
    h.getIntInfo("WidthMax", wmax);
    h.getIntInfo("HeightMax", hmax);
    HikCamera::Roi full{wmax.cur, hmax.cur, 0, 0}, small{640, 480, 0, 0};
    small.offset_x = ((wmax.cur - 640) / 2) / 16 * 16;
    small.offset_y = ((hmax.cur - 480) / 2) / 16 * 16;
    std::size_t before;
    { std::lock_guard<std::mutex> lk(cams[0]->m); before = cams[0]->recs.size(); }
    std::string d1, d2;
    auto t0 = std::chrono::steady_clock::now();
    int r1 = h.setRoi(small, &d1);
    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    std::this_thread::sleep_for(std::chrono::seconds(2));
    uint32_t gw = 0, gh = 0;
    { std::lock_guard<std::mutex> lk(cams[0]->m); if (cams[0]->recs.size() > before) { gw = cams[0]->recs.back().w; gh = cams[0]->recs.back().h; } }
    int r2 = h.setRoi(full, &d2);
    roi_result = F("设小 ROI ret=%s（耗时 %.0f ms，之后帧尺寸 %ux%u）；改回全幅 ret=%s", retHex(r1).c_str(), ms, gw, gh, retHex(r2).c_str());
    if (r1 != 0) roi_result += " " + d1;
    if (r2 != 0) roi_result += " " + d2;
    std::this_thread::sleep_for(std::chrono::seconds(1));
  }
  C(cams.empty() ? "无相机" : cams[0]->id + " ROI 测试: " + roi_result);

  for (auto& cp : cams) if (cp->started) { int r = cp->cam->stop(); C(cp->id + " stop ret=" + retHex(r)); }

  // 统计
  std::vector<std::vector<int64_t>> stamps;
  for (auto& cp : cams) {
    if (!cp->started) continue;
    auto st = cp->cam->stats();
    auto cs = cp->cam->clockState();
    std::vector<double> lat;
    std::size_t dev = 0;
    int64_t t_first = cp->recs.empty() ? 0 : cp->recs.front().recv;
    std::vector<int64_t> s;
    for (auto& r : cp->recs) {
      if (r.src != TimeSource::kReceive) dev++;
      if (r.recv < t_first + 1000000000LL) continue;  // 跳过第 1 秒
      lat.push_back((r.recv - r.stamp) / 1e6);
      s.push_back(r.stamp);
    }
    double span = cp->recs.size() > 1 ? (cp->recs.back().stamp - cp->recs.front().stamp) / 1e9 : 0;
    C(cp->id + F(" 帧 %llu（%.2f fps）帧号跳变 %llu 丢包帧 %llu 超时 %llu 错误 %llu；设备时间帧 %zu 临时 %llu 接收时间帧 %llu",
                 (unsigned long long)st.frames, span > 0 ? (cp->recs.size() - 1) / span : NAN, (unsigned long long)st.frame_num_gaps,
                 (unsigned long long)st.lost_packet_frames, (unsigned long long)st.grab_timeouts, (unsigned long long)st.grab_errors, dev,
                 (unsigned long long)st.provisional_frames, (unsigned long long)st.receive_time_frames));
    C(cp->id + F(" 对时 ok=%llu fail=%llu；", (unsigned long long)st.sync_ok, (unsigned long long)st.sync_failed) + cs.summary());
    C(cp->id + F(" 接收-帧时间 ms: 中位 %.3f p1 %.3f p99 %.3f std %.4f（ROI 测试期间的帧也包含在内）", pct(lat, .5), pct(lat, .01), pct(lat, .99), sd(lat)));
    if (cp->cam->disconnected()) C(cp->id + " 掉线: " + cp->cam->lastError());
    std::sort(s.begin(), s.end());
    stamps.push_back(s);
    // 每帧记录（留在实验室电脑上，需要时再分析）
    std::ofstream f(dir + "/" + cp->id + "_frames.csv");
    f << "frame_num,stamp_mono_ns,recv_mono_ns,width,height,size,time_source\n";
    for (auto& r : cp->recs) f << r.frame_num << "," << r.stamp << "," << r.recv << "," << r.w << "," << r.h << "," << r.size << "," << toString(r.src) << "\n";
  }
  if (stamps.size() >= 2 && !stamps[0].empty() && !stamps[1].empty()) {
    double half_ms = 500.0 / o.fps;
    std::vector<double> d;
    std::size_t unpaired = 0;
    for (int64_t t : stamps[0]) {
      auto it = std::lower_bound(stamps[1].begin(), stamps[1].end(), t);
      double best = 1e18;
      if (it != stamps[1].end()) best = std::min(best, std::fabs(double(*it - t)));
      if (it != stamps[1].begin()) best = std::min(best, std::fabs(double(*(it - 1) - t)));
      best /= 1e6;
      if (best > half_ms) unpaired++;
      else d.push_back(best);
    }
    double mean = 0;
    for (double x : d) mean += x;
    mean = d.empty() ? NAN : mean / d.size();
    C(F("配对 ms: 平均 %.3f 中位 %.3f p99 %.3f 最大 %.3f；未配对 %zu（阈值 %.2f）", mean, pct(d, .5), pct(d, .99),
        d.empty() ? NAN : *std::max_element(d.begin(), d.end()), unpaired, half_ms));
  }

  // 恢复并关闭
  for (auto& cp : cams) {
    if (!cp->opened) continue;
    if (o.restore) {
      ApplyReport rr = applyParams(cp->originals, *cp->cam);
      C(cp->id + " 恢复原值: " + rr.summary());
    }
    cp->cam->close();
  }
  cams.clear();
  C("finalize ret=" + retHex(SdkContext::instance().finalize()));

  std::ofstream b(dir + "/brief.txt");
  for (auto& l : card) b << l << "\n";
  std::ofstream lg(dir + "/params.txt");
  for (auto& l : log) lg << l << "\n";
  std::printf("\n");
  for (auto& l : card) std::printf("%s\n", l.c_str());
  std::printf("（结论卡已写入 %s/brief.txt）\n", dir.c_str());
  return 0;
}
