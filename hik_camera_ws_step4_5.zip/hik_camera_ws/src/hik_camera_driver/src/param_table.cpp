// param_table.cpp —— 见 param_table.hpp

#include "hik_camera_driver/param_table.hpp"

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <map>

namespace hik_camera_driver {

const char* toString(ParamType t) {
  switch (t) {
    case ParamType::kInt: return "int";
    case ParamType::kFloat: return "float";
    case ParamType::kEnum: return "enum";
    case ParamType::kBool: return "bool";
    case ParamType::kString: return "string";
  }
  return "?";
}

const char* toString(ApplyStatus s) {
  switch (s) {
    case ApplyStatus::kOk: return "OK";
    case ApplyStatus::kMismatch: return "MISMATCH";
    case ApplyStatus::kReadbackFailed: return "READBACK_FAILED";
    case ApplyStatus::kFailedOptional: return "FAILED_OPTIONAL";
    case ApplyStatus::kFailedRequired: return "FAILED_REQUIRED";
  }
  return "?";
}

std::string retHex(int ret) {
  char b[16];
  std::snprintf(b, sizeof(b), "0x%08X", static_cast<unsigned int>(ret));
  return b;
}

std::string ParamEntry::toSpec() const {
  return name + ":" + toString(type) + ":" + value + (required ? "" : ":optional");
}

namespace {

std::string trim(const std::string& s) {
  std::size_t b = s.find_first_not_of(" \t\r\n"), e = s.find_last_not_of(" \t\r\n");
  return b == std::string::npos ? std::string() : s.substr(b, e - b + 1);
}

std::vector<std::string> split(const std::string& s, char sep) {
  std::vector<std::string> out;
  std::string cur;
  for (char c : s) {
    if (c == sep) { out.push_back(cur); cur.clear(); }
    else cur += c;
  }
  out.push_back(cur);
  return out;
}

bool parseType(const std::string& t, ParamType& out) {
  if (t == "int") out = ParamType::kInt;
  else if (t == "float") out = ParamType::kFloat;
  else if (t == "enum") out = ParamType::kEnum;
  else if (t == "bool") out = ParamType::kBool;
  else if (t == "string") out = ParamType::kString;
  else return false;
  return true;
}

bool parseInt(const std::string& s, int64_t& v) {
  if (s.empty()) return false;
  errno = 0;
  char* end = nullptr;
  long long x = std::strtoll(s.c_str(), &end, 0);  // 支持十进制和 0x 十六进制
  if (errno != 0 || end == s.c_str() || *end != '\0') return false;
  v = x;
  return true;
}

bool parseFloat(const std::string& s, double& v) {
  if (s.empty()) return false;
  errno = 0;
  char* end = nullptr;
  double x = std::strtod(s.c_str(), &end);
  if (errno != 0 || end == s.c_str() || *end != '\0' || !std::isfinite(x)) return false;
  v = x;
  return true;
}

bool parseBool(const std::string& s, bool& v) {
  if (s == "true" || s == "True" || s == "1" || s == "on" || s == "On") { v = true; return true; }
  if (s == "false" || s == "False" || s == "0" || s == "off" || s == "Off") { v = false; return true; }
  return false;
}

}  // namespace

ParseResult parseParamSpecs(const std::vector<std::string>& specs) {
  ParseResult res;
  std::map<std::string, std::size_t> seen;
  for (std::size_t i = 0; i < specs.size(); ++i) {
    const std::string spec = trim(specs[i]);
    auto fail = [&](const std::string& msg) { res.errors.push_back({i, specs[i], msg}); };
    if (spec.empty()) { fail("空字符串"); continue; }

    std::vector<std::string> parts = split(spec, ':');
    if (parts.size() < 3) { fail("格式应为 节点名:类型:值[:optional]"); continue; }

    ParamEntry e;
    e.name = trim(parts[0]);
    if (e.name.empty()) { fail("节点名为空"); continue; }
    const std::string type_s = trim(parts[1]);
    if (type_s == "command") { fail("不支持 command 类型（避免误执行 DeviceReset 等命令）"); continue; }
    if (!parseType(type_s, e.type)) { fail("未知类型 \"" + type_s + "\"，应为 int / float / enum / bool / string"); continue; }

    std::size_t value_end = parts.size();
    const std::string last = trim(parts.back());
    if (parts.size() >= 4 && (last == "optional" || last == "required")) {
      e.required = (last == "required");
      value_end = parts.size() - 1;
    }
    std::string value;
    for (std::size_t k = 2; k < value_end; ++k) value += (k > 2 ? ":" : "") + parts[k];
    e.value = (e.type == ParamType::kString) ? value : trim(value);

    bool ok = true;
    switch (e.type) {
      case ParamType::kInt: ok = parseInt(e.value, e.int_value); break;
      case ParamType::kFloat: ok = parseFloat(e.value, e.float_value); break;
      case ParamType::kBool: ok = parseBool(e.value, e.bool_value); break;
      case ParamType::kEnum: ok = !e.value.empty(); break;
      case ParamType::kString: ok = true; break;
    }
    if (!ok) { fail("值 \"" + e.value + "\" 不是合法的 " + toString(e.type)); continue; }

    auto it = seen.find(e.name);
    if (it != seen.end()) res.warnings.push_back({i, specs[i], "节点 " + e.name + " 重复出现，将按顺序再次写入"});
    seen[e.name] = i;
    res.entries.push_back(e);
  }
  return res;
}

bool valuesMatch(const ParamEntry& e, const std::string& rb) {
  switch (e.type) {
    case ParamType::kInt: {
      int64_t v;
      return parseInt(trim(rb), v) && v == e.int_value;
    }
    case ParamType::kFloat: {
      double v;
      if (!parseFloat(trim(rb), v)) return false;
      double tol = std::max(1e-3, std::fabs(e.float_value) * 1e-3);
      return std::fabs(v - e.float_value) <= tol;
    }
    case ParamType::kBool: {
      bool v;
      return parseBool(trim(rb), v) && v == e.bool_value;
    }
    case ParamType::kEnum: return trim(rb) == e.value;
    case ParamType::kString: return rb == e.value;
  }
  return false;
}

ApplyReport applyParams(const std::vector<ParamEntry>& entries, NodeAccess& access) {
  ApplyReport rep;
  for (const auto& e : entries) {
    ApplyItem it;
    it.entry = e;
    switch (e.type) {
      case ParamType::kInt: it.set_ret = access.setInt(e.name, e.int_value); break;
      case ParamType::kFloat: it.set_ret = access.setFloat(e.name, e.float_value); break;
      case ParamType::kEnum: it.set_ret = access.setEnum(e.name, e.value); break;
      case ParamType::kBool: it.set_ret = access.setBool(e.name, e.bool_value); break;
      case ParamType::kString: it.set_ret = access.setString(e.name, e.value); break;
    }
    if (it.set_ret != 0) {
      it.status = e.required ? ApplyStatus::kFailedRequired : ApplyStatus::kFailedOptional;
    } else {
      it.read_ret = access.read(e.name, e.type, it.readback);
      if (it.read_ret != 0) it.status = ApplyStatus::kReadbackFailed;
      else it.status = valuesMatch(e, it.readback) ? ApplyStatus::kOk : ApplyStatus::kMismatch;
    }
    rep.items.push_back(it);
  }
  return rep;
}

std::string ApplyItem::line() const {
  std::string s = std::string(toString(status)) + "  " + entry.name + " = " + entry.value + " (" + toString(entry.type) +
                  (entry.required ? "" : ", optional") + ")";
  if (set_ret != 0) s += "  set_ret=" + retHex(set_ret);
  else if (read_ret != 0) s += "  read_ret=" + retHex(read_ret);
  else s += "  readback=" + readback;
  return s;
}

std::size_t ApplyReport::countOf(ApplyStatus s) const {
  std::size_t n = 0;
  for (const auto& it : items) n += (it.status == s);
  return n;
}

std::string ApplyReport::summary() const {
  char b[256];
  std::snprintf(b, sizeof(b), "params: %zu total, ok=%zu mismatch=%zu readback_failed=%zu failed_optional=%zu failed_required=%zu",
                items.size(), countOf(ApplyStatus::kOk), countOf(ApplyStatus::kMismatch), countOf(ApplyStatus::kReadbackFailed),
                countOf(ApplyStatus::kFailedOptional), countOf(ApplyStatus::kFailedRequired));
  return b;
}

std::vector<std::string> ApplyReport::lines() const {
  std::vector<std::string> out;
  for (const auto& it : items) out.push_back(it.line());
  return out;
}

}  // namespace hik_camera_driver
