// clock_sync.cpp —— 见 clock_sync.hpp 的说明

#include "hik_camera_driver/clock_sync.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

namespace hik_camera_driver {

const char* toString(AddResult r) {
  switch (r) {
    case AddResult::kAccepted: return "accepted";
    case AddResult::kRejectedRtt: return "rejected_rtt";
    case AddResult::kRejectedInvalid: return "rejected_invalid";
    case AddResult::kClockReset: return "clock_reset";
  }
  return "unknown";
}

std::string ClockSyncState::summary() const {
  char buf[512];
  std::snprintf(buf, sizeof(buf),
                "ready=%d prov=%d n=%zu/%zu ns_per_tick=%.9f (%+.2f ppm) rms=%.1fus max=%.1fus rtt<=%.0fus "
                "acc=%zu rej_rtt=%zu rej_inv=%zu resets=%zu",
                ready ? 1 : 0, provisional ? 1 : 0, fit_samples, window_samples, ns_per_tick, rate_error_ppm,
                residual_rms_ns / 1e3, residual_max_ns / 1e3, fit_rtt_threshold_ns / 1e3, total_accepted,
                total_rejected_rtt, total_rejected_invalid, total_resets);
  return buf;
}

double nsPerTickFromIncrement(int64_t increment) {
  // 只有落在合理时钟频率范围（100 kHz – 10 GHz）内才按“频率”解释；
  // 其他值（例如虚拟相机描述文件中“每 tick 多少 ns”的 1）视为未知，完全由拟合决定斜率。
  if (increment < 100'000 || increment > 10'000'000'000LL) return 0.0;
  return 1e9 / static_cast<double>(increment);
}

ClockSync::ClockSync(ClockSyncConfig cfg) : cfg_(cfg) {
  if (cfg_.min_samples < 2) cfg_.min_samples = 2;
  if (cfg_.max_samples < cfg_.min_samples) cfg_.max_samples = cfg_.min_samples;
  if (cfg_.keep_fraction <= 0.0 || cfg_.keep_fraction > 1.0) cfg_.keep_fraction = 1.0;
}

AddResult ClockSync::addSample(const SyncSample& s) {
  std::lock_guard<std::mutex> lk(mtx_);
  if (s.dev_ticks <= 0 || s.rttNs() < 0) {
    stats_.total_rejected_invalid++;
    return AddResult::kRejectedInvalid;
  }
  if (s.rttNs() > cfg_.max_rtt_ns) {
    stats_.total_rejected_rtt++;
    return AddResult::kRejectedRtt;
  }

  AddResult result = AddResult::kAccepted;
  if (have_last_ && s.dev_ticks + cfg_.reset_tolerance_ticks < last_ticks_) {
    // tick 倒退：相机时钟从 0 重新开始（重启、重连）。旧模型作废。
    samples_.clear();
    model_ = Model{};
    stats_.total_resets++;
    result = AddResult::kClockReset;
  }

  samples_.push_back(s);
  last_ticks_ = s.dev_ticks;
  have_last_ = true;
  stats_.total_accepted++;
  stats_.last_sample_host_ns = s.hostMidNs();
  evictLocked(s.hostMidNs());
  refitLocked();
  return result;
}

void ClockSync::evictLocked(int64_t newest_host_ns) {
  while (!samples_.empty() &&
         (newest_host_ns - samples_.front().hostMidNs() > cfg_.window_ns || samples_.size() > cfg_.max_samples)) {
    samples_.pop_front();
  }
}

void ClockSync::refitLocked() {
  stats_.window_samples = samples_.size();
  stats_.fit_samples = 0;
  stats_.residual_rms_ns = stats_.residual_max_ns = 0.0;
  stats_.rate_error_ppm = 0.0;
  model_ = Model{};
  if (samples_.empty()) return;

  // 1. 按往返时间排序，只保留最短的一部分
  std::vector<SyncSample> sel(samples_.begin(), samples_.end());
  std::sort(sel.begin(), sel.end(), [](const SyncSample& a, const SyncSample& b) { return a.rttNs() < b.rttNs(); });
  std::size_t k = static_cast<std::size_t>(std::ceil(sel.size() * cfg_.keep_fraction));
  k = std::max(k, cfg_.min_samples);
  k = std::min(k, sel.size());
  sel.resize(k);
  stats_.fit_rtt_threshold_ns = sel.back().rttNs();

  // 2. 以第一个（往返时间最短的）样本为参考点，计算质心
  Model m;
  m.x_ref = sel.front().dev_ticks;
  m.y_ref = sel.front().hostMidNs();
  long double sx = 0, sy = 0;
  int64_t tmin = sel.front().hostMidNs(), tmax = tmin;
  for (const auto& p : sel) {
    sx += static_cast<long double>(p.dev_ticks - m.x_ref);
    sy += static_cast<long double>(p.hostMidNs() - m.y_ref);
    tmin = std::min(tmin, p.hostMidNs());
    tmax = std::max(tmax, p.hostMidNs());
  }
  const long double n = static_cast<long double>(sel.size());
  m.cx = sx / n;
  m.cy = sy / n;

  // 3. 最小二乘求斜率（用去质心后的值，避免大数相减丢精度）
  long double sxx = 0, sxy = 0;
  for (const auto& p : sel) {
    long double dx = static_cast<long double>(p.dev_ticks - m.x_ref) - m.cx;
    long double dy = static_cast<long double>(p.hostMidNs() - m.y_ref) - m.cy;
    sxx += dx * dx;
    sxy += dx * dy;
  }

  const bool enough = sel.size() >= cfg_.min_samples && (tmax - tmin) >= cfg_.min_span_ns && sxx > 0;
  bool use_fit = enough;
  long double slope = enough ? sxy / sxx : 0;
  if (use_fit && cfg_.nominal_ns_per_tick > 0) {
    double err_ppm = static_cast<double>(slope / cfg_.nominal_ns_per_tick - 1.0L) * 1e6;
    if (std::fabs(err_ppm) > cfg_.max_rate_error_ppm) use_fit = false;  // 斜率不合理，退回名义值
  }

  if (use_fit) {
    m.slope = slope;
    m.provisional = false;
  } else if (cfg_.nominal_ns_per_tick > 0) {
    m.slope = cfg_.nominal_ns_per_tick;  // 名义斜率 + 质心作为截距：临时可用
    m.provisional = true;
  } else {
    return;  // 名义值未知且样本不足：暂时无法换算
  }
  m.valid = true;

  // 4. 残差
  long double ss = 0, mx = 0;
  for (const auto& p : sel) {
    long double dx = static_cast<long double>(p.dev_ticks - m.x_ref) - m.cx;
    long double pred = m.cy + m.slope * dx;
    long double r = static_cast<long double>(p.hostMidNs() - m.y_ref) - pred;
    ss += r * r;
    mx = std::max(mx, std::fabs(r));
  }
  stats_.fit_samples = sel.size();
  stats_.residual_rms_ns = static_cast<double>(std::sqrt(ss / n));
  stats_.residual_max_ns = static_cast<double>(mx);
  stats_.rate_error_ppm =
      cfg_.nominal_ns_per_tick > 0 ? static_cast<double>(m.slope / cfg_.nominal_ns_per_tick - 1.0L) * 1e6 : 0.0;
  model_ = m;
}

std::optional<int64_t> ClockSync::toHost(int64_t dev_ticks) const {
  std::lock_guard<std::mutex> lk(mtx_);
  if (!model_.valid) return std::nullopt;
  long double dx = static_cast<long double>(dev_ticks - model_.x_ref) - model_.cx;
  long double y = static_cast<long double>(model_.y_ref) + model_.cy + model_.slope * dx;
  return static_cast<int64_t>(std::llround(y));
}

ClockSyncState ClockSync::state() const {
  std::lock_guard<std::mutex> lk(mtx_);
  ClockSyncState s = stats_;
  s.ready = model_.valid;
  s.provisional = model_.valid && model_.provisional;
  s.ns_per_tick = model_.valid ? static_cast<double>(model_.slope) : 0.0;
  return s;
}

void ClockSync::reset() {
  std::lock_guard<std::mutex> lk(mtx_);
  samples_.clear();
  model_ = Model{};
  have_last_ = false;
  last_ticks_ = 0;
  stats_.window_samples = stats_.fit_samples = 0;
}

}  // namespace hik_camera_driver
