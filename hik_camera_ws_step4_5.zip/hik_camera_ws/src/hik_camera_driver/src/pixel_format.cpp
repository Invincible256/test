// pixel_format.cpp —— 见 pixel_format.hpp

#include "hik_camera_driver/pixel_format.hpp"

#include <cstdio>
#include <cstring>

namespace hik_camera_driver {

namespace {
constexpr PixelFormatInfo kTable[] = {
    {0x01080001u, "Mono8", "mono8", 8, 1, false},
    {0x01080008u, "BayerGR8", "bayer_grbg8", 8, 1, true},
    {0x01080009u, "BayerRG8", "bayer_rggb8", 8, 1, true},
    {0x0108000Au, "BayerGB8", "bayer_gbrg8", 8, 1, true},
    {0x0108000Bu, "BayerBG8", "bayer_bggr8", 8, 1, true},
    {0x02180014u, "RGB8_Packed", "rgb8", 24, 3, false},
};
}  // namespace

std::optional<PixelFormatInfo> lookupPixelFormat(uint32_t sdk_value) {
  for (const auto& f : kTable)
    if (f.sdk_value == sdk_value) return f;
  return std::nullopt;
}

std::optional<PixelFormatInfo> lookupPixelFormatByName(const std::string& name) {
  for (const auto& f : kTable)
    if (name == f.name) return f;
  if (name == "RGB8") return lookupPixelFormat(0x02180014u);  // GenICam 节点里的符号名是 RGB8Packed / RGB8
  if (name == "RGB8Packed") return lookupPixelFormat(0x02180014u);
  return std::nullopt;
}

std::size_t rowBytes(const PixelFormatInfo& f, uint32_t width) {
  return static_cast<std::size_t>(width) * f.bits_per_pixel / 8;
}

std::size_t frameBytes(const PixelFormatInfo& f, uint32_t width, uint32_t height) {
  return rowBytes(f, width) * height;
}

std::string pixelFormatHex(uint32_t v) {
  char b[16];
  std::snprintf(b, sizeof(b), "0x%08X", v);
  return b;
}

}  // namespace hik_camera_driver
