// stereo_coordinator_node.cpp —— 第 4、5 步：双相机协调节点（与两个相机节点放在同一个组件容器中）
//
// 节点名 /stereo，提供：
//   /stereo/start、/stereo/stop        std_srvs/Trigger：同时启动 / 停止左右相机（并发发送请求，缩短启动先后差）
//   /stereo/get_status                 std_srvs/Trigger：配对统计 + 左右相机各自的 get_status
//   /stereo/reset_stats                std_srvs/Trigger：清零配对统计（例如开始 30 分钟稳定性测试前）
//   /stereo/sync_status                hik_camera_interfaces/SyncStatus：每秒一次
// 订阅：<left_node>/frame_meta、<right_node>/frame_meta（只订阅小消息，不订阅图像）
//
// 注意：必须运行在多线程执行器中（component_container_mt）。服务回调里会等待相机节点的响应，
//       单线程执行器下会等到超时。

#include <chrono>
#include <future>
#include <memory>
#include <mutex>
#include <string>
#include <ctime>

#include "hik_camera_driver/stereo_pairer.hpp"
#include "hik_camera_interfaces/msg/frame_meta.hpp"
#include "hik_camera_interfaces/msg/sync_status.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_components/register_node_macro.hpp"
#include "std_srvs/srv/trigger.hpp"

// Humble（rclcpp 16）与 Jazzy（rclcpp 28）创建服务 / 客户端时 QoS 参数的类型不同
#if __has_include("rclcpp/version.h")
#include "rclcpp/version.h"
#endif
#ifdef RCLCPP_VERSION_GTE
#if RCLCPP_VERSION_GTE(28, 0, 0)
#define HIK_RCLCPP_QOS_OBJECT 1
#endif
#endif

namespace hik_camera_driver {

namespace {
int64_t monoNowNs() {
  timespec ts{};
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return int64_t(ts.tv_sec) * 1000000000LL + ts.tv_nsec;
}
}  // namespace

class StereoCoordinator : public rclcpp::Node {
  using Trigger = std_srvs::srv::Trigger;
  using FrameMeta = hik_camera_interfaces::msg::FrameMeta;
  using SyncStatus = hik_camera_interfaces::msg::SyncStatus;

 public:
  explicit StereoCoordinator(const rclcpp::NodeOptions& options) : rclcpp::Node("stereo", options) {
    left_ = declare_parameter<std::string>("left_node", "/stereo/left");
    right_ = declare_parameter<std::string>("right_node", "/stereo/right");
    const double fps = declare_parameter<double>("fps", 60.0);
    const double window_s = declare_parameter<double>("window_s", 10.0);
    status_period_s_ = declare_parameter<double>("status_period_s", 10.0);
    timeout_s_ = declare_parameter<double>("service_timeout_s", 5.0);
    pairer_ = std::make_unique<StereoPairer>(fps, window_s);

    srv_group_ = create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
    cli_group_ = create_callback_group(rclcpp::CallbackGroupType::Reentrant);
    sub_group_ = create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);

    for (int i = 0; i < 2; ++i) {
      const std::string& ns = i == 0 ? left_ : right_;
      start_cli_[i] = makeClient(ns + "/start");
      stop_cli_[i] = makeClient(ns + "/stop");
      status_cli_[i] = makeClient(ns + "/get_status");
    }

    makeService("~/start", [this](std::shared_ptr<Trigger::Response> res) {
      {
        std::lock_guard<std::mutex> lk(mtx_);
        pairer_->reset();
      }
      callBoth(start_cli_, "start", res);
    });
    makeService("~/stop", [this](std::shared_ptr<Trigger::Response> res) { callBoth(stop_cli_, "stop", res); });
    makeService("~/reset_stats", [this](std::shared_ptr<Trigger::Response> res) {
      std::lock_guard<std::mutex> lk(mtx_);
      pairer_->reset();
      res->success = true;
      res->message = "配对统计已清零";
    });
    makeService("~/get_status", [this](std::shared_ptr<Trigger::Response> res) {
      std::string s;
      {
        std::lock_guard<std::mutex> lk(mtx_);
        s = "== stereo ==\n" + pairer_->stats(monoNowNs()).summary();
      }
      for (int i = 0; i < 2; ++i) {
        std::string msg;
        bool ok = callOne(status_cli_[i], msg);
        s += "\n== " + std::string(i == 0 ? left_ : right_) + " ==\n" + (ok ? msg : "无法获取：" + msg);
      }
      res->success = true;
      res->message = s;
    });

    rclcpp::SubscriptionOptions so;
    so.callback_group = sub_group_;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(100)).reliable();
    sub_[0] = create_subscription<FrameMeta>(left_ + "/frame_meta", qos, [this](FrameMeta::ConstSharedPtr m) { onMeta(Side::kLeft, *m); }, so);
    sub_[1] = create_subscription<FrameMeta>(right_ + "/frame_meta", qos, [this](FrameMeta::ConstSharedPtr m) { onMeta(Side::kRight, *m); }, so);
    pub_ = create_publisher<SyncStatus>("~/sync_status", rclcpp::QoS(rclcpp::KeepLast(10)).reliable());

    timer_ = create_wall_timer(std::chrono::milliseconds(500), [this] { tick(); }, sub_group_);
    RCLCPP_INFO(get_logger(), "协调节点就绪：左 %s，右 %s；调用 %s/start 同时启动两台相机", left_.c_str(), right_.c_str(), get_fully_qualified_name());
  }

 private:
  rclcpp::Client<Trigger>::SharedPtr makeClient(const std::string& name) {
#ifdef HIK_RCLCPP_QOS_OBJECT  // Jazzy 及以后
    return create_client<Trigger>(name, rclcpp::ServicesQoS(), cli_group_);
#else                             // Humble
    return create_client<Trigger>(name, rmw_qos_profile_services_default, cli_group_);
#endif
  }

  template <class F>
  void makeService(const std::string& name, F handler) {
    auto cb = [handler](const std::shared_ptr<Trigger::Request>, std::shared_ptr<Trigger::Response> res) { handler(res); };
#ifdef HIK_RCLCPP_QOS_OBJECT
    services_.push_back(create_service<Trigger>(name, cb, rclcpp::ServicesQoS(), srv_group_));
#else
    services_.push_back(create_service<Trigger>(name, cb, rmw_qos_profile_services_default, srv_group_));
#endif
  }

  // 同时向左右相机发送请求，再分别等待结果
  void callBoth(rclcpp::Client<Trigger>::SharedPtr (&cli)[2], const char* what, std::shared_ptr<Trigger::Response> res) {
    using FutureT = rclcpp::Client<Trigger>::SharedFuture;
    FutureT fut[2];
    bool sent[2] = {false, false};
    std::string msg[2];
    for (int i = 0; i < 2; ++i) {
      if (!cli[i]->service_is_ready()) { msg[i] = "服务不可用（相机节点没有运行？）"; continue; }
      fut[i] = cli[i]->async_send_request(std::make_shared<Trigger::Request>()).future.share();
      sent[i] = true;
    }
    bool all_ok = true;
    const auto timeout = std::chrono::duration<double>(timeout_s_);
    for (int i = 0; i < 2; ++i) {
      if (sent[i]) {
        if (fut[i].wait_for(timeout) == std::future_status::ready) {
          auto r = fut[i].get();
          msg[i] = (r->success ? "成功：" : "失败：") + r->message;
          all_ok = all_ok && r->success;
        } else {
          msg[i] = "等待超时（协调节点是否运行在 component_container_mt 中？）";
          all_ok = false;
        }
      } else {
        all_ok = false;
      }
    }
    res->success = all_ok;
    res->message = std::string(what) + " 左[" + msg[0] + "] 右[" + msg[1] + "]";
    if (all_ok) RCLCPP_INFO(get_logger(), "%s", res->message.c_str());
    else RCLCPP_ERROR(get_logger(), "%s", res->message.c_str());
  }

  bool callOne(const rclcpp::Client<Trigger>::SharedPtr& cli, std::string& out) {
    if (!cli->service_is_ready()) { out = "服务不可用"; return false; }
    auto fut = cli->async_send_request(std::make_shared<Trigger::Request>()).future.share();
    if (fut.wait_for(std::chrono::duration<double>(timeout_s_)) != std::future_status::ready) { out = "等待超时"; return false; }
    out = fut.get()->message;
    return true;
  }

  void onMeta(Side side, const FrameMeta& m) {
    PairerFrame f;
    f.stamp_ns = m.stamp_mono_ns;  // 两台相机在同一进程，CLOCK_MONOTONIC 可以直接比较
    f.seq = m.seq;
    f.frame_num = m.frame_num;
    f.device_time = (m.time_source == FrameMeta::TIME_DEVICE);
    std::lock_guard<std::mutex> lk(mtx_);
    pairer_->add(side, f);
  }

  void tick() {
    const int64_t now = monoNowNs();
    PairerStats st;
    {
      std::lock_guard<std::mutex> lk(mtx_);
      pairer_->process(now - 300'000'000LL);  // 给另一路留 0.3 s 的到达时间
      st = pairer_->stats(now - 300'000'000LL);
    }
    if (++ticks_ % 2 == 0) {  // 每秒发布一次
      auto msg = std::make_unique<SyncStatus>();
      msg->header.stamp = now_ros();
      msg->period_ms = st.period_ms;
      msg->window_s = st.window_s;
      msg->window_pairs = st.window_pairs;
      msg->window_mean_ms = st.window_mean_ms;
      msg->window_p99_ms = st.window_p99_ms;
      msg->window_max_ms = st.window_max_ms;
      msg->left_fps = st.left_fps;
      msg->right_fps = st.right_fps;
      msg->total_pairs = st.total_pairs;
      msg->total_unpaired_left = st.unpaired[0];
      msg->total_unpaired_right = st.unpaired[1];
      msg->total_max_ms = st.total_max_ms;
      msg->left_frames = st.frames[0];
      msg->right_frames = st.frames[1];
      msg->left_frame_num_gaps = st.frame_num_gaps[0];
      msg->right_frame_num_gaps = st.frame_num_gaps[1];
      msg->left_meta_gaps = st.seq_gaps[0];
      msg->right_meta_gaps = st.seq_gaps[1];
      msg->left_not_device_time = st.not_device_time[0];
      msg->right_not_device_time = st.not_device_time[1];
      pub_->publish(std::move(msg));
    }
    const double elapsed = static_cast<double>(now - last_log_ns_) / 1e9;
    if (status_period_s_ > 0 && elapsed >= status_period_s_ && (st.frames[0] + st.frames[1]) > 0) {
      last_log_ns_ = now;
      RCLCPP_INFO(get_logger(), "%s", st.summary().c_str());
    }
  }

  rclcpp::Time now_ros() { return this->now(); }

  std::string left_, right_;
  double status_period_s_ = 10.0, timeout_s_ = 5.0;
  std::unique_ptr<StereoPairer> pairer_;
  std::mutex mtx_;
  uint64_t ticks_ = 0;
  int64_t last_log_ns_ = 0;

  rclcpp::CallbackGroup::SharedPtr srv_group_, cli_group_, sub_group_;
  rclcpp::Client<Trigger>::SharedPtr start_cli_[2], stop_cli_[2], status_cli_[2];
  std::vector<rclcpp::Service<Trigger>::SharedPtr> services_;
  rclcpp::Subscription<FrameMeta>::SharedPtr sub_[2];
  rclcpp::Publisher<SyncStatus>::SharedPtr pub_;
  rclcpp::TimerBase::SharedPtr timer_;
};

}  // namespace hik_camera_driver

RCLCPP_COMPONENTS_REGISTER_NODE(hik_camera_driver::StereoCoordinator)
