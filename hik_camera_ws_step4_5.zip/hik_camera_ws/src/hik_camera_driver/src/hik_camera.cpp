// hik_camera.cpp —— 见 hik_camera.hpp
//
// SDK 调用方式与 hik_probe 相同（已在真机上验证），依据 sdk_notes.md。

#include "hik_camera_driver/hik_camera.hpp"

#include <chrono>
#include <cstdio>
#include <cstring>
#include <ctime>

#include "MvCameraControl.h"

namespace hik_camera_driver {

namespace {

int64_t monoNs() {
  timespec ts{};
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return int64_t(ts.tv_sec) * 1000000000LL + ts.tv_nsec;
}

void __stdcall exceptionTrampoline(unsigned int msg_type, void* user) {
  if (user) static_cast<HikCamera*>(user)->handleSdkException(msg_type);
}

std::string fmtFloat(double v) {
  char b[64];
  std::snprintf(b, sizeof(b), "%.6f", v);
  return b;
}

}  // namespace

// ----------------------------------------------------------------------------
std::string errorString(int code) {
  switch (code) {
    case 0: return "0x00000000 成功";
    case kErrNotFound: return "没有找到匹配的相机";
    case kErrAmbiguous: return "有多台相机匹配，请同时指定序列号";
    case kErrBadState: return "当前状态下不能执行该操作";
    case kErrInvalidArg: return "参数不合法";
    case kErrSdkInit: return "SDK 初始化失败";
    default: break;
  }
  const char* m = "";
  switch (static_cast<unsigned int>(code)) {
    case 0x80000000u: m = "错误或无效的句柄"; break;
    case 0x80000001u: m = "不支持的功能"; break;
    case 0x80000003u: m = "函数调用顺序错误"; break;
    case 0x80000004u: m = "参数错误"; break;
    case 0x80000007u: m = "超时，没有数据"; break;
    case 0x80000020u: m = "设备已掉线"; break;
    case 0x80000102u: m = "值超出范围"; break;
    case 0x80000106u: m = "节点访问条件有误（取流中被锁定，或节点不可用）"; break;
    case 0x80000109u: m = "节点不存在"; break;
    case 0x80000203u: m = "设备无访问权限（可能被 MVS 等程序占用）"; break;
    case 0x80000302u: m = "USB 设备异常"; break;
    case 0x80000304u: m = "USB 带宽不足"; break;
    default: m = "（见 SDK 开发指南的状态码页）"; break;
  }
  return retHex(code) + " " + m;
}

const char* toString(TimeSource s) {
  switch (s) {
    case TimeSource::kDevice: return "device";
    case TimeSource::kDeviceProvisional: return "device_provisional";
    case TimeSource::kReceive: return "receive";
  }
  return "?";
}

std::string CameraSelector::describe() const {
  std::string s;
  if (!user_id.empty()) s += "user_id=" + user_id;
  if (!serial.empty()) s += std::string(s.empty() ? "" : " ") + "serial=" + serial;
  return s.empty() ? "(未指定)" : s;
}

// ----------------------------------------------------------------------------
HikCamera::HikCamera(HikCameraOptions opt) : opt_(opt), sdk_(SdkContext::instance()) {
  if (opt_.image_node_num < 1) opt_.image_node_num = 1;
  if (opt_.sync_period_s <= 0) opt_.sync_period_s = 1.0;
}

HikCamera::~HikCamera() { close(); }

void HikCamera::setError(const std::string& e) const {
  std::lock_guard<std::mutex> lk(err_mtx_);
  last_error_ = e;
}

std::string HikCamera::lastError() const {
  std::lock_guard<std::mutex> lk(err_mtx_);
  return last_error_;
}

bool HikCamera::isOpen() const {
  std::lock_guard<std::mutex> lk(ctl_);
  return h_ != nullptr;
}

int HikCamera::ensureOpenLocked() const { return h_ ? 0 : kErrBadState; }

// ---- 打开 / 关闭 -------------------------------------------------------------
int HikCamera::open(const CameraSelector& sel) {
  std::lock_guard<std::mutex> life(lifecycle_);
  {
    std::lock_guard<std::mutex> lk(ctl_);
    if (h_) { setError("相机已经打开"); return kErrBadState; }
  }
  if (!sdk_.ok()) { setError("SDK 不可用：" + errorString(sdk_.initResult())); return kErrSdkInit; }
  if (sel.user_id.empty() && sel.serial.empty()) { setError("必须指定 user_id 或 serial"); return kErrInvalidArg; }

  std::vector<DeviceDesc> devs;
  int r = sdk_.enumerate(devs);
  if (r != 0) { setError("枚举失败：" + errorString(r)); return r; }
  std::vector<const DeviceDesc*> hits;
  std::string listing;
  for (const auto& d : devs) {
    listing += "\n  - " + d.describe();
    bool ok = (sel.user_id.empty() || d.user_id == sel.user_id) && (sel.serial.empty() || d.serial == sel.serial);
    if (ok) hits.push_back(&d);
  }
  if (hits.empty()) {
    setError("没有找到 " + sel.describe() + "。当前枚举到 " + std::to_string(devs.size()) + " 台：" + listing);
    return kErrNotFound;
  }
  if (hits.size() > 1) {
    setError(sel.describe() + " 匹配到 " + std::to_string(hits.size()) + " 台，请同时指定序列号：" + listing);
    return kErrAmbiguous;
  }
  const DeviceDesc& d = *hits.front();
  const auto* info = static_cast<const MV_CC_DEVICE_INFO*>(d.raw.get());

  void* h = nullptr;
  r = MV_CC_CreateHandle(&h, info);
  if (r != MV_OK) { setError("CreateHandle 失败：" + errorString(r)); return r; }
  r = MV_CC_OpenDevice(h);
  if (r != MV_OK) {
    MV_CC_DestroyHandle(h);
    setError("OpenDevice 失败：" + errorString(r) + "（" + d.describe() + "）");
    return r;
  }
  {
    std::lock_guard<std::mutex> lk(ctl_);
    h_ = h;
    dev_ = d;
    disconnected_ = false;
    int re = MV_CC_RegisterExceptionCallBack(h_, exceptionTrampoline, this);
    if (re != MV_OK) setError("注册异常回调失败（不影响取流）：" + errorString(re));

    // 时间戳单位：真机 DeviceTimestampIncrement = 1e8（时钟频率）→ 10 ns/tick
    ClockSyncConfig cfg = opt_.clock;
    nominal_ns_per_tick_ = cfg.nominal_ns_per_tick;
    if (nominal_ns_per_tick_ <= 0) {
      MVCC_INTVALUE_EX iv{};
      if (MV_CC_GetIntValueEx(h_, "DeviceTimestampIncrement", &iv) == MV_OK) nominal_ns_per_tick_ = nsPerTickFromIncrement(iv.nCurValue);
      cfg.nominal_ns_per_tick = nominal_ns_per_tick_;
    }
    clock_ = std::make_unique<ClockSync>(cfg);
  }
  sdk_.registerHandle();
  {
    std::lock_guard<std::mutex> lk(stats_mtx_);
    stats_ = CameraStats{};
  }
  return 0;
}

void HikCamera::close() {
  std::lock_guard<std::mutex> life(lifecycle_);
  stopImpl();
  std::lock_guard<std::mutex> lk(ctl_);
  if (!h_) return;
  MV_CC_RegisterExceptionCallBack(h_, nullptr, nullptr);
  MV_CC_CloseDevice(h_);
  MV_CC_DestroyHandle(h_);
  h_ = nullptr;
  sdk_.unregisterHandle();
}

void HikCamera::handleSdkException(unsigned int msg_type) {
  // 文档要求不要在回调里做耗时操作：只记录，重连交给上层
  disconnected_ = true;
  setError("收到 SDK 异常 " + retHex(static_cast<int>(msg_type)) + (msg_type == MV_EXCEPTION_DEV_DISCONNECT ? "（设备断开连接）" : ""));
}

// ---- 参数 -------------------------------------------------------------------
int HikCamera::setInt(const std::string& name, int64_t v) {
  std::lock_guard<std::mutex> lk(ctl_);
  if (int e = ensureOpenLocked()) return e;
  return MV_CC_SetIntValueEx(h_, name.c_str(), v);
}

int HikCamera::setFloat(const std::string& name, double v) {
  std::lock_guard<std::mutex> lk(ctl_);
  if (int e = ensureOpenLocked()) return e;
  return MV_CC_SetFloatValue(h_, name.c_str(), static_cast<float>(v));
}

int HikCamera::setEnum(const std::string& name, const std::string& symbol) {
  std::lock_guard<std::mutex> lk(ctl_);
  if (int e = ensureOpenLocked()) return e;
  return MV_CC_SetEnumValueByString(h_, name.c_str(), symbol.c_str());
}

int HikCamera::setBool(const std::string& name, bool v) {
  std::lock_guard<std::mutex> lk(ctl_);
  if (int e = ensureOpenLocked()) return e;
  return MV_CC_SetBoolValue(h_, name.c_str(), v);
}

int HikCamera::setString(const std::string& name, const std::string& v) {
  std::lock_guard<std::mutex> lk(ctl_);
  if (int e = ensureOpenLocked()) return e;
  return MV_CC_SetStringValue(h_, name.c_str(), v.c_str());
}

int HikCamera::getIntInfo(const std::string& name, IntInfo& out) {
  std::lock_guard<std::mutex> lk(ctl_);
  if (int e = ensureOpenLocked()) return e;
  MVCC_INTVALUE_EX v{};
  int r = MV_CC_GetIntValueEx(h_, name.c_str(), &v);
  if (r == MV_OK) out = {v.nCurValue, v.nMin, v.nMax, v.nInc > 0 ? v.nInc : 1};
  return r;
}

int HikCamera::getFloatInfo(const std::string& name, FloatInfo& out) {
  std::lock_guard<std::mutex> lk(ctl_);
  if (int e = ensureOpenLocked()) return e;
  MVCC_FLOATVALUE v{};
  int r = MV_CC_GetFloatValue(h_, name.c_str(), &v);
  if (r == MV_OK) out = {v.fCurValue, v.fMin, v.fMax};
  return r;
}

int HikCamera::getEnumInfo(const std::string& name, EnumInfo& out) {
  std::lock_guard<std::mutex> lk(ctl_);
  if (int e = ensureOpenLocked()) return e;
  MVCC_ENUMVALUE_EX v;
  std::memset(&v, 0, sizeof(v));
  int r = MV_CC_GetEnumValueEx(h_, name.c_str(), &v);
  if (r != MV_OK) return r;
  out = EnumInfo{};
  out.cur_value = v.nCurValue;
  for (unsigned int k = 0; k < v.nSupportedNum && k < MV_MAX_ENUM_SYMBOLIC_NUM; ++k) {
    MVCC_ENUMENTRY e{};
    e.nValue = v.nSupportValue[k];
    std::string sym = (MV_CC_GetEnumEntrySymbolic(h_, name.c_str(), &e) == MV_OK) ? std::string(e.chSymbolic) : std::string("?");
    out.entries.emplace_back(sym, v.nSupportValue[k]);
    if (v.nSupportValue[k] == v.nCurValue) out.cur = sym;
  }
  if (out.cur.empty()) {
    MVCC_ENUMENTRY e{};
    e.nValue = v.nCurValue;
    if (MV_CC_GetEnumEntrySymbolic(h_, name.c_str(), &e) == MV_OK) out.cur = e.chSymbolic;
  }
  return MV_OK;
}

int HikCamera::getBool(const std::string& name, bool& out) {
  std::lock_guard<std::mutex> lk(ctl_);
  if (int e = ensureOpenLocked()) return e;
  return MV_CC_GetBoolValue(h_, name.c_str(), &out);
}

int HikCamera::getString(const std::string& name, std::string& out) {
  std::lock_guard<std::mutex> lk(ctl_);
  if (int e = ensureOpenLocked()) return e;
  MVCC_STRINGVALUE v;
  std::memset(&v, 0, sizeof(v));
  int r = MV_CC_GetStringValue(h_, name.c_str(), &v);
  if (r == MV_OK) out.assign(v.chCurValue, strnlen(v.chCurValue, sizeof(v.chCurValue)));
  return r;
}

int HikCamera::read(const std::string& name, ParamType type, std::string& out) {
  switch (type) {
    case ParamType::kInt: { IntInfo i; int r = getIntInfo(name, i); if (r == 0) out = std::to_string(i.cur); return r; }
    case ParamType::kFloat: { FloatInfo f; int r = getFloatInfo(name, f); if (r == 0) out = fmtFloat(f.cur); return r; }
    case ParamType::kEnum: { EnumInfo e; int r = getEnumInfo(name, e); if (r == 0) out = e.cur; return r; }
    case ParamType::kBool: { bool b = false; int r = getBool(name, b); if (r == 0) out = b ? "true" : "false"; return r; }
    case ParamType::kString: return getString(name, out);
  }
  return kErrInvalidArg;
}

// ---- 对时 -------------------------------------------------------------------
int HikCamera::syncOnce() {
  SyncSample s{};
  int r_cmd, r_read;
  MVCC_INTVALUE_EX v{};
  {
    std::lock_guard<std::mutex> lk(ctl_);
    if (int e = ensureOpenLocked()) return e;
    s.host_t0_ns = monoNs();
    r_cmd = MV_CC_SetCommandValue(h_, "DeviceTimestampLatch");  // 必须先 Latch，否则读到旧值（真机实测）
    r_read = (r_cmd == MV_OK) ? MV_CC_GetIntValueEx(h_, "DeviceTimestamp", &v) : r_cmd;
    s.host_t1_ns = monoNs();
  }
  std::lock_guard<std::mutex> lk(stats_mtx_);
  if (r_read != MV_OK) {
    stats_.sync_failed++;
    stats_.last_sync_error = r_read;
    return r_read;
  }
  s.dev_ticks = v.nCurValue;
  AddResult ar = clock_->addSample(s);
  if (ar == AddResult::kAccepted || ar == AddResult::kClockReset) stats_.sync_ok++;
  else stats_.sync_failed++;
  return 0;
}

ClockSyncState HikCamera::clockState() const {
  std::lock_guard<std::mutex> lk(ctl_);
  return clock_ ? clock_->state() : ClockSyncState{};
}

CameraStats HikCamera::stats() const {
  std::lock_guard<std::mutex> lk(stats_mtx_);
  return stats_;
}

// ---- 取流 -------------------------------------------------------------------
int HikCamera::start(FrameCallback cb) {
  std::lock_guard<std::mutex> life(lifecycle_);
  return startImpl(std::move(cb));
}

int HikCamera::stop() {
  std::lock_guard<std::mutex> life(lifecycle_);
  return stopImpl();
}

int HikCamera::startImpl(FrameCallback cb) {
  if (grabbing_) { setError("已经在取流"); return kErrBadState; }
  {
    std::lock_guard<std::mutex> lk(ctl_);
    if (int e = ensureOpenLocked()) { setError("相机未打开"); return e; }
    int r = MV_CC_SetImageNodeNum(h_, opt_.image_node_num);  // 默认只有 1 个缓存，必须在开流前调大
    if (r != MV_OK) { setError("SetImageNodeNum 失败：" + errorString(r)); return r; }
    r = MV_CC_SetGrabStrategy(h_, MV_GrabStrategy_OneByOne);  // 虚拟相机返回 0x80000021，只警告
    if (r != MV_OK) setError("SetGrabStrategy 失败（继续）：" + errorString(r));
  }
  // 开流前先连续对时几次，让第一帧就能换算时间（虚拟相机会全部失败，属正常）
  for (int i = 0; i < opt_.startup_sync_samples; ++i) {
    syncOnce();
    if (i + 1 < opt_.startup_sync_samples) std::this_thread::sleep_for(std::chrono::milliseconds(opt_.startup_sync_interval_ms));
  }
  {
    std::lock_guard<std::mutex> lk(ctl_);
    int r = MV_CC_StartGrabbing(h_);
    if (r != MV_OK) { setError("StartGrabbing 失败：" + errorString(r)); return r; }
  }
  cb_ = std::move(cb);
  seq_ = 0;
  have_last_fn_ = false;
  run_ = true;
  grabbing_ = true;
  grab_th_ = std::thread(&HikCamera::grabLoop, this);
  sync_th_ = std::thread(&HikCamera::syncLoop, this);
  return 0;
}

int HikCamera::stopImpl() {
  if (!grabbing_) return 0;
  run_ = false;
  {
    std::lock_guard<std::mutex> lk(sync_wait_mtx_);
  }
  sync_cv_.notify_all();
  if (grab_th_.joinable()) grab_th_.join();  // 先让取图线程退出（最长等待一次取图超时）
  if (sync_th_.joinable()) sync_th_.join();
  int r;
  {
    std::lock_guard<std::mutex> lk(ctl_);
    r = h_ ? MV_CC_StopGrabbing(h_) : 0;
  }
  grabbing_ = false;
  return r;
}

void HikCamera::syncLoop() {
  const auto period = std::chrono::nanoseconds(static_cast<int64_t>(opt_.sync_period_s * 1e9));
  auto next = std::chrono::steady_clock::now() + period;
  while (run_) {
    {
      std::unique_lock<std::mutex> lk(sync_wait_mtx_);
      sync_cv_.wait_until(lk, next, [this] { return !run_.load(); });
    }
    if (!run_) break;
    syncOnce();
    next += period;
    auto now = std::chrono::steady_clock::now();
    if (next < now) next = now + period;  // 落后太多时不追赶
  }
}

void HikCamera::grabLoop() {
  while (run_) {
    MV_FRAME_OUT fr;
    std::memset(&fr, 0, sizeof(fr));
    int r = MV_CC_GetImageBuffer(h_, &fr, opt_.grab_timeout_ms);
    const int64_t recv = monoNs();
    if (r != MV_OK) {
      std::lock_guard<std::mutex> lk(stats_mtx_);
      if (static_cast<unsigned int>(r) == MV_E_NODATA) stats_.grab_timeouts++;
      else { stats_.grab_errors++; stats_.last_grab_error = r; }
      if (static_cast<unsigned int>(r) != MV_E_NODATA) std::this_thread::sleep_for(std::chrono::milliseconds(10));  // 掉线时避免空转
      continue;
    }
    const MV_FRAME_OUT_INFO_EX& in = fr.stFrameInfo;
    Frame f;
    f.data = fr.pBufAddr;
    f.width = in.nExtendWidth ? in.nExtendWidth : in.nWidth;
    f.height = in.nExtendHeight ? in.nExtendHeight : in.nHeight;
    f.pixel_type = static_cast<uint32_t>(in.enPixelType);
    f.format = lookupPixelFormat(f.pixel_type);
    f.size = in.nFrameLen;
    f.frame_num = in.nFrameNum;
    f.dev_ticks = (static_cast<uint64_t>(in.nDevTimeStampHigh) << 32) | in.nDevTimeStampLow;
    f.lost_packet = in.nLostPacket;
    f.exposure_us = in.fExposureTime;
    f.gain_db = in.fGain;
    f.recv_mono_ns = recv;
    f.stamp_mono_ns = recv;
    f.time_source = TimeSource::kReceive;
    if (f.dev_ticks > 0) {
      if (auto h = clock_->toHost(static_cast<int64_t>(f.dev_ticks))) {
        f.stamp_mono_ns = *h;
        f.time_source = clock_->state().provisional ? TimeSource::kDeviceProvisional : TimeSource::kDevice;
      }
    }
    {
      std::lock_guard<std::mutex> lk(stats_mtx_);
      f.seq = seq_++;
      stats_.frames++;
      if (have_last_fn_ && f.frame_num != stats_.last_frame_num + 1) stats_.frame_num_gaps++;
      have_last_fn_ = true;
      stats_.last_frame_num = f.frame_num;
      if (f.lost_packet > 0) stats_.lost_packet_frames++;
      if (f.time_source == TimeSource::kReceive) stats_.receive_time_frames++;
      if (f.time_source == TimeSource::kDeviceProvisional) stats_.provisional_frames++;
    }
    if (cb_) {
      try {
        cb_(f);
      } catch (...) {
        std::lock_guard<std::mutex> lk(stats_mtx_);
        stats_.callback_exceptions++;
      }
    }
    MV_CC_FreeImageBuffer(h_, &fr);  // 只在取图成功后释放
  }
}

// ---- ROI --------------------------------------------------------------------
int HikCamera::getRoi(Roi& out) {
  IntInfo w, h, x, y;
  int r = getIntInfo("Width", w);
  if (r == 0) r = getIntInfo("Height", h);
  if (r == 0) r = getIntInfo("OffsetX", x);
  if (r == 0) r = getIntInfo("OffsetY", y);
  if (r == 0) out = {w.cur, h.cur, x.cur, y.cur};
  return r;
}

int HikCamera::setRoi(const Roi& roi, std::string* detail) {
  std::lock_guard<std::mutex> life(lifecycle_);
  auto say = [&](const std::string& s) { if (detail) *detail = s; setError(s); };

  IntInfo wmax, hmax, w, h, x, y;
  int r = getIntInfo("WidthMax", wmax);
  if (r == 0) r = getIntInfo("HeightMax", hmax);
  if (r == 0) r = getIntInfo("Width", w);
  if (r == 0) r = getIntInfo("Height", h);
  if (r == 0) r = getIntInfo("OffsetX", x);
  if (r == 0) r = getIntInfo("OffsetY", y);
  if (r != 0) { say("读取 ROI 相关节点失败：" + errorString(r)); return r; }

  auto aligned = [](int64_t v, const IntInfo& i) { return ((v - i.min) % i.inc) == 0; };
  std::string why;
  if (roi.width < w.min || roi.width > wmax.cur || !aligned(roi.width, w)) why += " 宽度应在 [" + std::to_string(w.min) + ", " + std::to_string(wmax.cur) + "] 且步进 " + std::to_string(w.inc) + "；";
  if (roi.height < h.min || roi.height > hmax.cur || !aligned(roi.height, h)) why += " 高度应在 [" + std::to_string(h.min) + ", " + std::to_string(hmax.cur) + "] 且步进 " + std::to_string(h.inc) + "；";
  if (roi.offset_x < 0 || roi.offset_x + roi.width > wmax.cur || (roi.offset_x % x.inc) != 0) why += " OffsetX 越界或不符合步进 " + std::to_string(x.inc) + "；";
  if (roi.offset_y < 0 || roi.offset_y + roi.height > hmax.cur || (roi.offset_y % y.inc) != 0) why += " OffsetY 越界或不符合步进 " + std::to_string(y.inc) + "；";
  if (!why.empty()) { say("ROI 不合法：" + why); return kErrInvalidArg; }

  const Roi old{w.cur, h.cur, x.cur, y.cur};
  const bool was_grabbing = grabbing_;
  FrameCallback cb = cb_;
  if (was_grabbing) stopImpl();  // 宽高在取流中被锁定（真机返回 0x80000106）

  auto apply = [&](const Roi& t) -> int {
    int e = setInt("OffsetX", 0);           // 先把偏移归零，避免“偏移 + 宽度”暂时越界
    if (e == 0) e = setInt("OffsetY", 0);
    if (e == 0) e = setInt("Width", t.width);
    if (e == 0) e = setInt("Height", t.height);
    if (e == 0) e = setInt("OffsetX", t.offset_x);
    if (e == 0) e = setInt("OffsetY", t.offset_y);
    return e;
  };
  r = apply(roi);
  if (r != 0) {
    int rr = apply(old);
    say("设置 ROI 失败：" + errorString(r) + (rr == 0 ? "，已恢复原 ROI" : "，恢复原 ROI 也失败：" + errorString(rr)));
  } else if (detail) {
    *detail = "ROI 已设置为 " + std::to_string(roi.width) + "x" + std::to_string(roi.height) + "+" + std::to_string(roi.offset_x) + "+" + std::to_string(roi.offset_y);
  }
  if (was_grabbing) {
    int rs = startImpl(cb);
    if (rs != 0 && r == 0) r = rs;
  }
  return r;
}

}  // namespace hik_camera_driver
