// stereo_pairer.cpp —— 见 stereo_pairer.hpp

#include "hik_camera_driver/stereo_pairer.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

namespace hik_camera_driver {

std::string PairerStats::summary() const {
  char b[512];
  std::snprintf(b, sizeof b,
                "配对(近%.0fs) %zu对 平均%.2fms p99 %.2fms 最大%.2fms | fps L%.2f R%.2f | 累计 配对%llu 未配对L%llu R%llu 最大%.2fms "
                "| 帧号跳变L%llu R%llu 消息丢失L%llu R%llu 非设备时间L%llu R%llu",
                window_s, window_pairs, window_mean_ms, window_p99_ms, window_max_ms, left_fps, right_fps,
                (unsigned long long)total_pairs, (unsigned long long)unpaired[0], (unsigned long long)unpaired[1], total_max_ms,
                (unsigned long long)frame_num_gaps[0], (unsigned long long)frame_num_gaps[1], (unsigned long long)seq_gaps[0],
                (unsigned long long)seq_gaps[1], (unsigned long long)not_device_time[0], (unsigned long long)not_device_time[1]);
  return b;
}

StereoPairer::StereoPairer(double fps, double window_s) : period_ns_(0), window_ns_(window_s * 1e9) {
  setFps(fps);
  totals_.window_s = window_s;
}

void StereoPairer::setFps(double fps) {
  if (fps <= 0) fps = 60.0;
  period_ns_ = 1e9 / fps;
  totals_.period_ms = period_ns_ / 1e6;
}

void StereoPairer::add(Side side, const PairerFrame& f) {
  const int i = static_cast<int>(side);
  SideState& s = side_[i];
  totals_.frames[i]++;
  if (!f.device_time) totals_.not_device_time[i]++;
  if (s.have_last) {
    if (f.seq == 0) {
      // 重新开流：序号归零，不算丢失
    } else if (f.seq != s.last.seq + 1) {
      totals_.seq_gaps[i]++;
    }
    if (f.seq != 0 && f.frame_num != s.last.frame_num + 1) totals_.frame_num_gaps[i]++;
  }
  s.have_last = true;
  s.last = f;
  // 保持时间顺序（正常情况下本来就是递增的）
  if (!s.queue.empty() && f.stamp_ns < s.queue.back().stamp_ns) {
    auto it = std::upper_bound(s.queue.begin(), s.queue.end(), f.stamp_ns,
                               [](int64_t t, const PairerFrame& x) { return t < x.stamp_ns; });
    s.queue.insert(it, f);
  } else {
    s.queue.push_back(f);
  }
  s.recent.push_back(f.stamp_ns);
}

void StereoPairer::process(int64_t cutoff_ns) {
  const double half = period_ns_ / 2.0;
  auto& L = side_[0].queue;
  auto& R = side_[1].queue;
  while (!L.empty() && !R.empty() && L.front().stamp_ns < cutoff_ns && R.front().stamp_ns < cutoff_ns) {
    const double dt = static_cast<double>(R.front().stamp_ns - L.front().stamp_ns);
    if (std::fabs(dt) <= half) {
      const double ms = std::fabs(dt) / 1e6;
      diffs_.push_back({std::max(L.front().stamp_ns, R.front().stamp_ns), ms});
      totals_.total_pairs++;
      totals_.total_max_ms = std::max(totals_.total_max_ms, ms);
      L.pop_front();
      R.pop_front();
    } else if (dt > 0) {
      totals_.unpaired[0]++;  // 左帧更早，且右边没有与它足够接近的帧
      L.pop_front();
    } else {
      totals_.unpaired[1]++;
      R.pop_front();
    }
  }
  // 一路已经停了很久（另一路还在出图）：截止时刻之前的帧都不可能再配对
  const int64_t stale = cutoff_ns - static_cast<int64_t>(period_ns_);
  for (int i = 0; i < 2; ++i) {
    auto& q = side_[i].queue;
    auto& other = side_[1 - i].queue;
    while (!q.empty() && other.empty() && q.front().stamp_ns < stale) {
      totals_.unpaired[i]++;
      q.pop_front();
    }
  }
  trim(cutoff_ns);
}

void StereoPairer::trim(int64_t now_ns) {
  const int64_t from = now_ns - static_cast<int64_t>(window_ns_);
  while (!diffs_.empty() && diffs_.front().t < from) diffs_.pop_front();
  for (auto& s : side_)
    while (!s.recent.empty() && s.recent.front() < from) s.recent.pop_front();
}

PairerStats StereoPairer::stats(int64_t now_ns) const {
  PairerStats st = totals_;
  const int64_t from = now_ns - static_cast<int64_t>(window_ns_);
  std::vector<double> v;
  for (const auto& d : diffs_)
    if (d.t >= from) v.push_back(d.ms);
  st.window_pairs = v.size();
  if (!v.empty()) {
    double sum = 0;
    for (double x : v) sum += x;
    st.window_mean_ms = sum / v.size();
    std::sort(v.begin(), v.end());
    st.window_max_ms = v.back();
    st.window_p99_ms = v[static_cast<std::size_t>(std::floor((v.size() - 1) * 0.99))];
  }
  for (int i = 0; i < 2; ++i) {
    std::size_t n = 0;
    int64_t first = 0, last = 0;
    for (int64_t t : side_[i].recent) {
      if (t < from) continue;
      if (n == 0) first = t;
      last = t;
      n++;
    }
    double fps = (n >= 2 && last > first) ? (n - 1) * 1e9 / static_cast<double>(last - first) : 0.0;
    (i == 0 ? st.left_fps : st.right_fps) = fps;
  }
  return st;
}

void StereoPairer::reset() {
  const double period = period_ns_;
  side_[0] = SideState{};
  side_[1] = SideState{};
  diffs_.clear();
  totals_ = PairerStats{};
  period_ns_ = period;
  totals_.period_ms = period_ns_ / 1e6;
  totals_.window_s = window_ns_ / 1e9;
}

}  // namespace hik_camera_driver
