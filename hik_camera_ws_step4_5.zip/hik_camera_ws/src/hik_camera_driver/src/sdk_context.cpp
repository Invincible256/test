// sdk_context.cpp —— 见 sdk_context.hpp

#include "hik_camera_driver/sdk_context.hpp"

#include <cstring>

#include "MvCameraControl.h"

namespace hik_camera_driver {

namespace {
// 设备信息里的字符串是 64 字节定长数组，不保证以 '\0' 结尾
std::string fixedStr(const unsigned char* p, std::size_t n) {
  std::size_t len = strnlen(reinterpret_cast<const char*>(p), n);
  return std::string(reinterpret_cast<const char*>(p), len);
}
}  // namespace

std::string DeviceDesc::describe() const {
  return model + " serial=" + serial + " user_id=" + (user_id.empty() ? "(空)" : user_id) + (is_virtual ? " (虚拟)" : "");
}

SdkContext& SdkContext::instance() {
  static SdkContext ctx;  // C++11 起，函数内静态变量的初始化是线程安全的，只执行一次
  return ctx;
}

SdkContext::SdkContext() { init_ret_ = MV_CC_Initialize(); }

SdkContext::~SdkContext() {
  std::lock_guard<std::mutex> lk(mtx_);
  if (init_ret_ == 0 && !finalized_ && open_handles_ == 0) {
    MV_CC_Finalize();
    finalized_ = true;
  }
}

uint32_t SdkContext::sdkVersion() const { return MV_CC_GetSDKVersion(); }

int SdkContext::enumerate(std::vector<DeviceDesc>& out) {
  out.clear();
  if (!ok()) return init_ret_ != 0 ? init_ret_ : -3;
  std::lock_guard<std::mutex> lk(enum_mtx_);
  MV_CC_DEVICE_INFO_LIST list;
  std::memset(&list, 0, sizeof(list));
  int r = MV_CC_EnumDevices(MV_USB_DEVICE, &list);  // MV_USB_DEVICE 同时覆盖真机和虚拟 USB 相机（实测）
  if (r != MV_OK) return r;
  for (unsigned int i = 0; i < list.nDeviceNum && i < MV_MAX_DEVICE_NUM; ++i) {
    if (!list.pDeviceInfo[i]) continue;
    auto copy = std::make_shared<MV_CC_DEVICE_INFO>(*list.pDeviceInfo[i]);  // 立即按值拷贝
    const MV_USB3_DEVICE_INFO& u = copy->SpecialInfo.stUsb3VInfo;
    DeviceDesc d;
    d.model = fixedStr(u.chModelName, sizeof(u.chModelName));
    d.serial = fixedStr(u.chSerialNumber, sizeof(u.chSerialNumber));
    d.user_id = fixedStr(u.chUserDefinedName, sizeof(u.chUserDefinedName));
    d.vendor = fixedStr(u.chVendorName, sizeof(u.chVendorName));
    d.device_version = fixedStr(u.chDeviceVersion, sizeof(u.chDeviceVersion));
    d.tlayer_type = copy->nTLayerType;
    d.is_virtual = d.serial.rfind("Vir", 0) == 0;
    d.raw = copy;
    out.push_back(std::move(d));
  }
  return MV_OK;
}

void SdkContext::registerHandle() {
  std::lock_guard<std::mutex> lk(mtx_);
  open_handles_++;
}

void SdkContext::unregisterHandle() {
  std::lock_guard<std::mutex> lk(mtx_);
  if (open_handles_ > 0) open_handles_--;
}

int SdkContext::openHandles() const {
  std::lock_guard<std::mutex> lk(mtx_);
  return open_handles_;
}

int SdkContext::finalize() {
  std::lock_guard<std::mutex> lk(mtx_);
  if (finalized_ || init_ret_ != 0) return 0;
  if (open_handles_ > 0) return -3;
  int r = MV_CC_Finalize();
  finalized_ = true;
  return r;
}

}  // namespace hik_camera_driver
