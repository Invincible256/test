// test_pixel_format.cpp —— 像素格式映射测试（数值来自 sdk_notes.md 附录 D5 与 hik_probe 实测）
#include "hik_camera_driver/pixel_format.hpp"
#include "test_util.hpp"

using namespace hik_camera_driver;

TEST(real_camera_bayer_gb8) {
  auto f = lookupPixelFormat(0x0108000Au);  // 真机 MV-CB013-A0UC-S 实测
  CHECK(f.has_value());
  CHECK(std::string(f->ros_encoding) == "bayer_gbrg8");
  CHECK(f->is_bayer);
  CHECK(frameBytes(*f, 1280, 1024) == 1310720u);  // 与实测帧长度一致
  CHECK(rowBytes(*f, 1280) == 1280u);
}

TEST(virtual_camera_rgb8) {
  auto f = lookupPixelFormat(0x02180014u);  // 虚拟 MV-CS016-10UC 实测
  CHECK(f.has_value());
  CHECK(std::string(f->ros_encoding) == "rgb8");
  CHECK(f->channels == 3);
  CHECK(frameBytes(*f, 1440, 1080) == 1440u * 1080u * 3u);
}

TEST(all_bayer_patterns) {
  CHECK(std::string(lookupPixelFormat(0x01080008u)->ros_encoding) == "bayer_grbg8");
  CHECK(std::string(lookupPixelFormat(0x01080009u)->ros_encoding) == "bayer_rggb8");
  CHECK(std::string(lookupPixelFormat(0x0108000Bu)->ros_encoding) == "bayer_bggr8");
  CHECK(std::string(lookupPixelFormat(0x01080001u)->ros_encoding) == "mono8");
}

TEST(unknown_format_rejected) {
  CHECK(!lookupPixelFormat(0x01100003u).has_value());  // Mono10 等未收录格式
  CHECK(!lookupPixelFormat(0).has_value());
}

TEST(lookup_by_name) {
  CHECK(lookupPixelFormatByName("BayerGB8")->sdk_value == 0x0108000Au);
  CHECK(lookupPixelFormatByName("RGB8Packed")->sdk_value == 0x02180014u);
  CHECK(!lookupPixelFormatByName("YUV422_8").has_value());
  CHECK(pixelFormatHex(0x0108000Au) == "0x0108000A");
}
