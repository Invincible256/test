// test_clock_sync.cpp —— ClockSync 单元测试
//
// 用一个模拟器生成对时样本，参数取自真机实测（hik_probe，2026-11-10）：
//   1 tick = 10 ns，相机比主机慢约 5.2 ppm，对时往返时间最小约 350 µs、偶尔到 1.5 ms

#include <atomic>
#include <random>
#include <thread>

#include "hik_camera_driver/clock_sync.hpp"
#include "test_util.hpp"

using namespace hik_camera_driver;

namespace {

// 模拟“真实”的两个时钟：主机时间 = kHost0 + true_ns_per_tick × tick
struct Sim {
  int64_t host0 = 1'700'000'000'000'000'000LL;   // 主机时钟起点（任意大数，检验大数精度）
  double true_ns_per_tick = 10.0 * (1.0 + 5.2e-6);
  int64_t tick0 = 38'598'202'717LL;               // 相机已运行约 386 s
  std::mt19937_64 rng{12345};

  int64_t ticksAt(int64_t host) const { return tick0 + static_cast<int64_t>((host - host0) / true_ns_per_tick); }
  int64_t hostAt(int64_t ticks) const { return host0 + static_cast<int64_t>((ticks - tick0) * true_ns_per_tick); }

  // 在主机时间 host 附近做一次对时：往返时间随机，去程/回程略不对称
  SyncSample sample(int64_t host) {
    std::exponential_distribution<double> extra(1.0 / 60e3);  // 平均多 60 µs
    std::uniform_real_distribution<double> u(0, 1);
    double rtt = 350e3 + extra(rng);
    if (u(rng) < 0.05) rtt += 1.0e6;                // 5% 的样本出现约 1 ms 的额外延迟
    double split = 0.45 + 0.1 * u(rng);             // 去程占往返的 45%–55%
    SyncSample s;
    s.host_t0_ns = host;
    int64_t latch_host = host + static_cast<int64_t>(rtt * split);
    s.dev_ticks = ticksAt(latch_host);
    s.host_t1_ns = host + static_cast<int64_t>(rtt);
    return s;
  }
};

ClockSyncConfig realCfg() {
  ClockSyncConfig c;
  c.nominal_ns_per_tick = nsPerTickFromIncrement(100'000'000);  // 真机 Increment
  return c;
}

}  // namespace

TEST(increment_is_frequency) {
  CHECK_NEAR(nsPerTickFromIncrement(100'000'000), 10.0, 1e-12);
  CHECK(nsPerTickFromIncrement(0) == 0.0);
  CHECK(nsPerTickFromIncrement(-5) == 0.0);
  CHECK(nsPerTickFromIncrement(1) == 0.0);  // 虚拟相机描述文件的含义（ns/tick），不当作频率
}

TEST(not_ready_without_samples) {
  ClockSync cs(realCfg());
  CHECK(!cs.toHost(123).has_value());
  CHECK(!cs.state().ready);
}

TEST(provisional_after_first_sample_when_nominal_known) {
  Sim sim;
  ClockSync cs(realCfg());
  CHECK(cs.addSample(sim.sample(sim.host0)) == AddResult::kAccepted);
  auto st = cs.state();
  CHECK(st.ready);
  CHECK(st.provisional);
  // 1 秒后的帧：名义斜率误差 5.2 ppm × 1 s ≈ 5 µs，加上单个样本的误差，应在 100 µs 内
  int64_t host = sim.host0 + 1'000'000'000LL;
  auto h = cs.toHost(sim.ticksAt(host));
  CHECK(h.has_value());
  CHECK_NEAR(double(*h - host), 0.0, 100e3);
}

TEST(no_model_when_nominal_unknown_and_few_samples) {
  Sim sim;
  ClockSync cs;  // 名义值未知
  for (int i = 0; i < 3; ++i) cs.addSample(sim.sample(sim.host0 + i * 1'000'000'000LL));
  CHECK(!cs.state().ready);
}

TEST(fit_accuracy_like_real_camera) {
  Sim sim;
  ClockSync cs(realCfg());
  for (int i = 0; i < 60; ++i) cs.addSample(sim.sample(sim.host0 + i * 1'000'000'000LL));  // 1 Hz，60 s
  auto st = cs.state();
  CHECK(st.ready);
  CHECK(!st.provisional);
  CHECK_NEAR(st.ns_per_tick, sim.true_ns_per_tick, sim.true_ns_per_tick * 2e-6);  // 斜率误差 < 2 ppm
  CHECK_NEAR(st.rate_error_ppm, 5.2, 2.0);
  CHECK(st.fit_rtt_threshold_ns < 1'000'000);  // 慢样本被排除
  // 窗口内 60 Hz 的每一帧，换算误差都应 < 50 µs
  double worst = 0;
  for (int k = 0; k < 30 * 60; ++k) {
    int64_t host = sim.host0 + 30'000'000'000LL + k * 16'666'667LL;
    if (host > sim.host0 + 59'000'000'000LL) break;
    worst = std::max(worst, std::fabs(double(*cs.toHost(sim.ticksAt(host)) - host)));
  }
  CHECK(worst < 50e3);
  std::printf("    最大换算误差 %.1f µs；%s\n", worst / 1e3, st.summary().c_str());
}

TEST(rejects_long_rtt_and_invalid) {
  Sim sim;
  ClockSync cs(realCfg());
  SyncSample bad = sim.sample(sim.host0);
  bad.host_t1_ns = bad.host_t0_ns + 6'000'000;  // 6 ms
  CHECK(cs.addSample(bad) == AddResult::kRejectedRtt);
  SyncSample zero{sim.host0, sim.host0 + 400'000, 0};  // 虚拟相机：tick 为 0
  CHECK(cs.addSample(zero) == AddResult::kRejectedInvalid);
  SyncSample backwards{sim.host0 + 10, sim.host0, 5};  // t1 < t0
  CHECK(cs.addSample(backwards) == AddResult::kRejectedInvalid);
  auto st = cs.state();
  CHECK(!st.ready);
  CHECK(st.total_rejected_rtt == 1);
  CHECK(st.total_rejected_invalid == 2);
}

TEST(detects_clock_reset_and_recovers) {
  Sim sim;
  ClockSync cs(realCfg());
  for (int i = 0; i < 10; ++i) cs.addSample(sim.sample(sim.host0 + i * 1'000'000'000LL));
  CHECK(!cs.state().provisional);
  // 相机重启：tick 从很小的值重新开始
  Sim after = sim;
  after.host0 = sim.host0 + 20'000'000'000LL;
  after.tick0 = 100'000;
  CHECK(cs.addSample(after.sample(after.host0)) == AddResult::kClockReset);
  auto st = cs.state();
  CHECK(st.total_resets == 1);
  CHECK(st.window_samples == 1);
  CHECK(st.provisional);
  for (int i = 1; i < 10; ++i) cs.addSample(after.sample(after.host0 + i * 1'000'000'000LL));
  int64_t host = after.host0 + 5'000'000'000LL;
  CHECK_NEAR(double(*cs.toHost(after.ticksAt(host)) - host), 0.0, 50e3);
  CHECK(!cs.state().provisional);
}

TEST(window_tracks_rate_change) {
  // 快慢差从 +5 ppm 变成 +15 ppm（例如温度变化），滑动窗口应跟上新的斜率
  Sim sim;
  ClockSyncConfig cfg = realCfg();
  cfg.window_ns = 20'000'000'000LL;
  ClockSync cs(cfg);
  for (int i = 0; i < 40; ++i) cs.addSample(sim.sample(sim.host0 + i * 1'000'000'000LL));
  Sim s2 = sim;
  s2.host0 = sim.host0 + 40'000'000'000LL;
  s2.tick0 = sim.ticksAt(s2.host0);
  s2.true_ns_per_tick = 10.0 * (1.0 + 15e-6);
  for (int i = 0; i < 40; ++i) cs.addSample(s2.sample(s2.host0 + i * 1'000'000'000LL));
  CHECK_NEAR(cs.state().rate_error_ppm, 15.0, 2.0);
  CHECK(cs.state().window_samples <= 21);
}

TEST(rejects_absurd_slope) {
  // 名义值写错（例如误把 Increment 当成“每 tick 纳秒数”）时，不能采用离谱的拟合结果
  Sim sim;
  ClockSyncConfig cfg;
  cfg.nominal_ns_per_tick = 1.0;  // 错误的名义值（真实是 10）
  ClockSync cs(cfg);
  for (int i = 0; i < 20; ++i) cs.addSample(sim.sample(sim.host0 + i * 1'000'000'000LL));
  auto st = cs.state();
  CHECK(st.provisional);  // 拟合斜率 ≈10，与名义值差 900%，被拒绝
}

TEST(thread_safety_smoke) {
  Sim sim;
  ClockSync cs(realCfg());
  cs.addSample(sim.sample(sim.host0));
  std::atomic<bool> stop{false};
  std::atomic<long> conversions{0};
  std::thread reader([&] {
    while (!stop) { if (cs.toHost(sim.tick0 + 1000).has_value()) conversions++; }
  });
  while (conversions == 0) std::this_thread::yield();  // 等读线程真正开始
  for (int i = 1; i < 200; ++i) cs.addSample(sim.sample(sim.host0 + i * 100'000'000LL));
  stop = true;
  reader.join();
  CHECK(conversions > 0);
  CHECK(cs.state().total_accepted >= 190);
}
