// test_hik_camera.cpp —— SdkContext / HikCamera 单元测试（链接假 SDK，不需要相机）
//
// 注意：这些测试只能验证“驱动逻辑”是否正确；真实 SDK 的行为要用 hik_camera_check 在真机上验证。

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <vector>

#include "fake_mvs_control.hpp"
#include "hik_camera_driver/hik_camera.hpp"
#include "test_util.hpp"

using namespace hik_camera_driver;
using namespace std::chrono_literals;

namespace {

fake_mvs::DeviceSpec spec(const std::string& serial, const std::string& uid) {
  fake_mvs::DeviceSpec s;
  s.serial = serial;
  s.user_id = uid;
  return s;
}

void twoRealCameras(int64_t right_phase_ns = 0) {
  fake_mvs::reset();
  fake_mvs::addDevice(spec("DA0000001", "left"));
  auto r = spec("DA0000002", "right");
  r.clock_ppm = 4.9;
  r.uptime_s = 220;
  r.phase_ns = right_phase_ns;
  fake_mvs::addDevice(r);
}

HikCameraOptions fastOpts() {
  HikCameraOptions o;
  o.sync_period_s = 0.2;  // 测试时缩短对时间隔
  o.startup_sync_samples = 5;
  o.startup_sync_interval_ms = 20;
  return o;
}

struct Collector {
  std::mutex m;
  std::vector<Frame> frames;  // 只保存元数据（data 指针在回调后失效，不使用）
  FrameCallback cb() {
    return [this](const Frame& f) { std::lock_guard<std::mutex> lk(m); frames.push_back(f); };
  }
  std::vector<Frame> get() { std::lock_guard<std::mutex> lk(m); return frames; }
};

double median(std::vector<double> v) {
  if (v.empty()) return NAN;
  std::sort(v.begin(), v.end());
  return v[v.size() / 2];
}
double stdev(const std::vector<double>& v) {
  double m = 0;
  for (double x : v) m += x;
  m /= v.size();
  double s = 0;
  for (double x : v) s += (x - m) * (x - m);
  return std::sqrt(s / v.size());
}

}  // namespace

TEST(sdk_initialized_once_per_process) {
  twoRealCameras();
  {
    HikCamera a(fastOpts()), b(fastOpts());
    CHECK(a.open({"left", ""}) == 0);
    CHECK(b.open({"right", ""}) == 0);
    CHECK(SdkContext::instance().openHandles() == 2);
    CHECK(SdkContext::instance().finalize() == kErrBadState);  // 还有打开的相机，拒绝
  }
  CHECK(fake_mvs::counters().initialize_calls == 1);
  CHECK(SdkContext::instance().openHandles() == 0);
}

TEST(enumeration_results_are_copies) {
  twoRealCameras();
  std::vector<DeviceDesc> a, b;
  CHECK(SdkContext::instance().enumerate(a) == 0);
  fake_mvs::reset();
  fake_mvs::addDevice(spec("ZZ0000009", "other"));
  CHECK(SdkContext::instance().enumerate(b) == 0);  // 假 SDK 会覆盖内部内存
  CHECK(a.size() == 2 && a[0].serial == "DA0000001" && a[1].user_id == "right");
  CHECK(b.size() == 1 && b[0].serial == "ZZ0000009");
}

TEST(open_by_user_id_serial_and_errors) {
  twoRealCameras();
  HikCamera c(fastOpts());
  CHECK(c.open({"", ""}) == kErrInvalidArg);
  CHECK(c.open({"nobody", ""}) == kErrNotFound);
  CHECK(c.lastError().find("DA0000001") != std::string::npos);  // 错误信息列出了可用设备
  CHECK(c.open({"left", "DA0000002"}) == kErrNotFound);          // 两项都填时都要匹配
  CHECK(c.open({"", "DA0000002"}) == 0);
  CHECK(c.device().user_id == "right");
  CHECK(c.open({"left", ""}) == kErrBadState);                   // 已经打开
  CHECK_NEAR(c.nominalNsPerTick(), 10.0, 1e-9);                   // 由 Increment = 1e8 推算
  c.close();
  CHECK(!c.isOpen());

  fake_mvs::reset();
  fake_mvs::addDevice(spec("DA0000001", "left"));
  fake_mvs::addDevice(spec("DA0000003", "left"));  // User ID 重名
  CHECK(c.open({"left", ""}) == kErrAmbiguous);
  CHECK(c.open({"left", "DA0000003"}) == 0);
  c.close();

  fake_mvs::reset();
  auto busy = spec("DA0000001", "left");
  busy.busy = true;
  fake_mvs::addDevice(busy);
  CHECK(c.open({"left", ""}) == static_cast<int>(0x80000203u));  // 被 MVS 占用
  CHECK(c.lastError().find("0x80000203") != std::string::npos);
}

TEST(param_table_through_node_access) {
  twoRealCameras();
  HikCamera c(fastOpts());
  CHECK(c.open({"left", ""}) == 0);
  auto p = parseParamSpecs({"AcquisitionMode:enum:Continuous", "TriggerSelector:enum:FrameBurstStart", "TriggerMode:enum:Off",
                            "ExposureAuto:enum:Off", "ExposureTime:float:5000", "GainAuto:enum:Off", "Gain:float:0",
                            "AcquisitionFrameRateEnable:bool:true", "AcquisitionFrameRate:float:60", "PixelFormat:enum:BayerGB8",
                            "GammaEnable:bool:false:optional", "SharpnessEnable:bool:false:optional", "DeviceUserID:string:left"});
  CHECK(p.ok());
  auto rep = applyParams(p.entries, c);
  for (auto& l : rep.lines()) if (l.rfind("OK", 0) != 0) std::printf("    %s\n", l.c_str());
  CHECK(rep.allRequiredOk());
  CHECK(rep.countOf(ApplyStatus::kFailedOptional) == 1);  // 假相机没有 SharpnessEnable
  IntInfo w;
  CHECK(c.getIntInfo("Width", w) == 0 && w.cur == 1280 && w.inc == 8);
  EnumInfo e;
  CHECK(c.getEnumInfo("PixelFormat", e) == 0 && e.cur == "BayerGB8" && e.entries.size() == 3);
}

TEST(free_run_frames_have_device_timestamps) {
  twoRealCameras();
  HikCamera c(fastOpts());
  CHECK(c.open({"left", ""}) == 0);
  CHECK(c.setFloat("AcquisitionFrameRate", 100) == 0);
  Collector col;
  CHECK(c.start(col.cb()) == 0);
  CHECK(c.isGrabbing());
  CHECK(fake_mvs::counters().last_node_num == 30);   // 开流前调大了缓存
  CHECK(c.setInt("Width", 640) == static_cast<int>(0x80000106u));  // 取流中宽度被锁定
  CHECK(c.setFloat("ExposureTime", 3000) == 0);      // 曝光可以改
  std::this_thread::sleep_for(1200ms);
  CHECK(c.stop() == 0);
  auto fr = col.get();
  auto st = c.stats();
  CHECK(fr.size() >= 100);
  CHECK(st.frame_num_gaps == 0);
  CHECK(st.receive_time_frames == 0);
  CHECK(st.sync_ok >= 5);
  CHECK(fr.front().format.has_value() && std::string(fr.front().format->ros_encoding) == "bayer_gbrg8");
  CHECK(fr.front().size == 1280u * 1024u);
  // 接收时刻 − 换算时间 ≈ 假相机的传输延迟 2 ms，而且很稳定
  std::vector<double> lat;
  for (auto& f : fr) lat.push_back((f.recv_mono_ns - f.stamp_mono_ns) / 1e6);
  std::printf("    帧 %zu；接收-帧时间 中位 %.3f ms，std %.3f ms；%s\n", fr.size(), median(lat), stdev(lat),
              c.clockState().summary().c_str());
  CHECK_NEAR(median(lat), 2.0, 0.6);
  CHECK(stdev(lat) < 0.5);
  // 序号连续
  for (size_t i = 0; i < fr.size(); ++i) CHECK(fr[i].seq == i);
}

TEST(two_cameras_pair_by_converted_time) {
  twoRealCameras(3'000'000);  // 右相机相位晚 3 ms
  HikCamera L(fastOpts()), R(fastOpts());
  CHECK(L.open({"left", ""}) == 0);
  CHECK(R.open({"right", ""}) == 0);
  CHECK(L.setFloat("AcquisitionFrameRate", 100) == 0);
  CHECK(R.setFloat("AcquisitionFrameRate", 100) == 0);
  Collector cl, cr;
  std::thread tl([&] { CHECK(L.start(cl.cb()) == 0); });  // 两台同时启动（启动前对时约 0.1 s）
  std::thread tr([&] { CHECK(R.start(cr.cb()) == 0); });
  tl.join();
  tr.join();
  std::this_thread::sleep_for(1500ms);
  L.stop();
  R.stop();
  auto a = cl.get(), b = cr.get();
  CHECK(a.size() > 100 && b.size() > 100);
  std::vector<int64_t> tb;
  for (auto& f : b) tb.push_back(f.stamp_mono_ns);
  std::vector<double> d;
  for (auto& f : a) {
    auto it = std::lower_bound(tb.begin(), tb.end(), f.stamp_mono_ns);
    double best = 1e18;
    if (it != tb.end()) best = std::min(best, std::fabs(double(*it - f.stamp_mono_ns)));
    if (it != tb.begin()) best = std::min(best, std::fabs(double(*(it - 1) - f.stamp_mono_ns)));
    if (best / 1e6 <= 5.0) d.push_back(best / 1e6);  // 100 Hz：半周期 5 ms
  }
  std::printf("    配对 %zu 对，时间差中位 %.3f ms，std %.3f ms\n", d.size(), median(d), stdev(d));
  CHECK(d.size() > 90);
  CHECK(stdev(d) < 0.3);  // 相位差稳定（取决于两台相机的启动先后，具体数值不固定）
}

TEST(roi_change_while_grabbing_restarts_stream) {
  twoRealCameras();
  HikCamera c(fastOpts());
  CHECK(c.open({"left", ""}) == 0);
  CHECK(c.setFloat("AcquisitionFrameRate", 100) == 0);
  Collector col;
  CHECK(c.start(col.cb()) == 0);
  std::this_thread::sleep_for(300ms);
  std::string detail;
  CHECK(c.setRoi({641, 480, 0, 0}, &detail) == kErrInvalidArg);  // 不符合步进 8
  CHECK(detail.find("步进") != std::string::npos);
  CHECK(c.isGrabbing());                                           // 参数不合法时不停流
  CHECK(c.setRoi({640, 480, 320, 272}, &detail) == 0);
  CHECK(c.isGrabbing());                                           // 自动重新开流
  std::this_thread::sleep_for(300ms);
  c.stop();
  HikCamera::Roi roi;
  CHECK(c.getRoi(roi) == 0 && roi.width == 640 && roi.height == 480 && roi.offset_x == 320 && roi.offset_y == 272);
  auto fr = col.get();
  CHECK(!fr.empty() && fr.back().width == 640 && fr.back().height == 480 && fr.back().size == 640u * 480u);
  CHECK(fake_mvs::counters().start_calls >= 2);
  CHECK(c.setRoi({1280, 1024, 8, 0}, &detail) == kErrInvalidArg);  // 偏移 + 宽度越界
}

TEST(virtual_camera_falls_back_to_receive_time) {
  fake_mvs::reset();
  auto v = spec("Vir12345678", "left");
  v.virtual_camera = true;
  v.pixel_format = 0x02180014u;  // 虚拟相机默认 RGB8
  v.width_max = 1440;
  v.height_max = 1080;
  fake_mvs::addDevice(v);
  HikCamera c(fastOpts());
  CHECK(c.open({"left", ""}) == 0);
  CHECK(c.device().is_virtual);
  CHECK(c.nominalNsPerTick() == 0.0);  // Increment = 1 不当作频率
  Collector col;
  CHECK(c.start(col.cb()) == 0);       // SetGrabStrategy 失败只是警告
  std::this_thread::sleep_for(400ms);
  c.stop();
  auto fr = col.get();
  CHECK(!fr.empty());
  CHECK(fr.front().time_source == TimeSource::kReceive);
  CHECK(fr.front().stamp_mono_ns == fr.front().recv_mono_ns);
  CHECK(std::string(fr.front().format->ros_encoding) == "rgb8");
  CHECK(c.stats().sync_failed > 0);
  CHECK(!c.clockState().ready);
}

TEST(disconnect_sets_flag_and_stop_does_not_hang) {
  twoRealCameras();
  HikCamera c(fastOpts());
  CHECK(c.open({"left", ""}) == 0);
  Collector col;
  CHECK(c.start(col.cb()) == 0);
  std::this_thread::sleep_for(200ms);
  fake_mvs::disconnect("DA0000001");
  std::this_thread::sleep_for(200ms);
  CHECK(c.disconnected());
  CHECK(c.lastError().find("0x00008001") != std::string::npos);
  CHECK(c.stats().grab_errors > 0);
  auto t0 = std::chrono::steady_clock::now();
  c.close();
  CHECK(std::chrono::steady_clock::now() - t0 < 1s);
}

TEST(callback_exception_is_contained) {
  twoRealCameras();
  HikCamera c(fastOpts());
  CHECK(c.open({"left", ""}) == 0);
  CHECK(c.start([](const Frame&) { throw std::runtime_error("bad callback"); }) == 0);
  std::this_thread::sleep_for(200ms);
  c.stop();
  auto st = c.stats();
  CHECK(st.callback_exceptions == st.frames && st.frames > 0);
  CHECK(fake_mvs::counters().frees == fake_mvs::counters().frames_delivered);  // 异常时也释放了缓存
}

TEST(repeated_start_stop_and_destructor) {
  twoRealCameras();
  {
    HikCamera c(fastOpts());
    CHECK(c.open({"left", ""}) == 0);
    for (int i = 0; i < 5; ++i) {
      CHECK(c.start(nullptr) == 0);
      CHECK(c.start(nullptr) == kErrBadState);
      std::this_thread::sleep_for(50ms);
      CHECK(c.stop() == 0);
    }
    CHECK(c.start(nullptr) == 0);
  }  // 析构时自动停流并关闭
  auto k = fake_mvs::counters();
  CHECK(k.handles_destroyed >= 1);
  CHECK(SdkContext::instance().openHandles() == 0);
}
