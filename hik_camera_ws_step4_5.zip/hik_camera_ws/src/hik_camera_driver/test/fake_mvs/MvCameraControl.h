// 测试用的“假 SDK”头文件：只声明 hik_camera_driver 用到的部分。
// 函数原型、结构体、常量取自 sdk_notes.md（已对照真实头文件 /opt/MVS/include 核对）。
// 只用于单元测试；正式编译使用 /opt/MVS/include 中的真实头文件。
#pragma once
#include <stdint.h>
#define __stdcall
#define IN
#define OUT
#define MV_OK 0x00000000
#define MV_E_NODATA 0x80000007
#define MV_E_SUPPORT 0x80000001
#define MV_E_PARAMETER 0x80000004
#define MV_E_GC_ACCESS 0x80000106
#define MV_E_GC_NODE_NOT_FOUND 0x80000109
#define MV_E_GC_RANGE 0x80000102
#define MV_E_ACCESS_DENIED 0x80000203
#define MV_E_USB_DEVICE 0x80000302
#define MV_E_CALLORDER 0x80000003
#define MV_E_DEV_OFFLINE 0x80000020
#define MV_E_HANDLE 0x80000000
#define MV_USB_DEVICE 0x00000004
#define MV_VIR_USB_DEVICE 0x00000020
#define MV_ACCESS_Exclusive 1
#define MV_EXCEPTION_DEV_DISCONNECT 0x00008001
#define MV_MATCH_TYPE_USB_DETECT 0x00000002
#define MV_MAX_DEVICE_NUM 256
#define INFO_MAX_BUFFER_SIZE 64
#define MV_MAX_ENUM_SYMBOLIC_NUM 256
#define MV_MAX_SYMBOLIC_LEN 64
enum MvGvspPixelType { PixelType_Gvsp_Mono8 = 0x01080001, PixelType_Gvsp_BayerGB8 = 0x0108000A, PixelType_Gvsp_RGB8_Packed = 0x02180014 };
typedef struct { unsigned char CrtlInEndPoint, CrtlOutEndPoint, StreamEndPoint, EventEndPoint; unsigned short idVendor, idProduct; unsigned int nDeviceNumber;
 unsigned char chDeviceGUID[64], chVendorName[64], chModelName[64], chFamilyName[64], chDeviceVersion[64], chManufacturerName[64], chSerialNumber[64], chUserDefinedName[64];
 unsigned int nbcdUSB, nDeviceAddress, nReserved[2]; } MV_USB3_DEVICE_INFO;
typedef struct { unsigned short nMajorVer, nMinorVer; unsigned int nMacAddrHigh, nMacAddrLow, nTLayerType, nDevTypeInfo, nReserved[3];
 union { MV_USB3_DEVICE_INFO stUsb3VInfo; char pad[600]; } SpecialInfo; } MV_CC_DEVICE_INFO;
typedef struct { unsigned int nDeviceNum; MV_CC_DEVICE_INFO* pDeviceInfo[MV_MAX_DEVICE_NUM]; } MV_CC_DEVICE_INFO_LIST;
typedef struct { unsigned short nWidth, nHeight; enum MvGvspPixelType enPixelType; unsigned int nFrameNum, nDevTimeStampHigh, nDevTimeStampLow, nReserved0; int64_t nHostTimeStamp;
 unsigned int nFrameLen, nSecondCount, nCycleCount, nCycleOffset; float fGain, fExposureTime; unsigned int nAverageBrightness, nRed, nGreen, nBlue, nFrameCounter, nTriggerIndex, nInput, nOutput;
 unsigned short nOffsetX, nOffsetY, nChunkWidth, nChunkHeight; unsigned int nLostPacket, nUnparsedChunkNum; int64_t u1; unsigned int nExtendWidth, nExtendHeight; uint64_t nFrameLenEx; unsigned int nReserved[40]; } MV_FRAME_OUT_INFO_EX;
typedef struct { unsigned char* pBufAddr; MV_FRAME_OUT_INFO_EX stFrameInfo; unsigned int nRes[16]; } MV_FRAME_OUT;
typedef struct { int64_t nCurValue, nMax, nMin, nInc; unsigned int nReserved[16]; } MVCC_INTVALUE_EX;
typedef struct { float fCurValue, fMax, fMin; unsigned int nReserved[4]; } MVCC_FLOATVALUE;
typedef struct { unsigned int nCurValue, nSupportedNum, nSupportValue[MV_MAX_ENUM_SYMBOLIC_NUM], nReserved[4]; } MVCC_ENUMVALUE_EX;
typedef struct { unsigned int nValue; char chSymbolic[MV_MAX_SYMBOLIC_LEN]; unsigned int nReserved[4]; } MVCC_ENUMENTRY;
typedef struct { char chCurValue[256]; int64_t nMaxLength; unsigned int nReserved[2]; } MVCC_STRINGVALUE;
typedef struct { unsigned int nType; void* pInfo; unsigned int nInfoSize; } MV_ALL_MATCH_INFO;
typedef struct { int64_t nReceiveDataSize; unsigned int nReceivedFrameCount, nErrorFrameCount, nReserved[2]; } MV_MATCH_INFO_USB_DETECT;
typedef enum { MV_GrabStrategy_OneByOne=0, MV_GrabStrategy_LatestImagesOnly=1, MV_GrabStrategy_LatestImages=2, MV_GrabStrategy_UpcomingImage=3 } MV_GRAB_STRATEGY;
enum MV_XML_AccessMode { AM_NI, AM_NA, AM_WO, AM_RO, AM_RW };
typedef enum { MV_CC_STREAM_EXCEPTION_ABNORMAL_IMAGE=0x4001 } MV_CC_STREAM_EXCEPTION_TYPE;
typedef struct { char chSerialNumber[64]; unsigned int nStreamIndex; MV_CC_STREAM_EXCEPTION_TYPE enExceptionType; unsigned int nReserved[8]; } MV_CC_STREAM_EXCEPTION_INFO;
typedef void(__stdcall *MvExceptionCallback)(unsigned int nMsgType, void *pUser);
typedef void(__stdcall *MvStreamExceptionCallback)(MV_CC_STREAM_EXCEPTION_INFO* p, void* pUser);
int MV_CC_Initialize(); int MV_CC_Finalize(); unsigned int MV_CC_GetSDKVersion();
int MV_CC_EnumDevices(unsigned int, MV_CC_DEVICE_INFO_LIST*);
int MV_CC_CreateHandle(void**, const MV_CC_DEVICE_INFO*);
int MV_CC_OpenDevice(void*, unsigned int = MV_ACCESS_Exclusive, unsigned short = 0);
int MV_CC_CloseDevice(void*); int MV_CC_DestroyHandle(void*);
int MV_CC_GetIntValueEx(void*, const char*, MVCC_INTVALUE_EX*); int MV_CC_SetIntValueEx(void*, const char*, int64_t);
int MV_CC_GetEnumValueEx(void*, const char*, MVCC_ENUMVALUE_EX*); int MV_CC_SetEnumValue(void*, const char*, unsigned int);
int MV_CC_GetEnumEntrySymbolic(void*, const char*, MVCC_ENUMENTRY*); int MV_CC_SetEnumValueByString(void*, const char*, const char*);
int MV_CC_GetFloatValue(void*, const char*, MVCC_FLOATVALUE*); int MV_CC_SetFloatValue(void*, const char*, float);
int MV_CC_GetBoolValue(void*, const char*, bool*); int MV_CC_SetBoolValue(void*, const char*, bool);
int MV_CC_GetStringValue(void*, const char*, MVCC_STRINGVALUE*); int MV_CC_SetStringValue(void*, const char*, const char*); int MV_CC_SetCommandValue(void*, const char*);
int MV_XML_GetNodeAccessMode(void*, const char*, enum MV_XML_AccessMode*);
int MV_XML_GetGenICamXML(void*, unsigned char*, unsigned int, unsigned int*);
int MV_CC_InvalidateNodes(void*); int MV_CC_FeatureSave(void*, const char*);
int MV_CC_SetImageNodeNum(void*, unsigned int); int MV_CC_SetGrabStrategy(void*, MV_GRAB_STRATEGY);
int MV_CC_GetValidImageNum(void*, unsigned int*);
int MV_CC_StartGrabbing(void*); int MV_CC_StopGrabbing(void*);
int MV_CC_GetImageBuffer(void*, MV_FRAME_OUT*, unsigned int); int MV_CC_FreeImageBuffer(void*, MV_FRAME_OUT*);
int MV_CC_RegisterExceptionCallBack(void*, MvExceptionCallback, void*);
int MV_CC_RegisterStreamExceptionCallBack(void*, MvStreamExceptionCallback, void*);
int MV_CC_GetAllMatchInfo(void*, MV_ALL_MATCH_INFO*);
