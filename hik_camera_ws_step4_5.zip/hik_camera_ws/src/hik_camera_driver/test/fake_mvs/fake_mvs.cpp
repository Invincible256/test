// fake_mvs.cpp —— 测试用的假海康 SDK（只实现驱动用到的函数）
//
// 行为模仿真机实测结果（hik_probe，2026-11-10）：
//   - 设备时钟：1 tick = 10 ns × (1 + ppm)，从“上电”开始计时；DeviceTimestampIncrement = 1e8
//   - 必须 Latch 后才能读到新的 DeviceTimestamp；Latch 往返约 0.35 ms
//   - 自由运行按 AcquisitionFrameRate 出图；帧时间戳与 Latch 用同一个时钟
//   - 取流中写 Width / Height / PixelFormat 返回 0x80000106
//   - Initialize / Finalize 调用次数被记录，用于检查“每个进程只调用一次”

#include "fake_mvs_control.hpp"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "MvCameraControl.h"

namespace {

int64_t mono() {
  timespec t{};
  clock_gettime(CLOCK_MONOTONIC, &t);
  return int64_t(t.tv_sec) * 1000000000LL + t.tv_nsec;
}

struct Node {
  char type;  // I F E B S
  int64_t i = 0, imin = 0, imax = 0, iinc = 1;
  double f = 0, fmin = 0, fmax = 0;
  bool b = false;
  std::string s;
  std::vector<std::pair<std::string, unsigned>> entries;
  unsigned e = 0;
  bool locked_while_grabbing = false;
};

struct Device {
  fake_mvs::DeviceSpec spec;
  MV_CC_DEVICE_INFO info{};
  int64_t boot_host = 0;  // “上电”时刻
  bool disconnected = false;
};

struct Handle {
  Device* dev = nullptr;
  bool open = false, grabbing = false;
  std::map<std::string, Node> nodes;
  int64_t latched = 0;
  int64_t grab_start = 0;
  uint64_t next_frame = 0;
  unsigned node_num = 1;
  std::vector<unsigned char> buf;
  MvExceptionCallback cb = nullptr;
  void* cb_user = nullptr;
};

std::mutex g_mtx;
std::vector<std::unique_ptr<Device>> g_devices;
std::vector<Handle*> g_handles;
fake_mvs::Counters g_counters;
MV_CC_DEVICE_INFO g_enum_slots[MV_MAX_DEVICE_NUM];  // 模拟 SDK 内部内存：每次枚举都会被覆盖

double truePeriodNs(const Device& d) { return 10.0 * (1.0 + d.spec.clock_ppm * 1e-6); }
int64_t ticksAt(const Device& d, int64_t host) { return static_cast<int64_t>((host - d.boot_host) / truePeriodNs(d)); }

void initNodes(Handle& h) {
  auto I = [&](const char* n, int64_t v, int64_t mn, int64_t mx, int64_t inc, bool lock = false) {
    Node x; x.type = 'I'; x.i = v; x.imin = mn; x.imax = mx; x.iinc = inc; x.locked_while_grabbing = lock; h.nodes[n] = x; };
  auto F = [&](const char* n, double v, double mn, double mx) { Node x; x.type = 'F'; x.f = v; x.fmin = mn; x.fmax = mx; h.nodes[n] = x; };
  auto B = [&](const char* n, bool v) { Node x; x.type = 'B'; x.b = v; h.nodes[n] = x; };
  auto S = [&](const char* n, const std::string& v) { Node x; x.type = 'S'; x.s = v; h.nodes[n] = x; };
  auto E = [&](const char* n, std::vector<std::pair<std::string, unsigned>> es, unsigned cur, bool lock = false) {
    Node x; x.type = 'E'; x.entries = es; x.e = cur; x.locked_while_grabbing = lock; h.nodes[n] = x; };
  const auto& sp = h.dev->spec;
  I("WidthMax", sp.width_max, sp.width_max, sp.width_max, 1);
  I("HeightMax", sp.height_max, sp.height_max, sp.height_max, 1);
  I("Width", sp.width_max, 32, sp.width_max, 8, true);
  I("Height", sp.height_max, 32, sp.height_max, 2, true);
  I("OffsetX", 0, 0, sp.width_max, 8);
  I("OffsetY", 0, 0, sp.height_max, 2);
  I("DeviceTimestamp", 0, 0, INT64_MAX, 1);
  I("DeviceTimestampIncrement", sp.virtual_camera ? 1 : 100000000, 0, INT64_MAX, 1);
  I("PayloadSize", 0, 0, INT64_MAX, 1);
  F("ExposureTime", 5000, 15, 1e7);
  F("Gain", 0, 0, 16.98);
  F("AcquisitionFrameRate", 60, 0.1, 100000);
  F("ResultingFrameRate", 60, -1e30, 1e30);
  B("AcquisitionFrameRateEnable", false);
  B("GammaEnable", false);
  S("DeviceUserID", sp.user_id);
  S("DeviceSerialNumber", sp.serial);
  S("DeviceModelName", sp.model);
  E("TriggerMode", {{"Off", 0}, {"On", 1}}, 1);
  E("TriggerSelector", {{"FrameBurstStart", 6}}, 6);
  E("AcquisitionMode", {{"SingleFrame", 0}, {"Continuous", 2}}, 2);
  E("ExposureAuto", {{"Off", 0}, {"Once", 1}, {"Continuous", 2}}, 2);
  E("GainAuto", {{"Off", 0}, {"Once", 1}, {"Continuous", 2}}, 0);
  E("PixelFormat", {{"Mono8", 0x01080001u}, {"BayerGB8", 0x0108000Au}, {"RGB8Packed", 0x02180014u}}, sp.pixel_format, true);
}

Handle* H(void* h) { return static_cast<Handle*>(h); }

int writable(Handle* h, const std::string& name, Node*& out) {
  if (!h || !h->open) return static_cast<int>(MV_E_HANDLE);
  auto it = h->nodes.find(name);
  if (it == h->nodes.end()) return static_cast<int>(MV_E_GC_NODE_NOT_FOUND);
  if (it->second.locked_while_grabbing && h->grabbing) return static_cast<int>(MV_E_GC_ACCESS);
  out = &it->second;
  return 0;
}

int readable(Handle* h, const std::string& name, Node*& out) {
  if (!h || !h->open) return static_cast<int>(MV_E_HANDLE);
  auto it = h->nodes.find(name);
  if (it == h->nodes.end()) return static_cast<int>(MV_E_GC_NODE_NOT_FOUND);
  out = &it->second;
  return 0;
}

void updatePayload(Handle* h) {
  Node& pf = h->nodes["PixelFormat"];
  int bpp = (pf.e == 0x02180014u) ? 3 : 1;
  h->nodes["PayloadSize"].i = h->nodes["Width"].i * h->nodes["Height"].i * bpp;
}

}  // namespace

// ---------------------------------------------------------------------------
// 测试控制接口
namespace fake_mvs {
void reset() {
  std::lock_guard<std::mutex> lk(g_mtx);
  g_devices.clear();
  int ini = g_counters.initialize_calls, fin = g_counters.finalize_calls;  // 进程级计数保留
  g_counters = Counters{};
  g_counters.initialize_calls = ini;
  g_counters.finalize_calls = fin;
}
void addDevice(const DeviceSpec& s) {
  std::lock_guard<std::mutex> lk(g_mtx);
  auto d = std::make_unique<Device>();
  d->spec = s;
  d->boot_host = mono() - s.uptime_s * 1000000000LL;
  std::memset(&d->info, 0, sizeof(d->info));
  d->info.nTLayerType = s.virtual_camera ? 0x20 : MV_USB_DEVICE;
  auto& u = d->info.SpecialInfo.stUsb3VInfo;
  std::snprintf(reinterpret_cast<char*>(u.chSerialNumber), sizeof(u.chSerialNumber), "%s", s.serial.c_str());
  std::snprintf(reinterpret_cast<char*>(u.chUserDefinedName), sizeof(u.chUserDefinedName), "%s", s.user_id.c_str());
  std::snprintf(reinterpret_cast<char*>(u.chModelName), sizeof(u.chModelName), "%s", s.model.c_str());
  std::snprintf(reinterpret_cast<char*>(u.chVendorName), sizeof(u.chVendorName), "Hikrobot");
  g_devices.push_back(std::move(d));
}
void disconnect(const std::string& serial) {
  std::vector<std::pair<MvExceptionCallback, void*>> cbs;
  {
    std::lock_guard<std::mutex> lk(g_mtx);
    for (auto& d : g_devices) if (d->spec.serial == serial) d->disconnected = true;
    for (Handle* h : g_handles)
      if (h->dev->spec.serial == serial && h->cb) cbs.emplace_back(h->cb, h->cb_user);
  }
  for (auto& c : cbs) c.first(MV_EXCEPTION_DEV_DISCONNECT, c.second);  // 回调在锁外调用
}
Counters counters() {
  std::lock_guard<std::mutex> lk(g_mtx);
  return g_counters;
}
}  // namespace fake_mvs

// ---------------------------------------------------------------------------
// SDK 函数
int MV_CC_Initialize() { std::lock_guard<std::mutex> lk(g_mtx); g_counters.initialize_calls++; return MV_OK; }
int MV_CC_Finalize() { std::lock_guard<std::mutex> lk(g_mtx); g_counters.finalize_calls++; return MV_OK; }
unsigned int MV_CC_GetSDKVersion() { return 0x04090003u; }

int MV_CC_EnumDevices(unsigned int, MV_CC_DEVICE_INFO_LIST* list) {
  std::lock_guard<std::mutex> lk(g_mtx);
  g_counters.enum_calls++;
  std::memset(list, 0, sizeof(*list));
  unsigned n = 0;
  for (auto& d : g_devices) {
    g_enum_slots[n] = d->info;          // 写进“SDK 内部内存”
    list->pDeviceInfo[n] = &g_enum_slots[n];
    n++;
  }
  list->nDeviceNum = n;
  return MV_OK;
}

int MV_CC_CreateHandle(void** out, const MV_CC_DEVICE_INFO* info) {
  std::lock_guard<std::mutex> lk(g_mtx);
  for (auto& d : g_devices) {
    if (std::strncmp(reinterpret_cast<const char*>(d->info.SpecialInfo.stUsb3VInfo.chSerialNumber),
                     reinterpret_cast<const char*>(info->SpecialInfo.stUsb3VInfo.chSerialNumber), 64) == 0) {
      auto* h = new Handle;
      h->dev = d.get();
      g_handles.push_back(h);
      *out = h;
      g_counters.handles_created++;
      return MV_OK;
    }
  }
  return static_cast<int>(MV_E_PARAMETER);
}

int MV_CC_OpenDevice(void* h, unsigned int, unsigned short) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Handle* x = H(h);
  if (x->dev->spec.busy) return static_cast<int>(MV_E_ACCESS_DENIED);
  x->open = true;
  initNodes(*x);
  updatePayload(x);
  return MV_OK;
}
int MV_CC_CloseDevice(void* h) { std::lock_guard<std::mutex> lk(g_mtx); H(h)->open = false; return MV_OK; }
int MV_CC_DestroyHandle(void* h) {
  std::lock_guard<std::mutex> lk(g_mtx);
  for (size_t i = 0; i < g_handles.size(); ++i) if (g_handles[i] == h) { g_handles.erase(g_handles.begin() + i); break; }
  delete H(h);
  g_counters.handles_destroyed++;
  return MV_OK;
}

int MV_CC_GetIntValueEx(void* h, const char* k, MVCC_INTVALUE_EX* v) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = readable(H(h), k, n); if (r) return r;
  if (n->type != 'I') return static_cast<int>(MV_E_GC_ACCESS);
  if (std::string(k) == "DeviceTimestamp") n->i = H(h)->latched;  // 没有 Latch 就一直是旧值
  if (std::string(k) == "OffsetX") n->imax = H(h)->nodes["WidthMax"].i - H(h)->nodes["Width"].i;
  if (std::string(k) == "OffsetY") n->imax = H(h)->nodes["HeightMax"].i - H(h)->nodes["Height"].i;
  std::memset(v, 0, sizeof(*v));
  v->nCurValue = n->i; v->nMin = n->imin; v->nMax = n->imax; v->nInc = n->iinc;
  return MV_OK;
}
int MV_CC_SetIntValueEx(void* h, const char* k, int64_t val) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = writable(H(h), k, n); if (r) return r;
  Handle* x = H(h);
  std::string key = k;
  int64_t mx = n->imax;
  if (key == "OffsetX") mx = x->nodes["WidthMax"].i - x->nodes["Width"].i;
  if (key == "OffsetY") mx = x->nodes["HeightMax"].i - x->nodes["Height"].i;
  if (key == "Width") mx = x->nodes["WidthMax"].i - x->nodes["OffsetX"].i;
  if (key == "Height") mx = x->nodes["HeightMax"].i - x->nodes["OffsetY"].i;
  if (val < n->imin || val > mx || (val - n->imin) % n->iinc) return static_cast<int>(MV_E_GC_RANGE);
  n->i = val;
  updatePayload(x);
  return MV_OK;
}
int MV_CC_GetFloatValue(void* h, const char* k, MVCC_FLOATVALUE* v) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = readable(H(h), k, n); if (r) return r;
  if (n->type != 'F') return static_cast<int>(MV_E_GC_ACCESS);
  std::memset(v, 0, sizeof(*v));
  v->fCurValue = static_cast<float>(n->f); v->fMin = static_cast<float>(n->fmin); v->fMax = static_cast<float>(n->fmax);
  return MV_OK;
}
int MV_CC_SetFloatValue(void* h, const char* k, float val) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = writable(H(h), k, n); if (r) return r;
  if (val < n->fmin || val > n->fmax) return static_cast<int>(MV_E_GC_RANGE);
  n->f = val;
  if (std::string(k) == "AcquisitionFrameRate") H(h)->nodes["ResultingFrameRate"].f = val;
  return MV_OK;
}
int MV_CC_GetEnumValueEx(void* h, const char* k, MVCC_ENUMVALUE_EX* v) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = readable(H(h), k, n); if (r) return r;
  if (n->type != 'E') return static_cast<int>(MV_E_GC_ACCESS);
  std::memset(v, 0, sizeof(*v));
  v->nCurValue = n->e; v->nSupportedNum = static_cast<unsigned>(n->entries.size());
  for (size_t i = 0; i < n->entries.size(); ++i) v->nSupportValue[i] = n->entries[i].second;
  return MV_OK;
}
int MV_CC_GetEnumEntrySymbolic(void* h, const char* k, MVCC_ENUMENTRY* e) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = readable(H(h), k, n); if (r) return r;
  for (auto& p : n->entries) if (p.second == e->nValue) { std::snprintf(e->chSymbolic, sizeof(e->chSymbolic), "%s", p.first.c_str()); return MV_OK; }
  return static_cast<int>(MV_E_PARAMETER);
}
int MV_CC_SetEnumValue(void* h, const char* k, unsigned int val) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = writable(H(h), k, n); if (r) return r;
  for (auto& p : n->entries) if (p.second == val) { n->e = val; updatePayload(H(h)); return MV_OK; }
  return static_cast<int>(MV_E_GC_RANGE);
}
int MV_CC_SetEnumValueByString(void* h, const char* k, const char* sym) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = writable(H(h), k, n); if (r) return r;
  if (n->type != 'E') return static_cast<int>(MV_E_GC_ACCESS);
  for (auto& p : n->entries) if (p.first == sym) { n->e = p.second; updatePayload(H(h)); return MV_OK; }
  return static_cast<int>(MV_E_GC_RANGE);
}
int MV_CC_GetBoolValue(void* h, const char* k, bool* b) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = readable(H(h), k, n); if (r) return r;
  if (n->type != 'B') return static_cast<int>(MV_E_GC_ACCESS);
  *b = n->b;
  return MV_OK;
}
int MV_CC_SetBoolValue(void* h, const char* k, bool b) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = writable(H(h), k, n); if (r) return r;
  if (n->type != 'B') return static_cast<int>(MV_E_GC_ACCESS);
  n->b = b;
  return MV_OK;
}
int MV_CC_GetStringValue(void* h, const char* k, MVCC_STRINGVALUE* v) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = readable(H(h), k, n); if (r) return r;
  if (n->type != 'S') return static_cast<int>(MV_E_GC_ACCESS);
  std::memset(v, 0, sizeof(*v));
  std::snprintf(v->chCurValue, sizeof(v->chCurValue), "%s", n->s.c_str());
  v->nMaxLength = 64;
  return MV_OK;
}
int MV_CC_SetStringValue(void* h, const char* k, const char* s) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Node* n; int r = writable(H(h), k, n); if (r) return r;
  if (n->type != 'S') return static_cast<int>(MV_E_GC_ACCESS);
  n->s = s;
  return MV_OK;
}
int MV_CC_SetCommandValue(void* h, const char* k) {
  Device* d;
  {
    std::lock_guard<std::mutex> lk(g_mtx);
    Handle* x = H(h);
    if (!x || !x->open) return static_cast<int>(MV_E_HANDLE);
    if (std::string(k) != "DeviceTimestampLatch") return static_cast<int>(MV_E_GC_NODE_NOT_FOUND);
    d = x->dev;
    if (d->disconnected) return static_cast<int>(MV_E_USB_DEVICE);
    if (d->spec.virtual_camera) return static_cast<int>(MV_E_PARAMETER);  // 真实虚拟相机：Latch 失败
  }
  // 往返约 350 µs：去程一半时锁存
  std::this_thread::sleep_for(std::chrono::microseconds(175));
  {
    std::lock_guard<std::mutex> lk(g_mtx);
    H(h)->latched = ticksAt(*d, mono());
    g_counters.latch_calls++;
  }
  std::this_thread::sleep_for(std::chrono::microseconds(175));
  return MV_OK;
}
int MV_XML_GetNodeAccessMode(void*, const char*, enum MV_XML_AccessMode* m) { *m = AM_RW; return MV_OK; }
int MV_XML_GetGenICamXML(void*, unsigned char*, unsigned int, unsigned int* len) { *len = 0; return static_cast<int>(MV_E_SUPPORT); }
int MV_CC_InvalidateNodes(void*) { return MV_OK; }
int MV_CC_FeatureSave(void*, const char*) { return MV_OK; }
int MV_CC_SetImageNodeNum(void* h, unsigned int n) { std::lock_guard<std::mutex> lk(g_mtx); H(h)->node_num = n; g_counters.last_node_num = n; return MV_OK; }
int MV_CC_SetGrabStrategy(void* h, MV_GRAB_STRATEGY) {
  std::lock_guard<std::mutex> lk(g_mtx);
  return H(h)->dev->spec.virtual_camera ? static_cast<int>(0x80000021u) : MV_OK;  // 虚拟相机实测返回 0x80000021
}
int MV_CC_GetValidImageNum(void*, unsigned int* n) { *n = 0; return MV_OK; }
int MV_CC_StartGrabbing(void* h) {
  std::lock_guard<std::mutex> lk(g_mtx);
  Handle* x = H(h);
  if (!x->open) return static_cast<int>(MV_E_HANDLE);
  if (x->grabbing) return static_cast<int>(MV_E_CALLORDER);
  x->grabbing = true;
  x->grab_start = mono() + x->dev->spec.phase_ns;
  x->next_frame = 0;
  updatePayload(x);
  x->buf.assign(static_cast<size_t>(x->nodes["PayloadSize"].i), 0x7F);
  g_counters.start_calls++;
  return MV_OK;
}
int MV_CC_StopGrabbing(void* h) {
  std::lock_guard<std::mutex> lk(g_mtx);
  H(h)->grabbing = false;
  g_counters.stop_calls++;
  return MV_OK;
}
int MV_CC_GetImageBuffer(void* h, MV_FRAME_OUT* f, unsigned int timeout_ms) {
  int64_t due, period;
  Device* d;
  {
    std::lock_guard<std::mutex> lk(g_mtx);
    Handle* x = H(h);
    if (!x->grabbing) return static_cast<int>(MV_E_CALLORDER);
    d = x->dev;
    if (d->disconnected) return static_cast<int>(MV_E_USB_DEVICE);
    double fps = x->nodes["AcquisitionFrameRate"].f;
    period = static_cast<int64_t>(1e9 / fps);
    due = x->grab_start + static_cast<int64_t>(x->next_frame + 1) * period;
  }
  int64_t now = mono();
  if (due - now > int64_t(timeout_ms) * 1000000LL) {
    std::this_thread::sleep_for(std::chrono::milliseconds(timeout_ms));
    return static_cast<int>(MV_E_NODATA);
  }
  if (due > now) std::this_thread::sleep_for(std::chrono::nanoseconds(due - now));
  std::this_thread::sleep_for(std::chrono::microseconds(d->spec.transfer_latency_us));  // 读出 + 传输
  std::lock_guard<std::mutex> lk(g_mtx);
  Handle* x = H(h);
  x->next_frame++;
  std::memset(f, 0, sizeof(*f));
  f->pBufAddr = x->buf.data();
  auto& i = f->stFrameInfo;
  i.nFrameNum = static_cast<unsigned>(x->next_frame);
  uint64_t ticks = d->spec.virtual_camera ? 0 : static_cast<uint64_t>(ticksAt(*d, due));
  i.nDevTimeStampHigh = static_cast<unsigned>(ticks >> 32);
  i.nDevTimeStampLow = static_cast<unsigned>(ticks & 0xFFFFFFFFu);
  i.nHostTimeStamp = 0;
  i.nWidth = static_cast<unsigned short>(x->nodes["Width"].i);
  i.nHeight = static_cast<unsigned short>(x->nodes["Height"].i);
  i.enPixelType = static_cast<MvGvspPixelType>(x->nodes["PixelFormat"].e);
  i.nFrameLen = static_cast<unsigned>(x->buf.size());
  i.fExposureTime = static_cast<float>(x->nodes["ExposureTime"].f);
  i.fGain = static_cast<float>(x->nodes["Gain"].f);
  g_counters.frames_delivered++;
  return MV_OK;
}
int MV_CC_FreeImageBuffer(void*, MV_FRAME_OUT*) { std::lock_guard<std::mutex> lk(g_mtx); g_counters.frees++; return MV_OK; }
int MV_CC_RegisterExceptionCallBack(void* h, MvExceptionCallback cb, void* user) {
  std::lock_guard<std::mutex> lk(g_mtx);
  H(h)->cb = cb; H(h)->cb_user = user;
  return MV_OK;
}
int MV_CC_RegisterStreamExceptionCallBack(void*, MvStreamExceptionCallback, void*) { return static_cast<int>(0x80000021u); }
int MV_CC_GetAllMatchInfo(void*, MV_ALL_MATCH_INFO*) { return MV_OK; }
