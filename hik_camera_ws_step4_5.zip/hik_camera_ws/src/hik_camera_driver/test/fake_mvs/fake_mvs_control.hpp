// fake_mvs_control.hpp —— 控制假 SDK 的测试接口
#pragma once
#include <cstdint>
#include <string>

namespace fake_mvs {

struct DeviceSpec {
  std::string serial = "DA0000001";
  std::string user_id = "left";
  std::string model = "MV-CB013-A0UC-S";
  bool virtual_camera = false;      // true：时间戳为 0、Latch 失败、SetGrabStrategy 返回 0x80000021
  int64_t width_max = 1280, height_max = 1024;
  unsigned pixel_format = 0x0108000Au;  // BayerGB8
  double clock_ppm = 5.2;           // 每 tick 的主机纳秒数比 10 ns 多出的 ppm（正数 = 相机比主机慢，真机约 +5）
  int64_t uptime_s = 300;           // 相机已运行时间
  int64_t phase_ns = 0;             // 开流后第一帧的相位偏移
  int transfer_latency_us = 2000;   // 曝光时刻到交给主机的延迟（真机约 9.85 ms，测试用小一点）
  bool busy = false;                // true：OpenDevice 返回 0x80000203（被占用）
};

struct Counters {
  int initialize_calls = 0, finalize_calls = 0;
  int enum_calls = 0, handles_created = 0, handles_destroyed = 0;
  int start_calls = 0, stop_calls = 0;
  long latch_calls = 0, frames_delivered = 0, frees = 0;
  unsigned last_node_num = 0;
};

void reset();                                   // 清空设备（Initialize/Finalize 计数保留）
void addDevice(const DeviceSpec& spec);
void disconnect(const std::string& serial);     // 模拟掉线：触发异常回调，之后取图和 Latch 失败
Counters counters();

}  // namespace fake_mvs
