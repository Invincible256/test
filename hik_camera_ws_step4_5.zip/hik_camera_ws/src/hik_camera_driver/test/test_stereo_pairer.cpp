// test_stereo_pairer.cpp —— 左右配对逻辑测试（模拟两台自由运行的相机）
#include "hik_camera_driver/stereo_pairer.hpp"
#include "test_util.hpp"

using namespace hik_camera_driver;

namespace {
constexpr int64_t kT = 16'666'667;  // 60 Hz
constexpr int64_t kT0 = 1'000'000'000'000LL;

// 生成 n 帧：左从 t0 开始，右偏移 offset_ns；drop_right 中的序号被丢弃
void feed(StereoPairer& p, int n, int64_t offset_ns, int drop_right = -1, int right_start = 0, int right_end = -1) {
  for (int i = 0; i < n; ++i) {
    p.add(Side::kLeft, {kT0 + i * kT, static_cast<uint64_t>(i), static_cast<uint32_t>(i + 1), true});
    if (i == drop_right || i < right_start || (right_end >= 0 && i >= right_end)) continue;
    p.add(Side::kRight, {kT0 + i * kT + offset_ns, static_cast<uint64_t>(i - right_start), static_cast<uint32_t>(i + 1), true});
  }
}
int64_t endOf(int n) { return kT0 + n * kT; }
}  // namespace

TEST(steady_offset_like_real_camera) {
  StereoPairer p(60.0, 10.0);
  feed(p, 3600, 3'910'000);  // 真机实测约 3.91 ms
  p.process(endOf(3600) + 1'000'000'000);
  auto s = p.stats(endOf(3600));
  CHECK(s.total_pairs == 3600);
  CHECK(s.unpaired[0] == 0 && s.unpaired[1] == 0);
  CHECK_NEAR(s.window_mean_ms, 3.91, 0.01);
  CHECK(s.window_max_ms <= 8.34);
  CHECK_NEAR(s.left_fps, 60.0, 0.05);
  CHECK(s.frame_num_gaps[0] == 0 && s.seq_gaps[1] == 0);
  std::printf("    %s\n", s.summary().c_str());
}

TEST(offset_near_half_period_still_pairs) {
  StereoPairer p(60.0, 10.0);
  feed(p, 600, 8'200'000);  // 接近 8.33 ms
  p.process(endOf(600) + 1'000'000'000);
  auto s = p.stats(endOf(600));
  CHECK(s.total_pairs == 600);
  CHECK(s.total_max_ms <= 8.34);
}

TEST(right_drops_one_frame) {
  StereoPairer p(60.0, 10.0);
  feed(p, 600, 3'000'000, /*drop_right=*/300);
  p.process(endOf(600) + 1'000'000'000);
  auto s = p.stats(endOf(600));
  CHECK(s.total_pairs == 599);
  CHECK(s.unpaired[0] == 1 && s.unpaired[1] == 0);
  CHECK(s.frame_num_gaps[1] == 1);  // 右相机帧号跳了一次
  CHECK(s.seq_gaps[1] == 1);        // 测试数据中序号也跳了
}

TEST(right_starts_late_and_stops_early) {
  StereoPairer p(60.0, 10.0);
  feed(p, 600, 2'000'000, -1, /*right_start=*/60, /*right_end=*/540);
  p.process(endOf(600) + 1'000'000'000);
  auto s = p.stats(endOf(600));
  CHECK(s.total_pairs == 480);
  CHECK(s.unpaired[0] == 120);  // 开头 60 帧 + 结尾 60 帧
  CHECK(s.unpaired[1] == 0);
}

TEST(offset_crossing_half_period) {
  // 两台相机快慢略有不同：错位从 7.9 ms 慢慢增大到 8.8 ms（越过半周期 8.33 ms 后，配对对象换成下一帧）
  StereoPairer p(60.0, 10.0);
  for (int i = 0; i < 1200; ++i) {
    int64_t off = 7'900'000 + static_cast<int64_t>(i) * 750;  // 每帧增加 0.75 µs
    p.add(Side::kLeft, {kT0 + i * kT, static_cast<uint64_t>(i), static_cast<uint32_t>(i + 1), true});
    p.add(Side::kRight, {kT0 + i * kT + off, static_cast<uint64_t>(i), static_cast<uint32_t>(i + 1), true});
  }
  p.process(endOf(1200) + 1'000'000'000);
  auto s = p.stats(endOf(1200));
  CHECK(s.total_max_ms <= 8.34);
  CHECK(s.unpaired[0] + s.unpaired[1] <= 2);  // 换对象时最多各丢一帧
  CHECK(s.total_pairs >= 1198);
}

TEST(restart_resets_sequence_without_counting_gap) {
  StereoPairer p(60.0, 10.0);
  feed(p, 100, 1'000'000);
  // 重新开流：序号从 0 开始，帧号也重新开始
  for (int i = 0; i < 100; ++i) {
    int64_t t = kT0 + (200 + i) * kT;
    p.add(Side::kLeft, {t, static_cast<uint64_t>(i), static_cast<uint32_t>(i + 1), true});
    p.add(Side::kRight, {t + 1'000'000, static_cast<uint64_t>(i), static_cast<uint32_t>(i + 1), false});
  }
  p.process(kT0 + 400 * kT);
  auto s = p.stats(kT0 + 300 * kT);
  CHECK(s.seq_gaps[0] == 0 && s.frame_num_gaps[0] == 0);
  CHECK(s.not_device_time[1] == 100);
  CHECK(s.total_pairs == 200);
}

TEST(only_processes_before_cutoff) {
  StereoPairer p(60.0, 10.0);
  feed(p, 100, 1'000'000);
  p.process(kT0 + 50 * kT);  // 只处理前 50 帧
  CHECK(p.stats(kT0 + 50 * kT).total_pairs == 50);
  p.reset();
  CHECK(p.stats(kT0).total_pairs == 0);
}
