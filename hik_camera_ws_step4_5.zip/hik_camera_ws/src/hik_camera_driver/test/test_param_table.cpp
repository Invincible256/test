// test_param_table.cpp —— 参数表解析与写入测试（用模拟的相机节点）
#include <map>

#include "hik_camera_driver/param_table.hpp"
#include "test_util.hpp"

using namespace hik_camera_driver;

namespace {
constexpr int kGcAccess = static_cast<int>(0x80000106u);  // 节点访问条件有误（真机：取流中写 Width）
constexpr int kNotExist = static_cast<int>(0x80000106u);

// 模拟相机：只有部分节点存在；可以设定“读回值与写入值不同”的节点
struct FakeCamera : NodeAccess {
  std::map<std::string, std::string> values;
  std::map<std::string, std::string> stale_readback;  // 写入后读回的“旧值”（模拟 AcquisitionFrameRate 的现象）
  std::vector<std::string> write_order;
  bool has(const std::string& n) const { return values.count(n) > 0; }
  int put(const std::string& n, const std::string& v) {
    if (!has(n)) return kNotExist;
    write_order.push_back(n);
    values[n] = v;
    return 0;
  }
  int setInt(const std::string& n, int64_t v) override { return put(n, std::to_string(v)); }
  int setFloat(const std::string& n, double v) override { char b[64]; snprintf(b, sizeof b, "%.6f", v); return put(n, b); }
  int setEnum(const std::string& n, const std::string& s) override { return put(n, s); }
  int setBool(const std::string& n, bool v) override { return put(n, v ? "true" : "false"); }
  int setString(const std::string& n, const std::string& v) override { return put(n, v); }
  int read(const std::string& n, ParamType, std::string& out) override {
    if (!has(n)) return kNotExist;
    out = stale_readback.count(n) ? stale_readback[n] : values[n];
    return 0;
  }
};
}  // namespace

TEST(parse_valid_specs) {
  auto r = parseParamSpecs({"TriggerMode:enum:Off", "ExposureTime:float:5000", "AcquisitionFrameRateEnable:bool:true",
                            "Width:int:1280", "OffsetX:int:0x10", "GammaEnable:bool:false:optional",
                            "DeviceUserID:string:left:arm:1", "Gain:float:0:required"});
  CHECK(r.ok());
  CHECK(r.entries.size() == 8);
  CHECK(r.entries[0].type == ParamType::kEnum && r.entries[0].value == "Off" && r.entries[0].required);
  CHECK(r.entries[1].float_value == 5000.0);
  CHECK(r.entries[2].bool_value);
  CHECK(r.entries[4].int_value == 16);
  CHECK(!r.entries[5].required);
  CHECK(r.entries[6].value == "left:arm:1");  // 值里可以有冒号
  CHECK(r.entries[7].required);
}

TEST(parse_errors) {
  auto r = parseParamSpecs({"", "OnlyName", "X:double:1", "DeviceReset:command:1", "W:int:12a", "F:float:abc", "B:bool:maybe",
                            "E:enum:"});
  CHECK(r.entries.empty());
  CHECK(r.errors.size() == 8);
}

TEST(parse_duplicate_warning) {
  auto r = parseParamSpecs({"Gain:float:0", "Gain:float:1"});
  CHECK(r.ok());
  CHECK(r.entries.size() == 2);
  CHECK(r.warnings.size() == 1);
}

TEST(apply_order_and_statuses) {
  FakeCamera cam;
  cam.values = {{"TriggerSelector", "FrameBurstStart"}, {"TriggerMode", "On"}, {"ExposureTime", "1000"},
                {"AcquisitionFrameRate", "30"}};
  cam.stale_readback["AcquisitionFrameRate"] = "88.5";  // 真机现象：写入 30 后立即读回 88.5
  auto p = parseParamSpecs({"TriggerSelector:enum:FrameBurstStart", "TriggerMode:enum:Off", "ExposureTime:float:5000",
                            "AcquisitionFrameRate:float:60", "SharpnessEnable:bool:false:optional", "LUTEnable:bool:false"});
  CHECK(p.ok());
  auto rep = applyParams(p.entries, cam);
  CHECK(rep.items.size() == 6);
  CHECK(rep.items[0].status == ApplyStatus::kOk);
  CHECK(rep.items[1].status == ApplyStatus::kOk);
  CHECK(rep.items[2].status == ApplyStatus::kOk);
  CHECK(rep.items[3].status == ApplyStatus::kMismatch);       // 只警告
  CHECK(rep.items[4].status == ApplyStatus::kFailedOptional); // 节点不存在，可选
  CHECK(rep.items[5].status == ApplyStatus::kFailedRequired); // 节点不存在，必需
  CHECK(!rep.allRequiredOk());
  // 顺序必须与配置一致：TriggerSelector 先于 TriggerMode
  CHECK(cam.write_order.size() >= 2 && cam.write_order[0] == "TriggerSelector" && cam.write_order[1] == "TriggerMode");
  for (auto& l : rep.lines()) std::printf("    %s\n", l.c_str());
  std::printf("    %s\n", rep.summary().c_str());
}

TEST(float_tolerance) {
  auto p = parseParamSpecs({"ExposureTime:float:5000"});
  CHECK(valuesMatch(p.entries[0], "5000.000000"));
  CHECK(valuesMatch(p.entries[0], "5003.0"));   // 0.1% 以内
  CHECK(!valuesMatch(p.entries[0], "5010.0"));
  CHECK(retHex(kGcAccess) == "0x80000106");
}
