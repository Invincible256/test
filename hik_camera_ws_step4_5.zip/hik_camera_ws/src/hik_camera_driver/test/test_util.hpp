// test_util.hpp —— 极简单元测试工具（不依赖 gtest，免安装）
#pragma once
#include <cmath>
#include <cstdio>
#include <functional>
#include <string>
#include <vector>

namespace tu {
struct Case { const char* name; std::function<void()> fn; };
inline std::vector<Case>& cases() { static std::vector<Case> v; return v; }
inline int& failures() { static int f = 0; return f; }
struct Reg { Reg(const char* n, std::function<void()> f) { cases().push_back({n, std::move(f)}); } };
inline int runAll() {
  int failed_cases = 0;
  for (auto& c : cases()) {
    int before = failures();
    c.fn();
    bool ok = failures() == before;
    std::printf("[%s] %s\n", ok ? " OK " : "FAIL", c.name);
    failed_cases += !ok;
  }
  std::printf("\n%zu 个测试，%d 个失败\n", cases().size(), failed_cases);
  return failed_cases == 0 ? 0 : 1;
}
}  // namespace tu

#define TEST(name) \
  static void name(); \
  static tu::Reg reg_##name(#name, name); \
  static void name()

#define CHECK(cond) \
  do { if (!(cond)) { std::printf("    %s:%d 检查失败: %s\n", __FILE__, __LINE__, #cond); tu::failures()++; } } while (0)

#define CHECK_NEAR(a, b, tol) \
  do { double _a = (a), _b = (b); if (!(std::fabs(_a - _b) <= (tol))) { \
    std::printf("    %s:%d 检查失败: |%s - %s| = %.6g > %.6g（%s=%.9g）\n", __FILE__, __LINE__, #a, #b, std::fabs(_a - _b), (double)(tol), #a, _a); \
    tu::failures()++; } } while (0)
