# 单相机：把一个 HikCameraNode 加载进组件容器（第 3 步验收用）
#   ros2 launch hik_camera_driver single_camera.launch.py camera:=left config:=laptop_virtual.yaml
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import ComposableNodeContainer
from launch_ros.descriptions import ComposableNode


def _setup(context):
    camera = LaunchConfiguration('camera').perform(context)
    config = LaunchConfiguration('config').perform(context)
    if not os.path.isabs(config):
        config = os.path.join(get_package_share_directory('hik_camera_driver'), 'config', config)
    node = ComposableNode(
        package='hik_camera_driver',
        plugin='hik_camera_driver::HikCameraNode',
        name=camera,
        namespace='stereo',
        parameters=[config],
        extra_arguments=[{'use_intra_process_comms': True}],
    )
    container = ComposableNodeContainer(
        name='hik_camera_container',
        namespace='',   # 容器放在根命名空间：容器的命名空间会通过全局重映射影响被加载的节点
        package='rclcpp_components',
        executable='component_container_mt',
        composable_node_descriptions=[node],
        output='screen',
    )
    return [container]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('camera', default_value='left', description='left 或 right（与配置文件中的节点名一致）'),
        DeclareLaunchArgument('config', default_value='laptop_virtual.yaml', description='config/ 下的文件名，或绝对路径'),
        OpaqueFunction(function=_setup),
    ])
