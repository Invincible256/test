# hik_camera_driver —— 第 1–3 步

> 第 3 步（ROS2 组件节点）的编译、运行和验收说明见工作空间根目录的 README.md。本文件说明第 1、2 步。

| 步骤 | 模块 | 文件 | 作用 |
|---|---|---|---|
| 1 | ClockSync | `clock_sync.hpp/.cpp` | 相机 tick → 主机时间（对时、筛选样本、滑动窗口拟合、复位检测） |
| 1 | PixelFormat | `pixel_format.hpp/.cpp` | 海康像素格式 → ROS 图像编码，计算每行和每帧字节数 |
| 1 | ParamTable | `param_table.hpp/.cpp` | 按顺序写入参数并读回核对，生成启动报告 |
| 2 | SdkContext | `sdk_context.hpp/.cpp` | 进程内只初始化一次 SDK；枚举加锁、结果按值拷贝 |
| 2 | HikCamera | `hik_camera.hpp/.cpp` | 驱动类：按 User ID / 序列号打开、参数读写、取流线程、对时线程、ROI 修改、掉线检测 |

## 一、编译和测试

```bash
cd hik_camera_driver
cmake -S . -B build
cmake --build build -j
./build/test_core      # 第 1 步：20 个测试
./build/test_driver    # 第 2 步：11 个测试（链接假 SDK，不需要相机，约 8 秒）
```

两项都应显示 `0 个失败`。CMake 找到 `/opt/MVS` 时，还会编译 `hik_camera_check`。

## 二、真机 / 虚拟相机验收：hik_camera_check

用 HikCamera 驱动类完成一次完整流程：打开两台相机 → 写入参数表 → 启动检查 → 同时开流 → 取流中修改曝光 → 取流中修改 ROI 再改回 → 停流 → 统计和配对 → 恢复原参数 → 关闭。

```bash
# 运行前关闭 MVS 客户端里的相机连接
./build/hik_camera_check --ids left,right --label laptop_virtual    # 笔记本
./build/hik_camera_check --ids left,right --label lab_real          # 实验室主机
```

屏幕最后打印**结论卡**（同时保存在 `check_out/<时间>_<主机名>_<标签>/brief.txt`），拍照发给我即可。

### 预期结果

| 项目 | 真机预期（与 hik_probe 一致） | 虚拟相机预期 |
|---|---|---|
| 参数表 | `failed_required=0`；部分可选项可能 FAILED_OPTIONAL（节点不存在），AcquisitionFrameRate 可能 MISMATCH（已知现象） | 同左 |
| 检查 | PixelFormat=BayerGB8(bayer_gbrg8)，1280x1024，PayloadSize=1310720 OK；ResultingFrameRate=60 | RGB8Packed(rgb8)，1440x1080 |
| 帧 | 约 60 fps，帧号跳变 0，丢包 0；全部为“设备时间帧” | 全部为“接收时间帧”（时间戳为 0，属正常） |
| 对时 | ready=1 prov=0，约 +5 ppm，rms 十几 µs 以内 | 全部失败（属正常） |
| 接收 − 帧时间 | 中位约 9.85 ms，std 约 0.02–0.1 ms | 约 0（使用接收时间） |
| ROI 测试 | 设小 ROI ret=0，之后帧尺寸 640x480；改回 ret=0 | 同左 |
| 配对 | 平均值在 0–8.33 ms 之间，未配对很少 | 仅供参考 |
| 恢复原值 | failed_required=0 | 同左 |

**注意**：ROI 测试会让第一台相机停流约 0.5 秒再重新开流，所以它的平均帧率会略低于 60，这是正常的。

### 常用参数

| 参数 | 默认 | 说明 |
|---|---|---|
| `--ids` | `left,right` | 按 User ID 打开 |
| `--fps` / `--exposure` | 60 / 5000 | 帧率、曝光（µs） |
| `--duration` | 30 | 取流秒数 |
| `--settings FILE` | 内置清单 | 自定义参数表，每行一项，`#` 开头为注释 |
| `--no-roi-test` / `--no-restore` | — | 跳过 ROI 测试 / 结束时不恢复参数 |

## 三、第 2 步的设计

### SdkContext（进程内单例）

- 第一次调用 `SdkContext::instance()` 时执行 `MV_CC_Initialize`。用函数内静态变量实现，线程安全，只执行一次。
- `enumerate()` 加锁，并把 `MV_CC_DEVICE_INFO` 拷贝到堆上（`DeviceDesc::raw`），之后枚举结果被覆盖也不受影响。
- 记录打开的相机数量。还有相机没关时，`finalize()` 会拒绝执行。独立程序在 main 返回前调用 `finalize()`；ROS 进程可以不调用，静态对象析构时会自动反初始化（安全性待 U6 测试）。
- 头文件不包含海康 SDK 头文件，上层的 ROS 节点代码不直接依赖 SDK。

### HikCamera（驱动类）

| 功能 | 实现要点 | 依据 |
|---|---|---|
| 打开 | 枚举后按 User ID / 序列号匹配；找不到时错误信息里列出当前所有设备；匹配到多台时要求补充序列号 | SDK 没有按 ID 打开的接口 |
| 时间戳单位 | 打开后读取 DeviceTimestampIncrement，换算出名义斜率（真机 10 ns/tick） | 真机实测 |
| 参数 | 实现 `NodeAccess`，可以直接用 ParamTable；另有 `getIntInfo` 等读取范围的函数 | |
| 开流 | `SetImageNodeNum(30)` → `SetGrabStrategy(OneByOne)`（失败只警告）→ **开流前先连续对时 10 次** → `StartGrabbing` → 启动取图线程和对时线程 | 缓存默认只有 1 个；第一帧就能换算时间 |
| 取图线程 | 只调用 GetImageBuffer / FreeImageBuffer 和用户回调；回调抛异常也会释放缓存；统计帧号跳变、丢包、超时 | |
| 对时线程 | 每秒一次 `Latch` → 读 `DeviceTimestamp`，在控制锁内执行；样本交给 ClockSync | 必须先 Latch |
| 时间戳 | 每帧 tick → ClockSync 换算成 CLOCK_MONOTONIC；无法换算时退回接收时刻并标记 `TimeSource::kReceive` | 兼容虚拟相机 |
| 停流 | 退出标志 → 唤醒对时线程 → join 两个线程 → `StopGrabbing` | 先 join 再停流 |
| ROI | 检查范围和步进 → 取流中自动停流 → 偏移归零 → 设宽高 → 设偏移 → 重新开流（沿用原回调）；失败时尽量恢复原 ROI | 宽高在取流中被锁定 |
| 掉线 | 异常回调只置位标志、记录原因（不在回调里做耗时操作）；重连留给第 6 步 | 文档要求 |
| 线程安全 | 控制类调用全部在 `ctl_` 锁内；开关流、ROI、关闭在 `lifecycle_` 锁内 | |

### 单元测试和假 SDK

`test/fake_mvs/` 是一个按真机实测行为编写的假 SDK：10 ns/tick、约 5 ppm 的时钟差、必须 Latch 才能读到新的时间戳、取流中宽高和像素格式被锁定、虚拟相机的各种失败返回码，以及掉线回调。它只用来验证**驱动逻辑**；真实 SDK 的行为以 hik_camera_check 在真机上的结果为准。

测试内容：SDK 只初始化一次、枚举结果是拷贝、按 ID 打开的各种情况（找不到、重名、被占用、重复打开）、参数表写入、自由运行取图和时间戳、双相机配对、取流中修改 ROI、虚拟相机退回接收时间、掉线、回调抛异常、反复开关流和析构。全部测试都通过了 AddressSanitizer / UBSan / ThreadSanitizer 检查。

## 四、第 3 步（已完成，见工作空间 README）

单相机 ROS2 组件节点：YAML 参数（含 ParamTable 格式的 `camera_settings`）、`start` / `stop` / `set_exposure` / `set_gain` / `set_roi` 服务、发布 `image_raw` 和 `frame_meta`。**前置条件：笔记本上装好与主机相同版本的 ROS2。**
