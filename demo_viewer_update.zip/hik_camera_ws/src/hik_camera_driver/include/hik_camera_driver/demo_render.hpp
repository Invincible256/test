// demo_render.hpp —— 演示窗口用到的纯计算函数（不依赖 OpenCV 和 ROS，便于单元测试）
//
//   - halfResDebayer：Bayer 原始图 → 半分辨率 BGR。每个 2×2 Bayer 块直接合成一个彩色像素，
//                     比“先全分辨率去马赛克再缩小”快得多，用于低分辨率显示档位，减少 CPU 占用
//   - ZoomView：数字放大 / 平移的几何计算（放大倍数、视野中心 → 裁剪区域）

#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <string>

namespace hik_camera_driver {

// 2×2 Bayer 块中左上角开始的排列，与 ROS 编码名称一致
enum class BayerPattern { kNone, kRGGB, kBGGR, kGBRG, kGRBG };

inline BayerPattern bayerPatternFromEncoding(const std::string& enc) {
  if (enc == "bayer_rggb8") return BayerPattern::kRGGB;
  if (enc == "bayer_bggr8") return BayerPattern::kBGGR;
  if (enc == "bayer_gbrg8") return BayerPattern::kGBRG;
  if (enc == "bayer_grbg8") return BayerPattern::kGRBG;
  return BayerPattern::kNone;
}

// src：width × height 的 8 位 Bayer 图，每行 step 字节；dst：(width/2) × (height/2) × 3 字节（BGR，紧密排列）
// 返回 false 表示参数不合法
inline bool halfResDebayer(const uint8_t* src, int width, int height, std::size_t step, BayerPattern p, uint8_t* dst) {
  if (!src || !dst || width < 2 || height < 2 || p == BayerPattern::kNone) return false;
  // 2×2 块内四个位置：a=(0,0) b=(0,1) c=(1,0) d=(1,1)
  // 各排列中 R、B 所在位置，以及两个 G 的位置
  int ri, bi;  // 0=a 1=b 2=c 3=d
  switch (p) {
    case BayerPattern::kRGGB: ri = 0; bi = 3; break;
    case BayerPattern::kBGGR: ri = 3; bi = 0; break;
    case BayerPattern::kGBRG: ri = 2; bi = 1; break;
    case BayerPattern::kGRBG: ri = 1; bi = 2; break;
    default: return false;
  }
  const int ow = width / 2, oh = height / 2;
  for (int y = 0; y < oh; ++y) {
    const uint8_t* r0 = src + static_cast<std::size_t>(2 * y) * step;
    const uint8_t* r1 = r0 + step;
    uint8_t* out = dst + static_cast<std::size_t>(y) * ow * 3;
    for (int x = 0; x < ow; ++x) {
      const int v[4] = {r0[2 * x], r0[2 * x + 1], r1[2 * x], r1[2 * x + 1]};
      int g = 0;
      for (int k = 0; k < 4; ++k)
        if (k != ri && k != bi) g += v[k];
      out[3 * x + 0] = static_cast<uint8_t>(v[bi]);
      out[3 * x + 1] = static_cast<uint8_t>((g + 1) / 2);
      out[3 * x + 2] = static_cast<uint8_t>(v[ri]);
    }
  }
  return true;
}

// 数字放大：zoom ≥ 1；center 为视野中心在整幅画面中的相对位置（0–1）
struct ZoomView {
  double zoom = 1.0;
  double cx = 0.5, cy = 0.5;

  static constexpr double kMin = 1.0, kMax = 8.0;

  void zoomBy(double factor) { zoom = std::clamp(zoom * factor, kMin, kMax); clampCenter(); }
  void reset() { zoom = 1.0; cx = cy = 0.5; }
  // 按视野宽度的比例平移，例如 dx = 0.1 表示向右移动视野宽度的 10%
  void pan(double dx, double dy) { cx += dx / zoom; cy += dy / zoom; clampCenter(); }
  // 以画面上的某一点（相对坐标）为中心放大，鼠标滚轮使用
  void zoomAt(double fx, double fy, double factor) {
    const double old = zoom;
    const double ax = cx + (fx - 0.5) / old, ay = cy + (fy - 0.5) / old;  // 鼠标所指的整幅画面坐标
    zoom = std::clamp(zoom * factor, kMin, kMax);
    cx = ax - (fx - 0.5) / zoom;
    cy = ay - (fy - 0.5) / zoom;
    clampCenter();
  }
  // 根据整幅画面尺寸计算裁剪区域
  void cropRect(int full_w, int full_h, int& x, int& y, int& w, int& h) const {
    w = std::max(1, static_cast<int>(full_w / zoom));
    h = std::max(1, static_cast<int>(full_h / zoom));
    x = std::clamp(static_cast<int>(cx * full_w - w / 2.0), 0, std::max(0, full_w - w));
    y = std::clamp(static_cast<int>(cy * full_h - h / 2.0), 0, std::max(0, full_h - h));
  }

 private:
  void clampCenter() {
    const double half = 0.5 / zoom;
    cx = std::clamp(cx, half, 1.0 - half);
    cy = std::clamp(cy, half, 1.0 - half);
  }
};

}  // namespace hik_camera_driver
