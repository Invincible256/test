# 双相机：左右两个 HikCameraNode + 协调节点 /stereo，全部加载进同一个组件容器（第 4、5 步）
#   ros2 launch hik_camera_driver stereo.launch.py config:=lab_real.yaml
# 启动后：ros2 service call /stereo/start std_srvs/srv/Trigger   同时启动两台相机
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import ComposableNodeContainer
from launch_ros.descriptions import ComposableNode


def _setup(context):
    config = LaunchConfiguration('config').perform(context)
    demo = LaunchConfiguration('demo').perform(context).lower() in ('true', '1', 'yes')
    if not os.path.isabs(config):
        config = os.path.join(get_package_share_directory('hik_camera_driver'), 'config', config)
    nodes = [
        ComposableNode(
            package='hik_camera_driver',
            plugin='hik_camera_driver::HikCameraNode',
            name=side,
            namespace='stereo',
            parameters=[config],
            extra_arguments=[{'use_intra_process_comms': True}],
        )
        for side in ('left', 'right')
    ]
    nodes.append(ComposableNode(
        package='hik_camera_driver',
        plugin='hik_camera_driver::StereoCoordinator',
        name='stereo',
        namespace='/',   # 节点全名 /stereo → 服务 /stereo/start、/stereo/stop ……
        parameters=[config],
        extra_arguments=[{'use_intra_process_comms': True}],
    ))
    if demo:  # 演示窗口：同一个容器内，进程内零拷贝接收图像
        nodes.append(ComposableNode(
            package='hik_camera_driver',
            plugin='hik_camera_driver::DemoViewer',
            name='demo_viewer',
            namespace='stereo',
            parameters=[config],
            extra_arguments=[{'use_intra_process_comms': True}],
        ))
    return [ComposableNodeContainer(
        name='hik_camera_container',
        namespace='',   # 容器放在根命名空间：容器的命名空间会通过全局重映射影响被加载的节点
        package='rclcpp_components',
        executable='component_container_mt',   # 必须是多线程容器（协调节点在服务回调中等待相机节点的响应）
        composable_node_descriptions=nodes,
        output='screen',
    )]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('config', default_value='laptop_virtual.yaml', description='config/ 下的文件名，或绝对路径'),
        DeclareLaunchArgument('demo', default_value='false', description='true：同时打开演示窗口（正式采集时建议关闭）'),
        OpaqueFunction(function=_setup),
    ])
