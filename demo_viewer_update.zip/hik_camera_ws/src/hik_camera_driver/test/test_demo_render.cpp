// test_demo_render.cpp —— 演示窗口纯计算函数的测试
#include <vector>

#include "hik_camera_driver/demo_render.hpp"
#include "test_util.hpp"

using namespace hik_camera_driver;

namespace {
// 生成一个纯色场景的 Bayer 图：场景颜色为 (R, G, B)
std::vector<uint8_t> bayerOf(BayerPattern p, int w, int h, uint8_t R, uint8_t G, uint8_t B) {
  std::vector<uint8_t> img(static_cast<size_t>(w) * h);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      int pos = (y % 2) * 2 + (x % 2);  // 0=a 1=b 2=c 3=d
      char c;
      switch (p) {
        case BayerPattern::kRGGB: c = "RGGB"[pos]; break;
        case BayerPattern::kBGGR: c = "BGGR"[pos]; break;
        case BayerPattern::kGBRG: c = "GBRG"[pos]; break;
        default: c = "GRBG"[pos]; break;
      }
      img[static_cast<size_t>(y) * w + x] = c == 'R' ? R : c == 'G' ? G : B;
    }
  return img;
}
}  // namespace

TEST(half_res_debayer_all_patterns) {
  for (auto p : {BayerPattern::kRGGB, BayerPattern::kBGGR, BayerPattern::kGBRG, BayerPattern::kGRBG}) {
    auto src = bayerOf(p, 8, 6, 200, 100, 30);
    std::vector<uint8_t> dst(4 * 3 * 3);
    CHECK(halfResDebayer(src.data(), 8, 6, 8, p, dst.data()));
    for (size_t i = 0; i < dst.size(); i += 3) {
      CHECK(dst[i] == 30);       // B
      CHECK(dst[i + 1] == 100);  // G
      CHECK(dst[i + 2] == 200);  // R
    }
  }
  CHECK(bayerPatternFromEncoding("bayer_gbrg8") == BayerPattern::kGBRG);  // 真机编码
  CHECK(bayerPatternFromEncoding("rgb8") == BayerPattern::kNone);
}

TEST(half_res_debayer_with_row_padding) {
  auto src = bayerOf(BayerPattern::kGBRG, 4, 4, 10, 20, 30);
  std::vector<uint8_t> padded(4 * 6, 0);  // 每行 6 字节（4 字节数据 + 2 字节填充）
  for (int y = 0; y < 4; ++y)
    for (int x = 0; x < 4; ++x) padded[y * 6 + x] = src[y * 4 + x];
  std::vector<uint8_t> dst(2 * 2 * 3);
  CHECK(halfResDebayer(padded.data(), 4, 4, 6, BayerPattern::kGBRG, dst.data()));
  CHECK(dst[0] == 30 && dst[1] == 20 && dst[2] == 10);
  CHECK(!halfResDebayer(padded.data(), 1, 4, 6, BayerPattern::kGBRG, dst.data()));
}

TEST(zoom_view_geometry) {
  ZoomView z;
  int x, y, w, h;
  z.cropRect(2560, 1024, x, y, w, h);
  CHECK(x == 0 && y == 0 && w == 2560 && h == 1024);
  z.zoomBy(2.0);
  z.cropRect(2560, 1024, x, y, w, h);
  CHECK(w == 1280 && h == 512 && x == 640 && y == 256);  // 放大 2 倍，居中
  z.pan(1.0, 0);                                         // 向右移动很多：停在右边界
  z.cropRect(2560, 1024, x, y, w, h);
  CHECK(x == 1280);
  z.zoomBy(100);                                         // 最大 8 倍
  CHECK(z.zoom == ZoomView::kMax);
  z.reset();
  z.zoomAt(1.0, 1.0, 2.0);                               // 以右下角为中心放大
  z.cropRect(1000, 1000, x, y, w, h);
  CHECK(x == 500 && y == 500 && w == 500 && h == 500);
  z.zoomBy(0.01);                                        // 最小 1 倍
  CHECK(z.zoom == ZoomView::kMin);
}
