// demo_viewer_node.cpp —— 演示窗口：与相机节点放在同一个组件容器中，进程内零拷贝接收图像
//
// 为什么流畅：rqt_image_view 在另一个进程里，每帧 1.3 MB 都要经过 ROS 传输层拷贝；本组件在同一个
//             进程里直接拿到图像指针，只做 去马赛克 → 缩放 → 显示，而且永远只画最新的一帧。
//
// 对采集的影响：只读取图像，不修改发布的数据；显示跟不上时直接跳帧，不会拖慢相机节点。
//               CPU 占用随“显示分辨率档位 × 显示帧率”增减，录制时可以调低（按键 3 / 4、[ ）。
//               正式采集训练数据时建议关闭（launch 参数 demo:=false，默认就是关闭）。
//
// 按键（窗口获得焦点时）：
//   + / -      放大 / 缩小（数字放大，最大 8 倍）；鼠标滚轮也可以（取决于 OpenCV 的界面后端）
//   0          恢复不放大
//   w a s d    放大后平移视野（方向键也可以）
//   1 2 3 4    显示分辨率：100% / 75% / 50% / 25%（越低越省 CPU）
//   [ ]        显示帧率 -5 / +5（5–60）
//   v          切换：左右并排 / 只看左 / 只看右
//   r          画面旋转 180°（只影响显示）
//   f          全屏 / 退出全屏
//   p          截图：保存当前画面到 snapshot_dir
//   h          显示 / 隐藏帮助
//   q / Esc    关闭窗口（相机继续工作）。请用 q 关闭；直接点窗口右上角的 × 在部分系统上窗口会重新弹出
// 拖动窗口边缘也可以缩放窗口大小。

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include <sys/stat.h>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "hik_camera_driver/demo_render.hpp"
#include "hik_camera_interfaces/msg/sync_status.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_components/register_node_macro.hpp"
#include "sensor_msgs/msg/image.hpp"

namespace hik_camera_driver {

namespace {

const double kScales[4] = {1.0, 0.75, 0.5, 0.25};

void mkdirs(const std::string& path) {
  std::string cur;
  for (std::size_t i = 0; i < path.size(); ++i) {
    cur += path[i];
    if (path[i] == '/' || i + 1 == path.size()) mkdir(cur.c_str(), 0755);
  }
}

// ROS Bayer 编码 → OpenCV 去马赛克代码（与 cv_bridge 相同：OpenCV 的命名比 ROS 错开一位）
int bayerCode(const std::string& enc) {
  if (enc == "bayer_rggb8") return cv::COLOR_BayerBG2BGR;
  if (enc == "bayer_bggr8") return cv::COLOR_BayerRG2BGR;
  if (enc == "bayer_gbrg8") return cv::COLOR_BayerGR2BGR;
  if (enc == "bayer_grbg8") return cv::COLOR_BayerGB2BGR;
  return -1;
}

// 把一帧转成指定缩放比例的 BGR 图像。scale ≤ 0.5 的 Bayer 图走半分辨率快速路径
cv::Mat toBgr(const sensor_msgs::msg::Image& m, double scale) {
  if (m.width == 0 || m.height == 0 || m.data.empty()) return {};
  auto* data = const_cast<uint8_t*>(m.data.data());
  const int w = static_cast<int>(m.width), h = static_cast<int>(m.height);
  cv::Mat bgr;
  const int code = bayerCode(m.encoding);
  if (code >= 0) {
    if (scale <= 0.5) {
      bgr.create(h / 2, w / 2, CV_8UC3);
      halfResDebayer(data, w, h, m.step, bayerPatternFromEncoding(m.encoding), bgr.data);
      scale *= 2.0;  // 已经缩小了一半
    } else {
      cv::cvtColor(cv::Mat(h, w, CV_8UC1, data, m.step), bgr, code);
    }
  } else if (m.encoding == "rgb8") {
    cv::cvtColor(cv::Mat(h, w, CV_8UC3, data, m.step), bgr, cv::COLOR_RGB2BGR);
  } else if (m.encoding == "bgr8") {
    bgr = cv::Mat(h, w, CV_8UC3, data, m.step).clone();
  } else if (m.encoding == "mono8") {
    cv::cvtColor(cv::Mat(h, w, CV_8UC1, data, m.step), bgr, cv::COLOR_GRAY2BGR);
  } else {
    return {};
  }
  if (scale < 0.999) cv::resize(bgr, bgr, cv::Size(), scale, scale, cv::INTER_AREA);
  return bgr;
}

cv::Mat placeholder(int w, int h, const std::string& text) {
  cv::Mat m(h, w, CV_8UC3, cv::Scalar(40, 40, 40));
  cv::putText(m, text, cv::Point(20, h / 2), cv::FONT_HERSHEY_SIMPLEX, std::max(0.6, w / 900.0), cv::Scalar(200, 200, 200), 2, cv::LINE_AA);
  return m;
}

}  // namespace

class DemoViewer : public rclcpp::Node {
  using Image = sensor_msgs::msg::Image;
  using SyncStatus = hik_camera_interfaces::msg::SyncStatus;

 public:
  explicit DemoViewer(const rclcpp::NodeOptions& options) : rclcpp::Node("demo_viewer", options) {
    const std::string left = declare_parameter<std::string>("left_topic", "/stereo/left/image_raw");
    const std::string right = declare_parameter<std::string>("right_topic", "/stereo/right/image_raw");
    const std::string sync = declare_parameter<std::string>("sync_topic", "/stereo/sync_status");
    display_fps_ = std::clamp(declare_parameter<double>("display_fps", 30.0), 5.0, 60.0);
    scale_idx_ = std::clamp(static_cast<int>(declare_parameter<int64_t>("resolution_level", 3)) - 1, 0, 3);  // 1–4，默认 3 = 50%
    rotate_ = declare_parameter<bool>("rotate_180", false);
    snapshot_dir_ = declare_parameter<std::string>("snapshot_dir", "");
    if (snapshot_dir_.empty()) {
      const char* home = getenv("HOME");
      snapshot_dir_ = std::string(home ? home : "/tmp") + "/camera/snapshots";
    }

    // 只保留最新的一帧：深度 1，显示跟不上时旧帧被直接覆盖，不会拖慢发布者
    auto qos = rclcpp::QoS(rclcpp::KeepLast(1)).reliable();
    sub_[0] = create_subscription<Image>(left, qos, [this](Image::ConstSharedPtr m) { std::lock_guard<std::mutex> lk(mtx_); latest_[0] = m; });
    sub_[1] = create_subscription<Image>(right, qos, [this](Image::ConstSharedPtr m) { std::lock_guard<std::mutex> lk(mtx_); latest_[1] = m; });
    sub_sync_ = create_subscription<SyncStatus>(sync, rclcpp::QoS(rclcpp::KeepLast(1)).reliable(),
                                                [this](SyncStatus::ConstSharedPtr m) { std::lock_guard<std::mutex> lk(mtx_); sync_ = m; });

    if (!getenv("DISPLAY") && !getenv("WAYLAND_DISPLAY")) {
      RCLCPP_ERROR(get_logger(), "没有图形界面环境（DISPLAY 未设置），演示窗口不启动；相机不受影响");
      return;
    }
    run_ = true;
    th_ = std::thread([this] { renderLoop(); });
    RCLCPP_INFO(get_logger(), "演示窗口已启动：显示 %.0f fps，分辨率 %.0f%%。按 h 显示帮助，q 关闭窗口", display_fps_, kScales[scale_idx_] * 100);
  }

  ~DemoViewer() override {
    run_ = false;
    if (th_.joinable()) th_.join();
  }

 private:
  static void onMouse(int event, int x, int y, int flags, void* user) {
    auto* self = static_cast<DemoViewer*>(user);
    if (event == cv::EVENT_MOUSEWHEEL && self->last_w_ > 0 && self->last_h_ > 0) {
      const int d = cv::getMouseWheelDelta(flags);
      self->zoom_.zoomAt(double(x) / self->last_w_, double(y) / self->last_h_, d > 0 ? 1.25 : 0.8);
    }
  }

  void renderLoop() {
    const std::string win = "Hik stereo demo";
    try {
      cv::namedWindow(win, cv::WINDOW_NORMAL | cv::WINDOW_KEEPRATIO);
      cv::resizeWindow(win, 1600, 700);
      cv::setMouseCallback(win, &DemoViewer::onMouse, this);
    } catch (const std::exception& e) {
      RCLCPP_ERROR(get_logger(), "无法创建窗口：%s（相机不受影响）", e.what());
      return;
    }
    auto next = std::chrono::steady_clock::now();
    auto fps_t0 = next;
    int frames = 0;
    double shown_fps = 0;
    bool fullscreen = false;
    while (run_ && rclcpp::ok()) {
      next += std::chrono::microseconds(static_cast<int64_t>(1e6 / display_fps_));
      try {
        Image::ConstSharedPtr img[2];
        SyncStatus::ConstSharedPtr sync;
        {
          std::lock_guard<std::mutex> lk(mtx_);
          img[0] = latest_[0];
          img[1] = latest_[1];
          sync = sync_;
        }
        const double scale = kScales[scale_idx_];
        cv::Mat side[2];
        for (int i = 0; i < 2; ++i) {
          if ((view_ == 1 && i == 1) || (view_ == 2 && i == 0)) continue;
          if (img[i]) side[i] = toBgr(*img[i], scale);
          if (side[i].empty()) side[i] = placeholder(static_cast<int>(1280 * scale), static_cast<int>(1024 * scale), i == 0 ? "LEFT: waiting" : "RIGHT: waiting");
          if (rotate_) cv::rotate(side[i], side[i], cv::ROTATE_180);
        }
        cv::Mat full;
        if (view_ == 0) {
          if (side[0].rows != side[1].rows) cv::resize(side[1], side[1], cv::Size(side[1].cols * side[0].rows / std::max(1, side[1].rows), side[0].rows));
          cv::hconcat(side[0], side[1], full);
        } else {
          full = view_ == 1 ? side[0] : side[1];
        }
        int x, y, w, h;
        zoom_.cropRect(full.cols, full.rows, x, y, w, h);
        cv::Mat out = full(cv::Rect(x, y, w, h)).clone();
        drawOverlay(out, sync, shown_fps, scale);
        last_w_ = out.cols;
        last_h_ = out.rows;
        cv::imshow(win, out);

        const int key = cv::waitKeyEx(1);
        if (key >= 0 && !handleKey(key, out, win, fullscreen)) break;
      } catch (const std::exception& e) {
        RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 5000, "演示窗口出错（已忽略，相机不受影响）：%s", e.what());
      }
      ++frames;
      const auto now = std::chrono::steady_clock::now();
      const double el = std::chrono::duration<double>(now - fps_t0).count();
      if (el >= 1.0) { shown_fps = frames / el; frames = 0; fps_t0 = now; }
      if (next > now) std::this_thread::sleep_until(next);
      else next = now;  // 落后时不追赶
    }
    try { cv::destroyWindow(win); cv::waitKey(1); } catch (...) {}
    RCLCPP_INFO(get_logger(), "演示窗口已关闭（相机继续工作）");
  }

  void drawOverlay(cv::Mat& out, const SyncStatus::ConstSharedPtr& sync, double shown_fps, double scale) {
    const double fs = std::max(0.5, out.cols / 1800.0);
    const int th = std::max(1, static_cast<int>(fs * 2));
    const int lh = static_cast<int>(32 * fs) + 6;
    char b[256];
    std::vector<std::string> lines;
    if (sync) {
      std::snprintf(b, sizeof b, "CAM L %.2f fps  R %.2f fps | L-R sync mean %.2f ms  max %.2f ms | gaps L%llu R%llu", sync->left_fps,
                    sync->right_fps, sync->window_mean_ms, sync->window_max_ms, (unsigned long long)sync->left_frame_num_gaps,
                    (unsigned long long)sync->right_frame_num_gaps);
    } else {
      std::snprintf(b, sizeof b, "CAM: no sync_status (is /stereo coordinator running?)");
    }
    lines.push_back(b);
    std::snprintf(b, sizeof b, "display %.0f/%.0f fps | res %.0f%% | zoom %.1fx | %s%s | h: help", shown_fps, display_fps_, scale * 100,
                  zoom_.zoom, view_ == 0 ? "both" : view_ == 1 ? "left" : "right", rotate_ ? " | rot180" : "");
    lines.push_back(b);
    if (show_help_) {
      lines.push_back("+/- zoom  0 reset  wasd/arrows pan  1-4 resolution 100/75/50/25%  [ ] display fps");
      lines.push_back("v view  r rotate180  f fullscreen  p snapshot  q close window (cameras keep running)");
    }
    cv::rectangle(out, cv::Rect(0, 0, out.cols, lh * static_cast<int>(lines.size()) + 8), cv::Scalar(0, 0, 0), cv::FILLED);
    for (std::size_t i = 0; i < lines.size(); ++i)
      cv::putText(out, lines[i], cv::Point(10, lh * static_cast<int>(i + 1)), cv::FONT_HERSHEY_SIMPLEX, fs, cv::Scalar(255, 255, 255), th, cv::LINE_AA);
  }

  // 返回 false 表示关闭窗口
  bool handleKey(int key, const cv::Mat& out, const std::string& win, bool& fullscreen) {
    const int k = key & 0xFFFF;
    // 方向键：GTK 后端 65361–65364；Qt 后端 0x250000–0x280000
    const bool left = key == 65361 || key == 0x250000, up = key == 65362 || key == 0x260000;
    const bool right = key == 65363 || key == 0x270000, down = key == 65364 || key == 0x280000;
    if (left || k == 'a') zoom_.pan(-0.1, 0);
    else if (right || k == 'd') zoom_.pan(0.1, 0);
    else if (up || k == 'w') zoom_.pan(0, -0.1);
    else if (down || k == 's') zoom_.pan(0, 0.1);
    else if (k == '+' || k == '=') zoom_.zoomBy(1.25);
    else if (k == '-' || k == '_') zoom_.zoomBy(0.8);
    else if (k == '0') zoom_.reset();
    else if (k >= '1' && k <= '4') scale_idx_ = k - '1';
    else if (k == '[') display_fps_ = std::max(5.0, display_fps_ - 5);
    else if (k == ']') display_fps_ = std::min(60.0, display_fps_ + 5);
    else if (k == 'v') view_ = (view_ + 1) % 3;
    else if (k == 'r') rotate_ = !rotate_;
    else if (k == 'h') show_help_ = !show_help_;
    else if (k == 'f') {
      fullscreen = !fullscreen;
      cv::setWindowProperty(win, cv::WND_PROP_FULLSCREEN, fullscreen ? cv::WINDOW_FULLSCREEN : cv::WINDOW_NORMAL);
    } else if (k == 'p') {
      mkdirs(snapshot_dir_);
      char name[64];
      time_t t = time(nullptr);
      strftime(name, sizeof name, "/snapshot_%Y%m%d_%H%M%S.png", localtime(&t));
      const std::string path = snapshot_dir_ + name;
      if (cv::imwrite(path, out)) RCLCPP_INFO(get_logger(), "截图已保存：%s", path.c_str());
    } else if (k == 'q' || k == 27) {
      return false;
    }
    return true;
  }

  std::mutex mtx_;
  Image::ConstSharedPtr latest_[2];
  SyncStatus::ConstSharedPtr sync_;
  rclcpp::Subscription<Image>::SharedPtr sub_[2];
  rclcpp::Subscription<SyncStatus>::SharedPtr sub_sync_;

  std::thread th_;
  std::atomic<bool> run_{false};
  ZoomView zoom_;
  double display_fps_ = 30.0;
  int scale_idx_ = 2;
  int view_ = 0;  // 0 并排，1 左，2 右
  bool rotate_ = false, show_help_ = false;
  std::string snapshot_dir_;
  int last_w_ = 0, last_h_ = 0;
};

}  // namespace hik_camera_driver

RCLCPP_COMPONENTS_REGISTER_NODE(hik_camera_driver::DemoViewer)
