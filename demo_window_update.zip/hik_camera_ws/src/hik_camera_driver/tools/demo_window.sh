#!/usr/bin/env bash
# demo_window.sh —— 演示窗口的一键开关（保证容器里始终最多只有一个演示窗口组件）
#
#   ros2 run hik_camera_driver demo_window.sh open      打开：没加载就加载；已加载（例如按过 q）就重新打开窗口
#   ros2 run hik_camera_driver demo_window.sh close     关闭窗口，组件保留（之后 open 很快）
#   ros2 run hik_camera_driver demo_window.sh unload    彻底卸载组件（正式采集前推荐）
#   ros2 run hik_camera_driver demo_window.sh status    查看当前加载了几个演示窗口组件
#
# 可选环境变量：DEMO_FPS（默认 30）、DEMO_RES（1–4，默认 3 = 50%）

CONTAINER=/hik_camera_container
NODE=/stereo/demo_viewer
FPS=${DEMO_FPS:-30.0}
RES=${DEMO_RES:-3}

ids() {
  ros2 component list "$CONTAINER" 2>/dev/null | awk -v n="$NODE" '$2 == n {print $1}'
}

if ! ros2 component list 2>/dev/null | grep -qx "$CONTAINER"; then
  echo "找不到容器 $CONTAINER：相机程序是否已经用 stereo.launch.py 启动？这个终端是否 source 了环境？"
  exit 1
fi

case "$1" in
  open)
    IDS=$(ids)
    if [ -n "$IDS" ]; then
      echo "演示窗口组件已加载（编号 $(echo $IDS | tr '\n' ' ')），重新打开窗口"
      ros2 service call "$NODE/open" std_srvs/srv/Trigger > /dev/null && echo "已打开"
    else
      ros2 component load "$CONTAINER" hik_camera_driver hik_camera_driver::DemoViewer \
        --node-name demo_viewer --node-namespace /stereo \
        -e use_intra_process_comms:=true \
        -p display_fps:="$FPS" -p resolution_level:="$RES"
    fi
    ;;
  close)
    if [ -n "$(ids)" ]; then
      ros2 service call "$NODE/close" std_srvs/srv/Trigger > /dev/null && echo "窗口已关闭（组件保留，open 可以重新打开）"
    else
      echo "没有加载演示窗口组件"
    fi
    ;;
  unload)
    IDS=$(ids)
    if [ -z "$IDS" ]; then echo "没有加载演示窗口组件"; exit 0; fi
    for id in $IDS; do ros2 component unload "$CONTAINER" "$id"; done   # 有多个（旧版本留下的）也全部卸载
    ;;
  status)
    IDS=$(ids)
    if [ -z "$IDS" ]; then echo "没有加载演示窗口组件"; else echo "已加载 $(echo "$IDS" | wc -l) 个演示窗口组件，编号：$(echo $IDS | tr '\n' ' ')"; fi
    ;;
  *)
    echo "用法：ros2 run hik_camera_driver demo_window.sh open | close | unload | status"
    exit 2
    ;;
esac
